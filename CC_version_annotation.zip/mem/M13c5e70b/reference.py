USED_INPUTS = ['pet_over_p']
LAW_CONSTANTS = {'alpha': 1.8}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {}

def predict(X: np.ndarray, alpha: float=1.8, **params) -> np.ndarray:
    phi = np.asarray(X[:, 0], dtype=float)
    return 1.0 / (1.0 + (1.0 / phi) ** alpha) ** (1.0 / alpha)
