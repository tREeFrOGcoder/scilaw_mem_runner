import numpy as np

def predict(X):
    X = np.asarray(X, dtype=float)
    phi = X[:, 0]  # PET/P aridity index

    eps = np.finfo(float).tiny
    phi_safe = np.maximum(phi, eps)

    # Budyko (1974) curve:
    # E/P = sqrt( phi * tanh(1/phi) * (1 - exp(-phi)) )
    et_over_p = np.sqrt(
        phi_safe * np.tanh(1.0 / phi_safe) * (1.0 - np.exp(-phi_safe))
    )

    return np.clip(et_over_p, 0.0, 1.0)
