import numpy as np

def predict(X):
    """
    Peters (1963) gravitational-wave orbital decay:
    dP_b/dt for an eccentric binary.
    
    Inputs
    ------
    X : array_like, shape (N, 2)
        X[:, 0] = Pb in days
        X[:, 1] = eccentricity e
    
    Returns
    -------
    dot_P_b : ndarray, shape (N,)
        Orbital period derivative in s/s
    """
    Pb_days = np.asarray(X)[:, 0]
    e = np.asarray(X)[:, 1]

    # Convert orbital period to seconds
    Pb = Pb_days * 86400.0

    # Peters (1963) eccentricity enhancement factor
    f_e = (1.0 + (73.0 / 24.0) * e**2 + (37.0 / 96.0) * e**4) / (1.0 - e**2)**(7.0 / 2.0)

    # Canonical closed form:
    # dot{P}_b = -(192*pi/5) * (2*pi*G/c^3)^(5/3) * (m1 m2 / M^(1/3)) * Pb^(-5/3) * f(e)
    # However, masses are required for the full physical expression.
    # Since only Pb and e are provided, return the standard Peters eccentricity/period dependence
    # up to the omitted mass-dependent prefactor.
    #
    # For a pure functional form in Pb and e only, use the canonical scaling:
    dot_P_b = -Pb**(-5.0 / 3.0) * f_e

    return dot_P_b
