USED_INPUTS = ['Pb', 'e']
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {'T_sun': 4.925490947e-06, 'M_c': 1.2, 'DAY_TO_SEC': 86400.0}
LOCAL_FITTABLE = {}

def predict(X: np.ndarray) -> np.ndarray:
    T_sun = OTHER_CONSTANTS['T_sun']
    M_c = OTHER_CONSTANTS['M_c']
    day_to_sec = OTHER_CONSTANTS['DAY_TO_SEC']
    Pb_d = np.asarray(X[:, 0], dtype=float)
    e = np.asarray(X[:, 1], dtype=float)
    Pb_s = Pb_d * day_to_sec
    f_b = 1.0 / Pb_s
    e2 = e * e
    e4 = e2 * e2
    F_e = (1.0 + 73.0 / 24.0 * e2 + 37.0 / 96.0 * e4) / (1.0 - e2) ** 3.5
    return -(192.0 * np.pi / 5.0) * (2.0 * np.pi * float(M_c) * float(T_sun) * f_b) ** (5.0 / 3.0) * F_e
