import numpy as np

def predict(X):
    """
    Predict OD600(t) using the modified Gompertz growth model (Zwietering et al., 1990)
    y(t) = y0 + A * exp( -exp( (mu_max * e / A) * (lambda_ - t) + 1 ) )

    Inputs:
    - X: 2-D numpy array with time in hours in column 0 (X[:,0])

    Returns:
    - 1-D numpy array with predicted OD600 values
    """
    t = np.asarray(X)[:, 0]

    # Typical default/fitted parameters for E. coli K-12 in rich media (placeholders)
    y0 = 0.02       # initial/background-subtracted OD600 at t ~ 0 [OD]
    A = 0.90        # asymptotic increase in OD600 (final OD ~ y0 + A) [OD]
    mu_max = 1.20   # maximum specific growth rate [1/h]
    lambda_ = 0.5   # lag time [h]

    # Modified Gompertz function
    inner = (mu_max * np.e / A) * (lambda_ - t) + 1.0
    od_increase = A * np.exp(-np.exp(inner))
    od = y0 + od_increase

    return od
