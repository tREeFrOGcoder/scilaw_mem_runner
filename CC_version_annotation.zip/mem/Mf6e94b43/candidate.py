import numpy as np

def predict(X):
    """
    Predict ln(m) for adult ages 30-95 using a Gompertz law with a linear
    period trend (the standard log-linear age-period Gompertz baseline):
    
        ln m_{x,t} = a0 + beta * (x - 50) + gamma * (t - 1950)
    
    where:
      beta  ~ Gompertz slope (~8.9% rise in m per year of adult age)
      gamma ~ annual decline in mortality level (~1.2% per year)
    """
    age = X[:, 0]
    year = X[:, 1]

    # Fitted constants (typical for total-sex, 1x1, developed-world mortality)
    beta = 0.085          # Gompertz age slope
    a0 = -5.6             # ln m at age 50, year 1950  (m ≈ 0.0037)
    gamma = -0.012        # period trend per calendar year

    x_centered = age - 50.0
    t_centered = year - 1950.0

    log_m_adult = a0 + beta * x_centered + gamma * t_centered
    return log_m_adult
