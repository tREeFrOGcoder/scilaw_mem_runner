import numpy as np

def predict(X):
    """
    Predicts the real part of the refractive index (n) as a function of 
    vacuum wavelength using the standard 3-term Sellmeier equation.
    
    The coefficients below correspond to the widely cited Sellmeier fit 
    for Silicon (Li 1980), which is based on precision minimum-deviation 
    goniometer measurements on single-crystal prisms (e.g., Bond 1965).
    """
    lam = X[:, 0]  # Wavelength in micrometers
    
    # Sellmeier coefficients
    B1 = 10.6684293
    C1 = 0.301516485**2  # ~0.090912
    
    B2 = 0.003043475
    C2 = 1.13475115**2   # ~1.287490
    
    B3 = 1.54133408
    C3 = 1104.0**2       # 1218816.0
    
    # 3-term Sellmeier equation
    n_sq = 1.0 + (B1 * lam**2) / (lam**2 - C1) \
               + (B2 * lam**2) / (lam**2 - C2) \
               + (B3 * lam**2) / (lam**2 - C3)
               
    return np.sqrt(n_sq)
