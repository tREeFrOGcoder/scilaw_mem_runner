import numpy as np

def predict(X):
    """
    Predicts the 10-minute-averaged active electrical power output [kW]
    from the 10-minute-averaged wind speed at hub height [m/s].

    Uses the standard piecewise power-curve model (cubic in Region 2).
    """
    v = X[:, 0]  # wind speed [m/s]

    # Typical turbine parameters (constants)
    CUT_IN = 3.0       # cut-in wind speed [m/s]
    RATED_SPEED = 12.0 # rated wind speed [m/s]
    CUT_OUT = 25.0     # cut-out wind speed [m/s]
    RATED_POWER = 2000.0  # rated power [kW] (example: 2 MW turbine)

    # Initialize output
    P = np.zeros_like(v)

    # Region 2: cubic power increase between cut-in and rated
    mask2 = (v >= CUT_IN) & (v <= RATED_SPEED)
    v_region = v[mask2]
    P[mask2] = RATED_POWER * (v_region**3 - CUT_IN**3) / (RATED_SPEED**3 - CUT_IN**3)

    # Region 3: constant rated power between rated and cut-out
    mask3 = (v > RATED_SPEED) & (v <= CUT_OUT)
    P[mask3] = RATED_POWER

    # Regions 1 & 4 (below cut-in and above cut-out) remain zero
    return P
