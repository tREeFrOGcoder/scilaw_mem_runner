USED_INPUTS = ['wind_speed_mps']
LAW_CONSTANTS = {'V_CI': 3.5, 'V_R': 14.0, 'V_CO': 25.0, 'P_R': 2050.0, 'CP_EQ': 0.4249}
OTHER_CONSTANTS = {'RHO': 1.225, 'A': 5281.0}
LOCAL_FITTABLE = {}

def predict(X: np.ndarray, V_CI: float=3.5, V_R: float=14.0, V_CO: float=25.0, P_R: float=2050.0, CP_EQ: float=0.4249) -> np.ndarray:
    v = np.asarray(X[:, 0], dtype=float)
    rho = OTHER_CONSTANTS['RHO']
    A = OTHER_CONSTANTS['A']
    P_cubic = 0.5 * rho * A * CP_EQ * v ** 3 / 1000.0
    return np.where((v < V_CI) | (v > V_CO), 0.0, np.where(v < V_R, P_cubic, P_R))
