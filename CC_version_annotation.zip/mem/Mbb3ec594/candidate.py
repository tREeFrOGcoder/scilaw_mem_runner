import numpy as np

def predict(X):
    """
    Predict dE/dX [PeV/(g/cm^2)] vs slant depth X using a canonical Gaisser-Hillas shape.
    Input: X is a 2-D numpy array with slant depth in column 0 (g/cm^2).
    Output: 1-D numpy array of dE/dX (PeV/(g/cm^2)).
    Notes: The numeric constants below are typical/default choices (can be tuned to data).
    """
    X = np.asarray(X)
    x = X[:, 0]

    # Canonical Gaisser-Hillas parameters (typical/placeholder values)
    X0 = -60.0        # effective first-interaction depth (g/cm^2)
    Xmax = 700.0      # depth of shower maximum (g/cm^2)
    lam = 70.0        # attenuation/shape parameter (g/cm^2)
    dEdX_max = 1.0    # peak energy deposit (PeV/(g/cm^2))

    # Avoid invalid bases for the power (ensure positive)
    denom = Xmax - X0
    base = (x - X0) / denom
    base = np.where(base > 0, base, 1e-12)

    # Gaisser-Hillas functional form for the longitudinal energy-deposit profile
    exponent = denom / lam
    dEdX = dEdX_max * (base ** exponent) * np.exp((Xmax - x) / lam)

    # Ensure strictly positive values within numerical limits
    dEdX = np.where(dEdX > 0, dEdX, 1e-12)

    return dEdX
