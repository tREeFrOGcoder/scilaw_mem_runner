USED_INPUTS = ['X']
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {'Xmax': {'init': None}, 'dEdX_max': {'init': None}, 'R': {'init': None}, 'L': {'init': None}}

def _normalized_profile(X_prime, R, L):
    base = 1.0 + R * X_prime / L
    exponent = R ** (-2.0)
    safe_base = np.where(base > 0.0, base, 0.0)
    exp_term = np.exp(-X_prime / (R * L))
    return np.where(base > 0.0, safe_base ** exponent * exp_term, 0.0)

def _profile(X, Xmax, dEdX_max, R, L):
    X_prime = X - Xmax
    return dEdX_max * _normalized_profile(X_prime, R, L)

def predict(X: np.ndarray, Xmax: float, dEdX_max: float, R: float, L: float) -> np.ndarray:
    X_arr = np.asarray(X[:, 0], dtype=float)
    return _profile(X_arr, Xmax, dEdX_max, R, L)
