import numpy as np


def predict(X):
    # Extract time since inoculation (hours)
    t = X[:, 0]

    # Standard parameters for E. coli K-12 BW25113 in a 96-well plate reader
    # (background-subtracted OD600)
    od_min = 0.02  # Initial background-subtracted OD600
    od_max = 0.85  # Asymptotic maximum OD600
    mu_max = 0.75  # Maximum specific growth rate (1/h)
    lag = 2.0  # Lag time (h)

    # Modified Gompertz model parameters
    A = od_max - od_min

    # Calculate the exponent term safely to avoid numerical overflow
    inner_term = (mu_max * np.e / A) * (lag - t) + 1
    inner_term = np.clip(inner_term, -50, 50)

    # Modified Gompertz equation
    od600 = od_min + A * np.exp(-np.exp(inner_term))

    return od600
