USED_INPUTS = ['n_qm']
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {'R_inf': 109737.316, 'Z_c': 1}
LOCAL_FITTABLE = {'delta_0': {'init': None}, 'a': {'init': None}, 'b': {'init': None}}

def _delta_ritz(n_qm, delta_0, a, b):
    n_qm = np.asarray(n_qm, dtype=float)
    n_star0 = n_qm - delta_0
    safe = np.where(np.abs(n_star0) > 1e-06, n_star0, 1e-06)
    return delta_0 + a / safe ** 2 + b / safe ** 4

def _binding_energy(n_qm, delta_0, a, b):
    R_inf = OTHER_CONSTANTS['R_inf']
    Z_c = OTHER_CONSTANTS['Z_c']
    n_qm = np.asarray(n_qm, dtype=float)
    delta = _delta_ritz(n_qm, delta_0, a, b)
    n_star = n_qm - delta
    n_star = np.where(n_star > 0.001, n_star, 0.001)
    return float(Z_c) ** 2 * R_inf / (n_star * n_star)

def predict(X: np.ndarray, delta_0: float, a: float, b: float) -> np.ndarray:
    n_qm = np.asarray(X[:, 0], dtype=float)
    return _binding_energy(n_qm, delta_0, a, b)
