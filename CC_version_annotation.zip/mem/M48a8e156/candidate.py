import numpy as np

def predict(X):
    """
    Predict binding energy (E_bind) in cm^-1 for Rydberg levels using the
    standard Rydberg formula with a quantum defect:
        E_bind = R_inf / (n - delta_l)**2

    Inputs:
    - X: 2-D numpy array with shape (N, 2)
        X[:,0] = n (principal quantum number)
        X[:,1] = l (orbital quantum number, integer 0=s,1=p,2=d,...)

    Notes:
    - This implements the canonical closed-form relation. The quantum defect
      delta_l depends on the atomic species and the particular series; here
      a set of commonly-cited default quantum-defect values for alkali-like
      atoms is used. For hydrogenic systems set delta=0.
    - R_inf is the Rydberg constant in cm^-1 for an infinite nuclear mass.

    Returns:
    - 1-D numpy array (length N) of binding energies in cm^-1.
    """
    X = np.asarray(X)
    if X.ndim == 1 and X.size == 2:
        X = X.reshape(1, 2)
    n = X[:, 0].astype(float)
    l = X[:, 1].astype(int)

    # Rydberg constant (in cm^-1) for infinite nuclear mass (R_infty)
    R_INF_CM1 = 109737.31568539

    # Default quantum defects (typical alkali-like values).
    # These are species-dependent; provided here as common examples.
    # l: 0=s,1=p,2=d,3=f,4=g,5=h
    QUANTUM_DEFECTS = {
        0: 1.35,    # delta_s (approximate)
        1: 0.85,    # delta_p (approximate)
        2: 0.015,   # delta_d (approximate, nearly hydrogenic)
        3: 0.0005,  # delta_f (very small)
        4: 0.0,
        5: 0.0
    }

    # Vectorized lookup: default to 0.0 for unknown l
    delta = np.array([QUANTUM_DEFECTS.get(int(li), 0.0) for li in l], dtype=float)

    # Prevent non-physical (n - delta) <= 0; produce NaN for those cases
    denom = n - delta
    with np.errstate(divide='ignore', invalid='ignore'):
        E_bind = R_INF_CM1 / (denom**2)
        E_bind = np.where(denom > 0, E_bind, np.nan)

    return E_bind.ravel()
