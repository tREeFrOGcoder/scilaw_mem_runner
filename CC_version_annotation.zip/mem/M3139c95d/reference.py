USED_INPUTS = ['M']
LAW_CONSTANTS = {'alpha_small': 0.55, 'alpha_large': 0.01, 'M_break': 124.0, 'R_break': 12.1}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {}

def predict(X: np.ndarray, alpha_small: float, alpha_large: float, M_break: float, R_break: float) -> np.ndarray:
    M = np.asarray(X[:, 0], dtype=float)
    C_small = R_break * M_break ** (-alpha_small)
    C_large = R_break * M_break ** (-alpha_large)
    R_small = C_small * np.power(M, alpha_small)
    R_large = C_large * np.power(M, alpha_large)
    return np.where(M <= M_break, R_small, R_large)
