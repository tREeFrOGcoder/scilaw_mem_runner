import numpy as np

def predict(X):
    # Log-linear spirometry prediction (Quanjer/GLI-style form)
    # FVC = exp(a + b*ln(height_cm) + c*ln(age_yr))
    a = -10.30
    b = 2.20
    c = 0.15

    age = np.asarray(X[:, 0], dtype=float)
    height = np.asarray(X[:, 1], dtype=float)

    ln_h = np.log(height)
    ln_t = np.log(age)

    fvc = np.exp(a + b * ln_h + c * ln_t)
    return fvc
