USED_INPUTS = ['log_distance_km']
LAW_CONSTANTS = {'A': -0.08523, 'B': 0.01892}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {}

def predict(X: np.ndarray, A: float=-0.08523, B: float=0.01892) -> np.ndarray:
    log_d = np.asarray(X[:, 0], dtype=float)
    return A + B * log_d
