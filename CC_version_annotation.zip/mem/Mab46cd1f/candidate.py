import numpy as np

def predict(X):
    log_d = X[:, 0]
    # Rousset's isolation-by-distance model: M = F_ST / (1 - F_ST) = a + b * ln(d)
    a = 0.0
    b = 0.01
    M = a + b * log_d
    return M
