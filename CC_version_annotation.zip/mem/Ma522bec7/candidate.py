import numpy as np

def predict(X):
    # Mincer earnings equation: log_wage = β0 + β1 * SCHL_years + β2 * exp + β3 * exp^2
    # Typical coefficients from labor economics literature
    beta_0 = 6.2      # intercept
    beta_1 = 0.10     # return to schooling (approx 10% per year)
    beta_2 = 0.04     # linear experience term
    beta_3 = -0.0007  # quadratic experience term (diminishing returns)
    
    s = X[:, 0]  # years of schooling
    x = X[:, 1]  # years of potential experience
    
    log_wage = beta_0 + beta_1 * s + beta_2 * x + beta_3 * (x ** 2)
    return log_wage
