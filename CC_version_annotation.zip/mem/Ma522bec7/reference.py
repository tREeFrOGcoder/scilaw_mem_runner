USED_INPUTS = ['SCHL_years', 'exp']
LAW_CONSTANTS = {'alpha': 8.888690024317656, 'rho_s': 0.11130553854535347, 'beta_0': 0.02864629358148585, 'beta_1': -0.00037876090477542945}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {}

def predict(X: np.ndarray, alpha: float, rho_s: float, beta_0: float, beta_1: float) -> np.ndarray:
    X = np.asarray(X, dtype=np.float64)
    s = X[:, 0]
    x = X[:, 1]
    return alpha + rho_s * s + beta_0 * x + beta_1 * x ** 2
