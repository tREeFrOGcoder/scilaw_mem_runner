import numpy as np

def predict(X):
    N = X[:, 0]
    # Bleasdale (1960) power-law yield-density model: w = a * N^(-b)
    a = 1.0  # Named constant / placeholder for fitted intercept
    b = 1.0  # Named constant / placeholder for fitted scaling exponent
    
    w = a * (N ** -b)
    return w
