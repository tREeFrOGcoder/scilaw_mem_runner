import numpy as np

def predict(X):
    X = np.asarray(X, dtype=float)
    M = X[:, 0]          # total gravitational mass in Msun
    kappa2T = X[:, 2]    # combined tidal coupling constant

    # Common quasi-universal Bernuzzi-type quadratic fit:
    #     (M f2) = a0 + a1*(kappa2T/100) + a2*(kappa2T/100)^2
    # where M f2 is dimensionless in geometric units.
    x = kappa2T / 100.0
    a0 = 5.832e-2
    a1 = -1.118e-2
    a2 = 7.970e-4

    Mf2 = a0 + a1 * x + a2 * x**2

    # Convert from geometric units to kHz:
    # 1 Msun = G*Msun/c^3 = 4.925490947 microseconds
    M_sun_seconds = 4.925490947e-6
    f2_kHz = Mf2 / (M * M_sun_seconds) / 1.0e3

    return f2_kHz
