USED_INPUTS = ['mass', 'm1', 'm2', 'kap2t']
LAW_CONSTANTS = {'a0': 0.0899, 'aM_1': 31.02, 'aT_1': 0.0294, 'bT_1': 1.13, 'aT_2': 3.78e-05, 'bT_2': -0.99, 'aT_3': 0.0575, 'bT_3': 39.99, 'aT_4': 0.000277, 'bT_4': 27.77}
OTHER_CONSTANTS = {'GM_SUN_C3': 4.925490947e-06}
LOCAL_FITTABLE = {}

def predict(X: np.ndarray, a0: float, aM_1: float, aT_1: float, bT_1: float, aT_2: float, bT_2: float, aT_3: float, bT_3: float, aT_4: float, bT_4: float) -> np.ndarray:
    GM_SUN_C3 = OTHER_CONSTANTS['GM_SUN_C3']
    X = np.asarray(X, dtype=float)
    mass = X[:, 0]
    m1 = X[:, 1]
    m2 = X[:, 2]
    kap2t = X[:, 3]
    nu = m1 * m2 / (mass * mass)
    Xv = 1.0 - 4.0 * nu
    Q_M = 1.0 + aM_1 * Xv
    Q_S = 1.0
    pT1 = aT_1 * (1.0 + bT_1 * Xv)
    pT2 = aT_2 * (1.0 + bT_2 * Xv)
    pT3 = aT_3 * (1.0 + bT_3 * Xv)
    pT4 = aT_4 * (1.0 + bT_4 * Xv)
    kT2 = kap2t * kap2t
    Q_T = (1.0 + pT1 * kap2t + pT2 * kT2) / (1.0 + pT3 * kap2t + pT4 * kT2)
    Mf2 = a0 * Q_M * Q_S * Q_T
    return Mf2 / (mass * GM_SUN_C3) / 1000.0
