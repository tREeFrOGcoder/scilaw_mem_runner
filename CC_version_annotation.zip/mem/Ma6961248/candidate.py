import numpy as np

def predict(X):
    nu_max = X[:, 0]
    Teff = X[:, 1]
    FeH = X[:, 2]
    phase = X[:, 3]

    # Standard asteroseismic scaling relation:
    # Δν ≈ Δν_sun * (ν_max / ν_max,sun)^(3/4) * (T_eff / T_eff,sun)^(3/8)
    # with a simple phase-dependent correction factor for red-giant branch vs core-He burning.
    dnu_sun = 135.1  # uHz
    numax_sun = 3090.0  # uHz
    teff_sun = 5777.0  # K

    dnu = dnu_sun * (nu_max / numax_sun) ** 0.75 * (Teff / teff_sun) ** 0.375

    # Mild empirical adjustment by evolutionary phase:
    # 0 = unclassified, 1 = RGB, 2 = HeB.
    # RGB stars tend to lie slightly below the pure scaling relation,
    # while HeB stars tend to lie slightly above it.
    corr = np.ones_like(dnu)
    corr = np.where(phase == 1, 0.98, corr)
    corr = np.where(phase == 2, 1.02, corr)

    return dnu * corr
