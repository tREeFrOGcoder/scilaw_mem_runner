import numpy as np

def predict(X):
    m = X[:, 0]  # mass in kg
    S = X[:, 1]  # wing area in m^2
    
    # Constants
    C_L = 2.0  # Lift coefficient, typical value for flapping flight
    rho = 1.225  # Sea-level air density in kg/m^3
    
    # Mean equivalent airspeed formula: Ue = sqrt((2 * m * g) / (rho * S * C_L))
    g = 9.81  # Acceleration due to gravity in m/s^2
    Ue = np.sqrt((2 * m * g) / (rho * S * C_L))
    
    return Ue
