USED_INPUTS = ['cases_prev', 'biweek', 'z_t', 'log_pop']
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {'b0': {'init': None}, 'b1': {'init': None}, 'b2': {'init': None}, 'alpha': {'init': None}, 'sbar_frac': {'init': None}}

def _log_pred(cases_prev, biweek, z_t, log_pop, b0, b1, b2, alpha, sbar_frac):
    omega = 2.0 * np.pi / 26.0
    s = biweek.astype(float)
    log_beta = b0 + b1 * np.cos(omega * s) + b2 * np.sin(omega * s)
    log_i = alpha * np.log(np.clip(cases_prev, 0.0, None) + 1.0)
    N = np.power(10.0, log_pop)
    s_pool = np.clip(z_t + sbar_frac * N, 1e-06, None)
    return log_beta + log_i + np.log(s_pool)

def predict(X: np.ndarray, b0: float, b1: float, b2: float, alpha: float, sbar_frac: float) -> np.ndarray:
    cases_prev = np.asarray(X[:, 0], dtype=float)
    biweek = np.asarray(X[:, 1], dtype=float)
    z_t = np.asarray(X[:, 2], dtype=float)
    log_pop = np.asarray(X[:, 3], dtype=float)
    return np.clip(np.exp(_log_pred(cases_prev, biweek, z_t, log_pop, b0, b1, b2, alpha, sbar_frac)) - 1.0, 0.0, None)
