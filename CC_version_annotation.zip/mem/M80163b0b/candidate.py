import numpy as np

def predict(X):
    # Standard historical measles "seasonally forced susceptible-incidence" form:
    # I_t = beta_t * I_{t-1} * (z_t / N)
    # with beta_t often modeled as a seasonal term.
    #
    # Here we use a common closed-form approximation for the seasonal contact rate:
    # beta_t = beta0 + beta1 * cos(2*pi*s/26)
    #
    # and N = 10^(log_pop).

    I_prev = X[:, 0]
    s = X[:, 1]
    B = X[:, 2]
    log_pop = X[:, 3]
    z = X[:, 4]

    N = 10.0 ** log_pop

    # Canonical seasonal forcing for measles transmission
    beta0 = 2.5
    beta1 = 1.5
    beta_t = beta0 + beta1 * np.cos(2.0 * np.pi * s / 26.0)

    I_t = beta_t * I_prev * (z / N)

    # Cases cannot be negative
    return np.maximum(I_t, 0.0)
