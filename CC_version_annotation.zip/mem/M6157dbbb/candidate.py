import numpy as np

def predict(X):
    # Constants
    g = 9.81  # acceleration due to gravity in m/s^2

    # Inputs
    R_m = X[:, 0]  # Hydraulic depth (m)
    S_f = X[:, 1]  # Channel bed slope (dimensionless)

    # Manning's equation for velocity in an open channel flow
    # V = (1/n) * R^(2/3) * S_f^(1/2) 
    # Assuming a common roughness coefficient n = 0.033 for natural channels
    n = 0.033

    V = (1/n) * (R_m**(2/3)) * (S_f**0.5)

    return V
