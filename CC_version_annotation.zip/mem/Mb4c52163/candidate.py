import numpy as np

def predict(X):
    log_P = X[:, 0]
    feh = X[:, 1]
    
    # Canonical Period-Luminosity-Metallicity (PLZ) relation for
    # Classical Cepheids in the Gaia Wesenheit magnitude system.
    # Form: M_W = a*(log P - 1) + gamma*[Fe/H] + zp
    # Coefficients from Riess et al. / SH0ES calibrations
    # (e.g., Riess et al. 2019, 2021; Breuval et al. 2024)
    a = -3.31        # period slope  [mag / dex(log P)]
    gamma = -0.20    # metallicity slope [mag / dex]
    zp = -5.93       # zero-point at log P = 1, [Fe/H] = 0 [mag]
    
    M_W = a * (log_P - 1.0) + gamma * feh + zp
    return M_W
