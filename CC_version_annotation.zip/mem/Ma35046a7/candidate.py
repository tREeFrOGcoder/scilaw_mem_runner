import numpy as np

def predict(X):
    """
    Predict summertime thermocline depth z_t [m] from lake surface area A_s [km^2]
    and maximum depth Z_max [m].

    Inputs:
    - X: 2-D numpy array with shape (n_samples, 2)
         column 0: A_s_km2 (lake surface area in km^2)
         column 1: Z_max_m  (lake maximum depth in m)

    Output:
    - 1-D numpy array of predicted thermocline depths z_t [m], rounded to the
      nearest 0.5 m to reflect the 0.5 m interpolation grid of the source data.
    """
    X = np.asarray(X, dtype=float)
    if X.ndim != 2 or X.shape[1] < 2:
        raise ValueError("X must be a 2-D array with at least two columns: [A_s_km2, Z_max_m].")

    A_s = X[:, 0]
    Z_max = X[:, 1]

    # Prevent non-physical or zero/negative values from causing issues
    A_s = np.maximum(A_s, 1e-6)
    Z_max = np.maximum(Z_max, 0.0)

    # Empirical power-law relationship (area-driven), with Z_max as physical upper bound.
    # Coefficients chosen as a commonly used simple scaling: z_t = alpha * A_s^beta
    alpha = 2.0   # scaling factor (m)
    beta = 0.35   # exponent on area

    z_pred = alpha * (A_s ** beta)

    # Enforce physical upper bound by maximum depth
    z_pred = np.minimum(z_pred, Z_max)

    # Round to nearest 0.5 m to match the dataset grid resolution
    z_pred = np.round(z_pred * 2.0) / 2.0

    return z_pred
