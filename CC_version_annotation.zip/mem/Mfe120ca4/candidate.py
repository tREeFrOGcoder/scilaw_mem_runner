import numpy as np

def predict(X):
    c = X[:, 0]  # concentration [g/L]
    l = X[:, 1]  # path length [cm]
    
    # Beer-Lambert Law: A = epsilon * c_molar * l
    # Convert mass concentration to molar concentration:
    #   c_molar [mol/L] = c [g/L] / M [g/mol]
    
    M = 294.185  # Molar mass of K2Cr2O7 [g/mol]
    
    # Molar absorptivity at 350 nm (commonly used reference wavelength
    # for potassium dichromate spectrophotometric standards)
    epsilon = 315.0  # [L / (mol * cm)]
    
    # Specific absorptivity: a = epsilon / M  [L / (g * cm)]
    a = epsilon / M
    
    A = a * c * l
    return A
