import numpy as np

def predict(X):
    X = np.asarray(X, dtype=float)

    T_ei = X[:, 0]
    T_ci = X[:, 1]
    Q_e  = X[:, 2]

    # Gordon-Ng universal chiller model coefficients, to be fitted/calibrated
    A = 0.0
    B = 0.0
    C = 0.0

    return -2.0 + T_ci / T_ei + (T_ci / Q_e) * (A + B * Q_e + C * Q_e**2)
