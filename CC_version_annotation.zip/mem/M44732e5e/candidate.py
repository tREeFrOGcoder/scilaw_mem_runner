import numpy as np

def predict(X):
    X = np.asarray(X)
    delta_nu = X[:, 0]  # μHz

    # Empirical red-giant solar-like oscillation scaling:
    # Δν = 0.263 * ν_max^0.772  with Δν and ν_max in μHz
    alpha = 0.263
    beta = 0.772

    nu_max = (delta_nu / alpha) ** (1.0 / beta)
    return nu_max
