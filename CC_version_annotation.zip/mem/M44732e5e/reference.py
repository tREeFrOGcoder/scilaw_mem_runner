USED_INPUTS = ['delta_nu']
LAW_CONSTANTS = {'A': 0.267, 'beta': 0.764}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {}

def predict(X: np.ndarray, A: float, beta: float) -> np.ndarray:
    delta_nu = np.asarray(X[:, 0], dtype=float)
    return (delta_nu / float(A)) ** (1.0 / float(beta))
