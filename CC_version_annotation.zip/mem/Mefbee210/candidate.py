import numpy as np

def predict(X):
    rho = X[:, 0]
    D = X[:, 1]
    H = X[:, 2]
    
    # Chave et al. (2014) pantropical allometric equation including tree height
    agb_kg = 0.0673 * (rho * D**2 * H)**0.976
    
    return agb_kg
