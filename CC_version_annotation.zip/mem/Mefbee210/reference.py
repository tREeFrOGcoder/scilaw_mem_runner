USED_INPUTS = ['wood_density', 'diameter_cm', 'height_m']
LAW_CONSTANTS = {'c': 0.0673, 'alpha': 0.976}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {}

def predict(X: np.ndarray, c: float, alpha: float) -> np.ndarray:
    rho = np.asarray(X[:, 0], dtype=float)
    D = np.asarray(X[:, 1], dtype=float)
    H = np.asarray(X[:, 2], dtype=float)
    return c * np.power(rho * D ** 2 * H, alpha)
