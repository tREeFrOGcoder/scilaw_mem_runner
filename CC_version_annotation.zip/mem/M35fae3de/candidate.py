import numpy as np

def predict(X):
    """
    Predict cross-section mean velocity V_mps [m/s] from hydraulic depth and slope
    using Manning's equation (closed-form).
    
    V = (1/n) * R^(2/3) * sqrt(S)
    
    Inputs:
    - X: 2-D numpy array where
        X[:,0] = R_m (hydraulic depth, m)
        X[:,1] = SLOPE (dimensionless)
    
    Notes:
    - A default Manning's n = 0.035 (typical natural channel) is used.
    - Negative slopes are clipped to zero to avoid complex results.
    - Returns a 1-D numpy array of V (m/s).
    """
    X = np.asarray(X)
    if X.ndim == 1:
        X = X.reshape(1, -1)
    R = X[:, 0].astype(float)
    S = X[:, 1].astype(float)
    # enforce non-negative physical inputs
    R = np.maximum(R, 0.0)
    S = np.maximum(S, 0.0)
    MANNING_N = 0.035  # typical default roughness for natural channels
    V = (1.0 / MANNING_N) * (R ** (2.0 / 3.0)) * np.sqrt(S)
    return V
