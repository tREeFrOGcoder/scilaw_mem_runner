USED_INPUTS = ['R_m', 'SLOPE']
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {'k_n': 1.0}
LOCAL_FITTABLE = {'n': {'init': None}}

def _velocity(R_m, SLOPE, n):
    R_safe = np.clip(R_m, 0.0, None)
    S_safe = np.clip(SLOPE, 0.0, None)
    return _K_N / n * R_safe ** (2.0 / 3.0) * S_safe ** 0.5

def predict(X: np.ndarray, n: float) -> np.ndarray:
    R_m = np.asarray(X[:, 0], dtype=float)
    SLOPE = np.asarray(X[:, 1], dtype=float)
    V = _velocity(R_m, SLOPE, n)
    return np.clip(V, 0.0, None)
