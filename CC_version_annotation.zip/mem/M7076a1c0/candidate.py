import numpy as np

def predict(X):
    n = X[:, 0]
    R_y = 109737.315  # Rydberg constant in cm^-1
    return R_y / (n ** 2)
