import numpy as np

def predict(X):
    """
    Predict FEV1 (L) from age (years) and height (cm) using the Johnson (2023) equation.
    X: 2-D numpy array of shape (n, 2), where
        X[:, 0] = age (yr)
        X[:, 1] = height_cm (cm)
    Returns: 1-D numpy array of FEV1 (L).
    """
    age = X[:, 0]
    height = X[:, 1]
    # Johnson (2023) closed-form: FEV1 = 0.039 * height - 0.029 * age - 2.1
    return 0.039 * height - 0.029 * age - 2.1
