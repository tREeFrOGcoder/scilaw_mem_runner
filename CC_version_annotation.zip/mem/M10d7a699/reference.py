USED_INPUTS = ['age', 'height_cm']
LAW_CONSTANTS = {'b0': 0.777, 'b1': -0.00921, 'b2': -0.0001374, 'b3': 0.00010647}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {}

def predict(X: np.ndarray, b0: float, b1: float, b2: float, b3: float) -> np.ndarray:
    X = np.asarray(X, dtype=float)
    age = X[:, 0]
    height = X[:, 1]
    return b0 + b1 * age + b2 * age * age + b3 * height * height
