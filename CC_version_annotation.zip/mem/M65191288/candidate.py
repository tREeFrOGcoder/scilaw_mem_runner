import numpy as np

def predict(X):
    """
    Predict fluorometric enzyme activity rate v [nmol g^-1 h^-1]
    from substrate concentration S [uM] using the standard
    Michaelis–Menten equation: v = Vmax * S / (Km + S).

    Parameters
    ----------
    X : np.ndarray, shape (n_samples, 1)
        X[:, 0] = substrate_conc (S) in uM.

    Returns
    -------
    v : np.ndarray, shape (n_samples,)
        Predicted activity rate in nmol g^-1 h^-1.
    """
    # Extract substrate concentration
    S = X[:, 0]

    # Typical Michaelis–Menten parameters for soil fluorometric assays
    # (e.g., β-glucosidase, acid phosphatase, leucine aminopeptidase).
    # These are representative values; actual values would be obtained
    # by fitting to calibration data.
    Vmax = 500.0   # nmol g^-1 h^-1
    Km = 100.0     # uM

    # Michaelis–Menten rate equation
    v = Vmax * S / (Km + S)
    return v
