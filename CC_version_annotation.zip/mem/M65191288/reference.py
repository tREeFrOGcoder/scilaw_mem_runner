USED_INPUTS = ['substrate_conc']
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {'V_max': {'init': None}, 'K_m': {'init': None}}

def _mm_rate(S, V_max, K_m):
    return V_max * S / (K_m + S)

def predict(X: np.ndarray, V_max: float, K_m: float) -> np.ndarray:
    S = np.asarray(X[:, 0], dtype=float)
    return _mm_rate(S, V_max, K_m)
