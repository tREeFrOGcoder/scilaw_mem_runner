USED_INPUTS = ['MER_kg_per_s']
LAW_CONSTANTS = {'A': 0.6681, 'B': 0.1753}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {}

def predict(X: np.ndarray, A: float=0.6681, B: float=0.1753) -> np.ndarray:
    MER = np.asarray(X[:, 0], dtype=float)
    return A * MER ** B
