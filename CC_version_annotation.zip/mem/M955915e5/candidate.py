import numpy as np

def predict(X):
    # X[:, 0] is the Mass Eruption Rate (MER) in kg/s
    mer = X[:, 0]
    
    # Mastin et al. (2009) empirical relation: 
    # H = 2.00 * Q^0.241, where Q is the volumetric flow rate in m^3/s (DRE).
    # Assuming a standard magma dense-rock equivalent (DRE) density of 2500 kg/m^3:
    rho = 2500.0
    q = mer / rho
    
    # Calculate column height above vent level (H_top) in km
    h_top = 2.00 * (q ** 0.241)
    
    return h_top
