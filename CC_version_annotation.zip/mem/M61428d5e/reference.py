USED_INPUTS = ['C1']
LAW_CONSTANTS = {'a0': 0.118824, 'a1': 0.142985, 'a2': 40.896317}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {}

def predict(X, a0=LAW_CONSTANTS['a0'], a1=LAW_CONSTANTS['a1'], a2=LAW_CONSTANTS['a2']):
    C1 = np.asarray(X[:, 0], dtype=float)
    return a0 - a1 * np.sin(np.sin(a2 * C1))
