import numpy as np

def predict(X):
    M1 = X[:, 0]
    M2 = X[:, 1]
    C1 = X[:, 2]
    C2 = X[:, 3]
    q = X[:, 4]
    Lambda_tilde = X[:, 5]
    
    # Calculate M_disk based on a commonly cited empirical relationship
    M_disk = (0.1 * (M1 + M2) * (1 + 0.5 * (C1 + C2) * (1 - q))) + (1.0 / Lambda_tilde) * (M1 + M2)
    
    return M_disk
