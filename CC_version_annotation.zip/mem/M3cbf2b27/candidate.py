import numpy as np

def predict(X):
    """
    Predicts the Voigt-Reuss-Hill average polycrystalline bulk modulus K_VRH (in GPa)
    using an empirical, physically-informed scaling relationship based on 
    atomic volume, average atomic mass, density, and crystal system.
    
    Inputs:
    X[:, 0] = V_atomic_A3 (V_a) [angstrom^3]
    X[:, 1] = M_avg_amu (M_avg) [amu]
    X[:, 2] = density_g_cm3 (rho) [g/cm^3]
    X[:, 3] = crystal_system_id (cs) [2 to 7]
    """
    V_a = X[:, 0]
    M_avg = X[:, 1]
    rho = X[:, 2]
    cs = X[:, 3]
    
    # Empirical power-law relationship incorporating atomic packing,
    # elemental mass, mass density, and structural symmetry.
    ln_K = 7.8 - 1.4 * np.log(V_a) - 0.1 * np.log(M_avg) + 0.4 * np.log(rho) + 0.05 * cs
    K_VRH = np.exp(ln_K)
    
    return K_VRH
