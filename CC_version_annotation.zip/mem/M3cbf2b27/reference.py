USED_INPUTS = ['V_atomic_A3', 'crystal_system_id']
LAW_CONSTANTS = {'anderson_nafe_exponent': -4.0 / 3.0}
OTHER_CONSTANTS = {'a_by_csid_1': 3.677239, 'a_by_csid_2': 3.671468, 'a_by_csid_3': 3.674551, 'a_by_csid_4': 3.705846, 'a_by_csid_5': 3.609841, 'a_by_csid_6': 3.67535, 'a_by_csid_7': 3.675828, 'a_global': 3.677239}
LOCAL_FITTABLE = {}

def predict(X: np.ndarray, anderson_nafe_exponent: float) -> np.ndarray:
    V = np.asarray(X[:, 0], dtype=float)
    csid = np.asarray(X[:, 1], dtype=np.int64)
    a_table = {1: OTHER_CONSTANTS['a_by_csid_1'], 2: OTHER_CONSTANTS['a_by_csid_2'], 3: OTHER_CONSTANTS['a_by_csid_3'], 4: OTHER_CONSTANTS['a_by_csid_4'], 5: OTHER_CONSTANTS['a_by_csid_5'], 6: OTHER_CONSTANTS['a_by_csid_6'], 7: OTHER_CONSTANTS['a_by_csid_7']}
    a_global = OTHER_CONSTANTS['a_global']
    a = np.full(csid.shape, a_global, dtype=np.float64)
    for k, v in a_table.items():
        a[csid == k] = v
    V_safe = np.where(V > 0, V, 1e-09)
    log10K = a + anderson_nafe_exponent * np.log10(V_safe)
    return np.power(10.0, log10K)
