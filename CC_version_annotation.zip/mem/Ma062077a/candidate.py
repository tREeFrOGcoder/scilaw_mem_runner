import numpy as np

def predict(X):
    k = X[:, 0]
    
    # Parameters for the triangular fundamental diagram (Daganzo, 1995)
    v_f = 100.0  # Free-flow speed (km/h)
    w = 20.0     # Backward congestion wave speed (km/h)
    k_j = 210.0  # Jam density (veh/km/lane)
    
    # Triangular fundamental diagram: q = min(v_f * k, w * (k_j - k))
    q = np.minimum(v_f * k, w * (k_j - k))
    
    # Ensure non-negative flow
    return np.maximum(q, 0.0)
