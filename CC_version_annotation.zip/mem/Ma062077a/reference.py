USED_INPUTS = ['k_veh_km_lane']
LAW_CONSTANTS = {'V_F': 28.3826, 'Q_CAP': 2770.641, 'W': 15.9268, 'K_JAM': 415.6429}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {}

def predict(X: np.ndarray, V_F: float=28.3826, Q_CAP: float=2770.641, W: float=15.9268, K_JAM: float=415.6429) -> np.ndarray:
    k = np.asarray(X[:, 0], dtype=float)
    return np.minimum(V_F * k, np.minimum(Q_CAP, W * (K_JAM - k)))
