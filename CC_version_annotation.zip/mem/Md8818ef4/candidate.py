import numpy as np

def predict(X):
    # Unpack inputs
    SWdown = X[:, 0]        # W m^-2
    VPD = X[:, 1]           # kPa
    Tair = X[:, 2]          # K
    # RH = X[:, 3]          # not needed (VPD already provided)
    # Wind = X[:, 4]        # not needed (Ga already provided)
    Rnet = X[:, 5]          # W m^-2
    Qg = X[:, 6]            # W m^-2
    LAI = X[:, 7]           # m^2 m^-2
    # LWdown = X[:, 8]      # not needed (Rnet already provided)
    Ga = X[:, 9]            # m s^-1
    delta = X[:, 10]        # kPa K^-1
    # theta_FC = X[:, 11]   # not used (no observed soil moisture)
    # theta_WP = X[:, 12]   # not used

    # Physical constants
    gamma = 0.066           # psychrometric constant [kPa K^-1]
    rho = 1.2               # air density [kg m^-3]
    cp = 1010.0             # specific heat of air [J kg^-1 K^-1]
    g_max = 0.006           # maximum leaf stomatal conductance [m s^-1]

    # Jarvis-type environmental stress factors (multiplicative)
    f_rad = SWdown / (SWdown + 200.0)                 # light response
    f_vpd = 1.0 / (1.0 + VPD / 1.5)                   # VPD response (Leuning-type)
    f_temp = np.exp(-((Tair - 298.15) / 15.0)**2)     # temperature response
    # Soil moisture stress omitted because instantaneous θ is not provided

    # Canopy (surface) conductance [m s^-1]
    Gc = LAI * g_max * f_rad * f_vpd * f_temp
    Gc = np.maximum(Gc, 1e-6)  # avoid division by zero

    # Available energy [W m^-2]
    A = Rnet - Qg

    # Convert kPa-based quantities to Pa for unit consistency
    delta_Pa = delta * 1000.0
    gamma_Pa = gamma * 1000.0
    VPD_Pa = VPD * 1000.0

    # Penman-Monteith equation
    # λE = [Δ (Rn - G) + ρ cp Ga VPD] / [Δ + γ (1 + Ga/Gc)]
    numerator = delta_Pa * A + rho * cp * Ga * VPD_Pa
    denominator = delta_Pa + gamma_Pa * (1.0 + Ga / Gc)
    LE = numerator / denominator

    return LE
