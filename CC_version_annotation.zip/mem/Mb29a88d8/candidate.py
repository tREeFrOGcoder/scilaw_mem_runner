import numpy as np

def predict(X):
    phi = np.clip(X[:, 0], 1e-6, 1.0 - 1e-6)
    # Kozeny-Carman porosity-permeability relationship (reference-state form)
    k_ref = 100.0      # mD
    phi_ref = 0.20     # fraction
    k = k_ref * (phi / phi_ref)**3 * ((1.0 - phi_ref) / (1.0 - phi))**2
    return np.log10(k)
