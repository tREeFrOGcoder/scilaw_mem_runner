import numpy as np

def predict(X):
    """
    Predict ln S(p) — the natural log of the top p share of pre-tax national income —
    using a standard inverted-Pareto relationship with a slope that varies by year and region.

    The canonical form is: ln S(p) = (1 - 1/alpha) * ln p
    where (1 - 1/alpha) is modelled as a linear function of year and region fixed effects.

    Parameters
    ----------
    X : np.ndarray, shape (n_samples, 4)
        Columns:
        0 - log_p_above (ln p)
        1 - top_pct (100p)  [redundant, not used]
        2 - year
        3 - region (string or integer-coded categorical)

    Returns
    -------
    np.ndarray, shape (n_samples,)
        ln S(p) for each row.
    """
    log_p = X[:, 0]
    year = X[:, 2]
    region = X[:, 3].astype(str)          # ensure string for comparison

    # region offset relative to Americas (empirically plausible values)
    offsets = {
        'Africa':   0.10,
        'Americas': 0.00,
        'Asia':     0.05,
        'Europe':   0.08,
        'Oceania':  0.07
    }

    # compute region effect for each observation
    region_effect = np.zeros_like(year)
    for reg in np.unique(region):
        if reg in offsets:
            region_effect[region == reg] = offsets[reg]
        # if an unknown region appears, leave offset as 0.0

    # beta = 1 - 1/alpha, linear time trend + region effect
    # base: Americas in 2000 -> beta = 0.37, annual change -0.002
    beta = 0.37 - 0.002 * (year - 2000.0) + region_effect

    ln_S = beta * log_p
    return ln_S
