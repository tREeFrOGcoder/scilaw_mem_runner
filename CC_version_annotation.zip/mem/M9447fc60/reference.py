USED_INPUTS = ['log_p_above']
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {'a': {'init': None}, 'b': {'init': None}}

def predict(X: np.ndarray, a: float, b: float) -> np.ndarray:
    log_p = np.asarray(X[:, 0], dtype=float)
    return a + b * log_p
