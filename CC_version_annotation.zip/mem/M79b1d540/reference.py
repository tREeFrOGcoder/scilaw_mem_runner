USED_INPUTS = ['log10_conc_ppb']
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {'alpha': {'init': None}, 'beta': {'init': None}}

def _probit_mortality(log10_x, alpha, beta):
    return ndtr(alpha + beta * log10_x)

def predict(X: np.ndarray, alpha: float, beta: float) -> np.ndarray:
    log10_x = np.asarray(X[:, 0], dtype=float)
    return _probit_mortality(log10_x, alpha, beta)
