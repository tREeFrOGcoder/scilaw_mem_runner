import numpy as np

def predict(X):
    x = np.asarray(X)
    log10_C = x[:, 0]

    # Standard dose-mortality probit model:
    # probit(P) = alpha + beta * log10(C)
    alpha = 0.0
    beta = 1.0

    z = alpha + beta * log10_C

    # Normal CDF approximation: P = Phi(z)
    t = 1.0 / (1.0 + 0.2316419 * np.abs(z))
    d = 0.3989422804014327 * np.exp(-0.5 * z * z)
    p = 1.0 - d * (
        1.330274429 * t
        - 1.821255978 * t**2
        + 1.781477937 * t**3
        - 0.356563782 * t**4
        + 0.319381530 * t**5
    )
    P = np.where(z >= 0, p, 1.0 - p)

    return np.clip(P, 0.0, 1.0)
