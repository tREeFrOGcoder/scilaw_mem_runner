import numpy as np

def predict(X):
    # Canonical Pareto-style top-share relationship:
    #   S(p) ≈ exp(a + b*ln p + c*t + region FE)
    # Here we use the most standard closed-form approximation for log top share:
    #   ln S(p) = alpha + beta * ln(p)
    # with optional weak time/region adjustments omitted as generic placeholders.
    #
    # Since no data are provided, this is a standard theoretical/log-linear form,
    # not a fitted empirical WID-specific model.

    log_p = X[:, 0].astype(float)
    year = X[:, 2].astype(float)
    region = X[:, 3]

    # Baseline Pareto-log share elasticity:
    # In top-share applications, beta is typically positive and around 0.7-1.0
    # depending on income definition and upper-tail concentration.
    alpha = -0.35
    beta = 0.85

    # Mild secular trend placeholder centered around 2000
    gamma = 0.002
    year_centered = year - 2000.0

    # Region fixed effects (generic placeholders for WID macro-regions)
    region_fe = {
        "Europe": 0.00,
        "Asia": -0.03,
        "Africa": -0.05,
        "Americas": 0.02,
        "Oceania": -0.01,
    }

    # Support both string-like and numeric region codes by falling back to 0.0
    reg_adj = np.array([region_fe.get(str(r), 0.0) for r in region], dtype=float)

    return alpha + beta * log_p + gamma * year_centered + reg_adj
