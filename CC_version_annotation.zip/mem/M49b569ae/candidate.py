import numpy as np

def predict(X):
    Q2 = np.asarray(X)[:, 0]
    # Arrington (2007) parameterization for GEp / GD
    return 1.0 - 0.24 * Q2 + 0.09 * Q2**2
