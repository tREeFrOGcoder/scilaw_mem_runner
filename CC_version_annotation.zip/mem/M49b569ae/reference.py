USED_INPUTS = ['Q2_GeV2']
LAW_CONSTANTS = {'a1': 3.439, 'a2': -1.602, 'a3': 0.068, 'b1': 15.055, 'b2': 48.061, 'b3': 99.304, 'b4': 0.012, 'b5': 8.65}
OTHER_CONSTANTS = {'M_p': 0.938, 'Lambda2': 0.71}
LOCAL_FITTABLE = {}

def predict(X: np.ndarray, a1: float, a2: float, a3: float, b1: float, b2: float, b3: float, b4: float, b5: float) -> np.ndarray:
    M_p = OTHER_CONSTANTS['M_p']
    Lambda2 = OTHER_CONSTANTS['Lambda2']
    Q2 = np.asarray(X[:, 0], dtype=float)
    tau = Q2 / (4.0 * M_p * M_p)
    num = 1.0 + a1 * tau + a2 * tau ** 2 + a3 * tau ** 3
    den = 1.0 + b1 * tau + b2 * tau ** 2 + b3 * tau ** 3 + b4 * tau ** 4 + b5 * tau ** 5
    G_E = num / den
    G_D = (1.0 + Q2 / Lambda2) ** (-2.0)
    return G_E / G_D
