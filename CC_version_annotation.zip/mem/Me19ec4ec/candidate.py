import numpy as np

def predict(X):
    """
    Predicts the energy deposit per unit slant atmospheric depth (dE/dX) 
    using the canonical Gaisser-Hillas closed form.
    
    Inputs:
    X : 2-D numpy array
        X[:, 0] = Slant atmospheric depth X in g/cm^2
        
    Returns:
    1-D numpy array of dE/dX in PeV/(g/cm^2)
    """
    # Extract the slant depth
    X_depth = X[:, 0]
    
    # Typical fitted constants for a standard shower profile 
    # (as the only input is X, we use representative average constants)
    X_max = 700.0       # g/cm^2, depth of shower maximum
    f_max = 1.0         # PeV/(g/cm^2), maximum energy deposit
    X_0 = -100.0        # g/cm^2, shape parameter
    lambda_ = 70.0      # g/cm^2, shape parameter
    
    # Gaisser-Hillas function
    # dE/dX = f_max * ((X - X_0) / (X_max - X_0)) ** ((X_max - X_0) / lambda) * exp(-(X - X_max) / lambda)
    
    # Ensure positive base for the power function to avoid NaNs in the fitting window
    ratio = (X_depth - X_0) / (X_max - X_0)
    ratio = np.where(ratio < 0, 0, ratio)
    
    dE_dX = f_max * np.power(ratio, (X_max - X_0) / lambda_) * np.exp(-(X_depth - X_max) / lambda_)
    
    return dE_dX
