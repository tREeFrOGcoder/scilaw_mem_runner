USED_INPUTS = ['latitude']
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {'gamma_e': 9.7803253359, 'k': 0.00193185265241, 'e2': 0.00669437999014}
LOCAL_FITTABLE = {}

def predict(X: np.ndarray) -> np.ndarray:
    gamma_e = OTHER_CONSTANTS['gamma_e']
    k = OTHER_CONSTANTS['k']
    e2 = OTHER_CONSTANTS['e2']
    lat_deg = X[:, 0].astype(float)
    phi = np.deg2rad(lat_deg)
    sin2 = np.sin(phi) ** 2
    return gamma_e * (1.0 + k * sin2) / np.sqrt(1.0 - e2 * sin2)
