import numpy as np

def predict(X):
    """
    Compute normal gravity on the WGS84 reference ellipsoid (Somigliana formula).
    Input:
      X[:,0] = geodetic latitude in degrees
    Returns:
      1-D numpy array of gamma [m/s^2]
    """
    X = np.asarray(X)
    lat_deg = X[:, 0]
    phi = np.deg2rad(lat_deg)
    s2 = np.sin(phi)**2

    # International Gravity Formula / Somigliana constants (WGS84/IGF-80)
    gamma_e = 9.7803253359        # gravity at the equator [m/s^2]
    k = 0.00193185265241          # Somigliana constant
    e2 = 0.00669437999013         # eccentricity squared of WGS84

    gamma = gamma_e * (1.0 + k * s2) / np.sqrt(1.0 - e2 * s2)
    return gamma
