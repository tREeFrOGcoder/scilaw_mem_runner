import numpy as np

def predict(X):
    """
    Predicts the large frequency separation (delta_nu, [uHz]) from the frequency of 
    maximum oscillation power (nu_max, [uHz]) using the canonical empirical power-law 
    relation (Stello et al. 2009).

    Inputs:
    - X: 2-D numpy array where:
        - X[:, 0] = nu_max [uHz]
        - X[:, 1] = Teff [K] (unused in this canonical form)
        - X[:, 2] = FeH [dex] (unused in this canonical form)
        - X[:, 3] = phase (unused in this canonical form)

    Returns:
    - 1-D numpy array of delta_nu [uHz]
    """
    nu_max = X[:, 0]
    
    # Canonical power-law relation from Stello et al. (2009)
    delta_nu = 0.263 * np.power(nu_max, 0.772)
    
    return delta_nu
