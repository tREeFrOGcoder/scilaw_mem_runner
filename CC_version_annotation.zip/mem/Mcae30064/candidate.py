import numpy as np

def predict(X):
    """
    Predict log10(BMR in watts) from body mass in grams using Kleiber's law.
    B (W) = B0 * (M_kg)^0.75, with B0 = 70 kcal/day for a 1 kg mammal converted to watts.
    M_kg = body_mass_g / 1000
    Returns a 1-D numpy array of log10(B).
    """
    X = np.asarray(X)
    if X.ndim == 1:
        X = X.reshape(-1, 1)
    mass_g = X[:, 0].astype(float)
    # avoid log10(0)
    mass_g = np.maximum(mass_g, 1e-12)
    # normalization: 70 kcal/day for 1 kg -> in watts = 70 * 4184 J / 86400 s
    B0_watts = 70.0 * 4184.0 / 86400.0  # ≈ 3.389814815 W for 1 kg
    log10_B = np.log10(B0_watts) + 0.75 * (np.log10(mass_g) - 3.0)
    return log10_B
