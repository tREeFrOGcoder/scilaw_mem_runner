import numpy as np

def predict(X):
    s = X[:, 0]
    x = X[:, 1]
    
    # Canonical Mincer earnings function (often discussed/cited in Heckman's reviews of human capital models)
    beta_0 = 4.50   # Intercept
    beta_1 = 0.08   # Average return to an additional year of schooling
    beta_2 = 0.05   # Return to potential experience
    beta_3 = -0.001 # Diminishing returns to experience (concavity)
    
    ln_Y = beta_0 + beta_1 * s + beta_2 * x + beta_3 * (x ** 2)
    
    return ln_Y
