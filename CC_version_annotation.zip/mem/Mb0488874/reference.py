USED_INPUTS = ['log_P', 'feh']
LAW_CONSTANTS = {'alpha': -3.338, 'gamma': -0.384, 'delta': -4.958}
OTHER_CONSTANTS = {'pivot': 0.7}
LOCAL_FITTABLE = {}

def predict(X: np.ndarray, alpha: float=-3.338, gamma: float=-0.384, delta: float=-4.958) -> np.ndarray:
    pivot = OTHER_CONSTANTS['pivot']
    log_P = np.asarray(X[:, 0], dtype=float)
    feh = np.asarray(X[:, 1], dtype=float)
    return alpha * (log_P - pivot) + delta + gamma * feh
