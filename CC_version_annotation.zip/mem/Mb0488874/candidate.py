import numpy as np


def predict(X):
    # X[:, 0] = log_P (base-10 logarithm of fundamental-mode period in days)
    # X[:, 1] = feh ([Fe/H] metallicity in dex)
    log_P = X[:, 0]
    feh = X[:, 1]

    # Canonical PLZ relation for Gaia Wesenheit magnitude from Breuval (2022)
    # M_W = a * (log P - 1.0) + b + c * [Fe/H]
    slope = -3.311
    zero_point = -5.988
    metallicity_term = -0.22

    M_W = slope * (log_P - 1.0) + zero_point + metallicity_term * feh

    return M_W
