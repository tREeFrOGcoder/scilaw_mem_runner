USED_INPUTS = ['Agei']
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {'L_inf': {'init': None}, 'K': {'init': None}, 't0': {'init': None}}

def _vbgf(t: np.ndarray, L_inf: float, K: float, t0: float) -> np.ndarray:
    return L_inf * (1.0 - np.exp(-K * (t - t0)))

def predict(X: np.ndarray, L_inf: float, K: float, t0: float) -> np.ndarray:
    t = np.asarray(X[:, 0], dtype=float)
    return _vbgf(t, L_inf, K, t0)
