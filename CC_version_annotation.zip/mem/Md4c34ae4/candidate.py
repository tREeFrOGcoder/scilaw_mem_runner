import numpy as np

def predict(X):
    # Von Bertalanffy Growth Function (VBGF): L(t) = Linf * (1 - exp(-k*(t - t0)))
    age = X[:, 0]
    Linf = 500.0   # asymptotic total length (mm)
    k = 0.20       # Brody growth coefficient (per year)
    t0 = -0.5      # theoretical age at length zero (years)
    return Linf * (1.0 - np.exp(-k * (age - t0)))
