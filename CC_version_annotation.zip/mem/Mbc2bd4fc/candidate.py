import numpy as np

def predict(X):
    """
    Predict long-term mean daily runoff per unit area Q [mm/day] from inputs X.
    Uses the canonical parametric Budyko (Fu) formulation:
        ET/P = phi / (1 + phi**n)**(1/n),   where phi = PET / P
    Then Q = P - ET, constrained to [0, P].

    X is a 2-D numpy array with columns:
      0: p_mean (P) [mm/day]
      1: pet_mean (PET) [mm/day]
      (other columns are ignored by this baseline)

    Returns a 1-D numpy array of Q (mm/day).
    """
    P = np.asarray(X)[:, 0].astype(float)
    PET = np.asarray(X)[:, 1].astype(float)

    # Ensure no division by zero; if P == 0, runoff must be zero
    P_safe = np.where(P <= 0.0, np.nan, P)

    # Aridity index
    phi = PET / P_safe

    # Fu parameter (common/default choice). Can be tuned if data are available.
    n = 2.0

    # Budyko-Fu actual evapotranspiration fraction: ET/P
    # ET_frac = phi / (1 + phi**n)**(1/n)
    # Handle NaNs from P==0 by setting ET_frac -> 0 (so Q -> 0) afterwards.
    with np.errstate(divide='ignore', invalid='ignore', over='ignore'):
        ET_frac = phi / np.power(1.0 + np.power(phi, n), 1.0 / n)

    ET_frac = np.where(np.isnan(ET_frac), 0.0, ET_frac)

    ET = P * ET_frac

    Q = P - ET

    # Enforce physical bounds: 0 <= Q <= P
    Q = np.maximum(0.0, np.minimum(Q, P))

    return Q.ravel()
