import numpy as np

def predict(X):
    """
    Predict log10(viscosity / Pa·s) of silicate melt using the Giordano et al. (2008) model.
    Input X: 2-D array with columns:
        X[:,0]  T [K]
        X[:,1]  SiO2 [mol%]
        X[:,2]  TiO2 [mol%]
        X[:,3]  Al2O3 [mol%]
        X[:,4]  FeO [mol%]
        X[:,5]  Fe2O3 [mol%]
        X[:,6]  MnO [mol%]
        X[:,7]  MgO [mol%]
        X[:,8]  CaO [mol%]
        X[:,9]  Na2O [mol%]
        X[:,10] K2O [mol%]
        X[:,11] P2O5 [mol%]
        X[:,12] H2O [mol%]
    Returns 1-D array of log10(eta).
    """
    T = X[:, 0]
    # Composition in mol% (columns 1 to 12)
    comp_mol_pct = X[:, 1:13]
    # Convert to mole fraction and normalize to sum = 1
    comp_frac = comp_mol_pct / 100.0
    total = np.sum(comp_frac, axis=1, keepdims=True)
    # Avoid division by zero (unlikely but safe)
    total = np.where(total == 0, 1.0, total)
    x = comp_frac / total

    # Coefficients from Giordano, Russell & Dingwell (2008), Table 3
    # A parameter
    a_intercept = -4.55
    a_coeff = np.array([ 0.029, -0.035, -0.083, -0.048, -0.024,
                        -0.038,  0.049,  0.059,  0.097,  0.036,
                         1.375, -0.058])
    # B parameter
    b_intercept = 5398.0
    b_coeff = np.array([-55.7,  15.4,  62.6,  45.0,  37.6,
                         17.7, -56.3, -55.0, -96.3, -88.7,
                      -1134.0,  65.6])
    # C parameter
    c_intercept = 526.9
    c_coeff = np.array([ 4.7, -9.2, -5.7, -2.4, -5.9,
                        -4.5,  5.2,  4.6,  4.9,  4.6,
                        65.0, -10.6])

    A = a_intercept + np.dot(x, a_coeff)
    B = b_intercept + np.dot(x, b_coeff)
    C = c_intercept + np.dot(x, c_coeff)

    log_eta = A + B / (T - C)
    return log_eta
