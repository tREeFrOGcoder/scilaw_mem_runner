USED_INPUTS = ['sigma0', 'log_M_sph', 'Pseudobulge']
LAW_CONSTANTS = {'c_sigma': 1.0, 'c_msph': 1.0, 'c_pseudo': -0.56, 'c_offset': -4.57}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {}

def predict(X, **params):
    sigma0 = np.asarray(X[:, 0], dtype=float)
    log_M_sph = np.asarray(X[:, 1], dtype=float)
    pseudobulge = np.asarray(X[:, 2], dtype=float)
    c_sigma = LAW_CONSTANTS['c_sigma']
    c_msph = LAW_CONSTANTS['c_msph']
    c_pseudo = LAW_CONSTANTS['c_pseudo']
    c_offset = LAW_CONSTANTS['c_offset']
    return c_sigma * np.log10(sigma0) + c_msph * log_M_sph + c_pseudo * pseudobulge + c_offset
