import numpy as np

def predict(X):
    # Extract central stellar velocity dispersion (km/s)
    sigma0 = X[:, 0]
    
    # Canonical M-sigma relation coefficients (McConnell & Ma 2013)
    alpha = 8.32
    beta = 5.64
    
    # Calculate log10(M_BH / M_sun)
    log_M_BH = alpha + beta * np.log10(sigma0 / 200.0)
    
    return log_M_BH
