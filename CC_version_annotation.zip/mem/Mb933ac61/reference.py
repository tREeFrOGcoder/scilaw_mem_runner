USED_INPUTS = ['log_M_Msun']
LAW_CONSTANTS = {'A1': 2.028, 'B1': -0.976, 'A2': 4.572, 'B2': -0.102, 'A3': 5.743, 'B3': -0.007, 'A4': 4.329, 'B4': 0.01, 'A5': 3.967, 'B5': 0.093, 'A6': 2.865, 'B6': 1.105}
OTHER_CONSTANTS = {'M_BREAK_1': 0.45, 'M_BREAK_2': 0.72, 'M_BREAK_3': 1.05, 'M_BREAK_4': 2.4, 'M_BREAK_5': 7.0}
LOCAL_FITTABLE = {}

def predict(X: np.ndarray, A1: float=2.028, B1: float=-0.976, A2: float=4.572, B2: float=-0.102, A3: float=5.743, B3: float=-0.007, A4: float=4.329, B4: float=0.01, A5: float=3.967, B5: float=0.093, A6: float=2.865, B6: float=1.105, M_BREAK_1: float=0.45, M_BREAK_2: float=0.72, M_BREAK_3: float=1.05, M_BREAK_4: float=2.4, M_BREAK_5: float=7.0) -> np.ndarray:
    log_M = np.asarray(X[:, 0], dtype=float)
    M = 10.0 ** log_M
    pred = np.zeros_like(log_M)
    bin1 = M <= M_BREAK_1
    bin2 = (M > M_BREAK_1) & (M <= M_BREAK_2)
    bin3 = (M > M_BREAK_2) & (M <= M_BREAK_3)
    bin4 = (M > M_BREAK_3) & (M <= M_BREAK_4)
    bin5 = (M > M_BREAK_4) & (M <= M_BREAK_5)
    bin6 = M > M_BREAK_5
    pred[bin1] = A1 * log_M[bin1] + B1
    pred[bin2] = A2 * log_M[bin2] + B2
    pred[bin3] = A3 * log_M[bin3] + B3
    pred[bin4] = A4 * log_M[bin4] + B4
    pred[bin5] = A5 * log_M[bin5] + B5
    pred[bin6] = A6 * log_M[bin6] + B6
    return pred
