import numpy as np

def predict(X):
    """
    Predict log10(L/L_sun) from inputs:
    X[:,0] = log10(M/M_sun)
    X[:,1] = [M/H] (ignored)
    Uses a standard piecewise mass-luminosity relation for main-sequence stars:
      L = a * M^alpha with coefficients chosen to give approximate continuity:
        M <= 0.43   : L = 0.23 * M^2.3
        0.43 < M <= 2 : L = 1.0  * M^4.0
        2 < M <= 20 : L = 1.5  * M^3.5
        M > 20      : L = 3200 * M^1.0
    Returns a 1-D numpy array of log10(L/L_sun).
    """
    X = np.asarray(X)
    if X.ndim == 1:
        # interpret as single sample with at least one feature
        X = X.reshape(1, -1)
    logM = X[:, 0]
    # prepare output filled with NaN for invalid inputs
    logL = np.full_like(logM, np.nan, dtype=float)

    # compute mass in solar units
    with np.errstate(over='ignore', invalid='ignore'):
        M = 10.0 ** logM

    # piecewise masks
    m1 = (M <= 0.43)
    m2 = (M > 0.43) & (M <= 2.0)
    m3 = (M > 2.0) & (M <= 20.0)
    m4 = (M > 20.0)

    # coefficients and exponents
    # (values are the commonly cited textbook choices)
    a1, e1 = 0.23, 2.3
    a2, e2 = 1.0, 4.0
    a3, e3 = 1.5, 3.5
    a4, e4 = 3200.0, 1.0

    # compute luminosities and convert to log10
    # guard against negative/NaN M entries by using masks
    if np.any(m1):
        L1 = a1 * (M[m1] ** e1)
        logL[m1] = np.log10(L1)
    if np.any(m2):
        L2 = a2 * (M[m2] ** e2)
        logL[m2] = np.log10(L2)
    if np.any(m3):
        L3 = a3 * (M[m3] ** e3)
        logL[m3] = np.log10(L3)
    if np.any(m4):
        L4 = a4 * (M[m4] ** e4)
        logL[m4] = np.log10(L4)

    return logL
