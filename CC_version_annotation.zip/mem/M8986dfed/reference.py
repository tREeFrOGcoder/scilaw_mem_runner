USED_INPUTS = ['laser_power_W', 'scan_velocity_mm_per_s', 'beam_diameter_um']
LAW_CONSTANTS = {'B_slope': 0.1875, 'E_threshold': 10.0}
OTHER_CONSTANTS = {'A_abs_316L': 0.4, 'rho_316L': 7980.0, 'hs_J_kg_316L': 1200000.0, 'D_diff_316L': 5.38e-06}
LOCAL_FITTABLE = {}

def predict(X: np.ndarray, B_slope: float, E_threshold: float) -> np.ndarray:
    A_abs_316L = OTHER_CONSTANTS['A_abs_316L']
    rho_316L = OTHER_CONSTANTS['rho_316L']
    hs_J_kg_316L = OTHER_CONSTANTS['hs_J_kg_316L']
    D_diff_316L = OTHER_CONSTANTS['D_diff_316L']
    P = np.asarray(X[:, 0], dtype=float)
    u = np.asarray(X[:, 1], dtype=float) * 0.001
    D4sigma = np.asarray(X[:, 2], dtype=float) * 1e-06
    sigma = D4sigma / 4.0
    sigma_um = np.asarray(X[:, 2], dtype=float) / 4.0
    sigma3 = np.power(np.maximum(sigma, 1e-15), 3.0)
    u_safe = np.where(u > 0, u, 1e-30)
    arg = np.pi * D_diff_316L * u_safe * sigma3
    arg = np.maximum(arg, 1e-60)
    denom = rho_316L * hs_J_kg_316L * np.sqrt(arg)
    E_star = A_abs_316L * P / denom
    d_over_sigma = np.maximum(0.0, B_slope * (E_star - E_threshold))
    return sigma_um * d_over_sigma
