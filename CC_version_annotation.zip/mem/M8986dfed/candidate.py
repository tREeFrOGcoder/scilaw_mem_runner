import numpy as np

def predict(X):
    P = X[:, 0]  # laser_power_W
    V = X[:, 1]  # scan_velocity_mm_per_s
    D = X[:, 2]  # beam_diameter_um
    
    # Constants based on the canonical form from King (2014)
    alpha = 0.5  # empirical constant for melt pool depth
    beta = 1.0   # empirical constant for scaling with power and velocity
    
    # Calculate melt pool depth in micrometers
    d = alpha * (P / V) * (D / 2)  # D/2 for radius in micrometers
    
    return d
