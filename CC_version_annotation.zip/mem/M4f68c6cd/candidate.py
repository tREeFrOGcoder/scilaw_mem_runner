import numpy as np

def predict(X):
    t = X[:, 0]
    dt = t - 1958.0
    
    # Long-term quadratic trend
    c = 315.0 + 0.8 * dt + 0.013 * dt**2
    
    # Annual seasonal cycle (peaks in May, troughs in Sept)
    c += 2.0 * np.sin(2 * np.pi * t) - 2.0 * np.cos(2 * np.pi * t)
    
    # Semi-annual seasonal cycle
    c += 0.5 * np.sin(4 * np.pi * t)
    
    return c
