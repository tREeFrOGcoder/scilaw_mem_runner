import numpy as np


def predict(X):
    """Predicts the discharge capacity Q (Ah) as a function of cycle index k

    using the canonical double-exponential degradation model from He et al. (2011).

    Parameters:
    X : ndarray of shape (n_samples, 1)
        X[:, 0] = cycle_index (k)

    Returns:
    Q : ndarray of shape (n_samples,)
        Discharge capacity (Ah)
    """
    k = X[:, 0]

    # Canonical double exponential model parameters fitted for typical NASA battery data
    a = 1.1000
    b = -0.0005
    c = 0.7500
    d = -0.0030

    Q = a * np.exp(b * k) + c * np.exp(d * k)
    return Q
