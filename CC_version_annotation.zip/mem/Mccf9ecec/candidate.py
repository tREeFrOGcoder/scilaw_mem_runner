import numpy as np

def predict(X):
    log_P = X[:, 0]
    feh = X[:, 1]
    
    # Constants for the relationship (fictitious values for illustration)
    a = 3.12  # Coefficient for log_P
    b = -0.25 # Coefficient for [Fe/H]
    c = -1.85 # Intercept
    
    # Calculate M_W using the standard relation
    M_W = a * log_P + b * feh + c
    
    return M_W
