USED_INPUTS = ['M_threshold']
LAW_CONSTANTS = {'a': 8.1352, 'b': 1.0191}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {}

def predict(X: np.ndarray, a: float, b: float) -> np.ndarray:
    M = X[:, 0]
    return a - b * M
