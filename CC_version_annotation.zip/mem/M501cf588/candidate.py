import numpy as np

def predict(X):
    M = X[:, 0]
    # Gutenberg-Richter cumulative rate relation:
    # log10 N = a - b M
    # Since only magnitude threshold is provided, use the standard canonical b-value form
    # with b ≈ 1 as the most common generic closed-form relationship.
    a = 0.0
    b = 1.0
    return a - b * M
