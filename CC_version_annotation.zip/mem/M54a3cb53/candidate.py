import numpy as np

def predict(X):
    """
    Predict mean equivalent airspeed corrected to sea-level density (Ue) [m/s]
    from body mass and wing area using the steady lift balance:
        Ue = sqrt( (2 * m * g) / (rho0 * S * CL) )
    where CL is a typical cruise lift coefficient.
    Inputs:
      X[:,0] = mass_kg (m) [kg]
      X[:,1] = wing_area_m2 (S) [m^2]
    Returns:
      1-D numpy array of Ue for each row of X.
    """
    X = np.asarray(X)
    m = X[:, 0]
    S = X[:, 1]
    # constants
    g = 9.81           # gravitational acceleration [m/s^2]
    rho0 = 1.225       # sea-level air density [kg/m^3]
    CL = 0.5           # typical cruise lift coefficient (dimensionless)
    # avoid division by zero or negative areas
    S_safe = np.maximum(S, 1e-8)
    Ue = np.sqrt((2.0 * m * g) / (rho0 * S_safe * CL))
    return Ue
