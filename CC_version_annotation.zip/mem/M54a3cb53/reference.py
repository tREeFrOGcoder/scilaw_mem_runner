USED_INPUTS = ['mass_kg', 'wing_area_m2']
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {'C_L': 0.4195, 'g': 9.81, 'rho_0': 1.225}
LOCAL_FITTABLE = {}

def predict(X: np.ndarray) -> np.ndarray:
    C_L = OTHER_CONSTANTS['C_L']
    g = OTHER_CONSTANTS['g']
    rho_0 = OTHER_CONSTANTS['rho_0']
    mass_kg = np.asarray(X[:, 0], dtype=float)
    wing_area_m2 = np.asarray(X[:, 1], dtype=float)
    Ue = np.sqrt(2.0 * mass_kg * g / (rho_0 * wing_area_m2 * C_L))
    return Ue
