import numpy as np

def predict(X):
    """
    Predict OD600(t) using the Zwietering (1990) modified Gompertz model.
    
    Input:
        X : 2-D numpy array, X[:,0] = time_h (h)
    Returns:
        1-D numpy array of predicted OD600 (dimensionless)
    """
    t = X[:, 0]
    
    # Parameters for E. coli K-12 BW25113 (typical values)
    A = 0.8       # asymptote (maximum OD)
    mu_max = 0.5  # maximum specific growth rate (h^-1)
    lag = 2.0     # lag time (h)
    
    # Zwietering (1990) equation: y = A * exp{-exp[ (mu_max * e / A) * (lag - t) + 1 ]}
    inner = (mu_max * np.e / A) * (lag - t) + 1.0
    od = A * np.exp(-np.exp(inner))
    
    return od
