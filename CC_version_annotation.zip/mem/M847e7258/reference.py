USED_INPUTS = ['Q_alpha_MeV']
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {'A_Z': {'init': None}, 'B_Z': {'init': None}}

def predict(X: np.ndarray, A_Z: float, B_Z: float) -> np.ndarray:
    Q = np.asarray(X[:, 0], dtype=float)
    return A_Z * Q ** (-0.5) + B_Z
