import numpy as np

def predict(X):
    X = np.asarray(X, dtype=float)

    A = np.maximum(X[:, 0], 1e-12)   # GDP per capita
    P = np.maximum(X[:, 1], 1e-12)   # population
    AP = np.maximum(X[:, 2], 1e-12)  # active-age population share, %
    DP = np.maximum(X[:, 3], 1e-12)  # population density
    UR = np.maximum(X[:, 4], 1e-12)  # urbanization share, %
    AT = X[:, 5]                     # annual mean temperature, deg C

    # Extended STIRPAT form:
    # ln(I_N2O) = beta0 + beta_A ln(A) + beta_P ln(P)
    #             + beta_AP ln(AP) + beta_DP ln(DP)
    #             + beta_UR ln(UR) + beta_AT AT
    BETA_0 = -9.11
    BETA_A = 0.30
    BETA_P = 1.00
    BETA_AP = 0.10
    BETA_DP = -0.05
    BETA_UR = 0.10
    BETA_AT = 0.02

    log_I = (
        BETA_0
        + BETA_A * np.log(A)
        + BETA_P * np.log(P)
        + BETA_AP * np.log(AP)
        + BETA_DP * np.log(DP)
        + BETA_UR * np.log(UR)
        + BETA_AT * AT
    )

    return np.exp(log_I)
