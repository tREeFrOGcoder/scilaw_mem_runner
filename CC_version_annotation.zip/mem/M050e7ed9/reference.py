USED_INPUTS = ['GDP', 'TP', 'AP', 'DP', 'UR', 'AT']
LAW_CONSTANTS = {'a1': 90.005, 'a2': 1.0, 'a3': 1.598, 'a4': 0.999}
OTHER_CONSTANTS = {'LOG_FLOOR': 1e-20, 'AT_K_OFFSET': 273.15}
LOCAL_FITTABLE = {}

def predict(X: np.ndarray, **params) -> np.ndarray:
    a1 = params.get('a1', LAW_CONSTANTS['a1'])
    a2 = params.get('a2', LAW_CONSTANTS['a2'])
    a3 = params.get('a3', LAW_CONSTANTS['a3'])
    a4 = params.get('a4', LAW_CONSTANTS['a4'])
    GDP = np.asarray(X[:, 0], dtype=float)
    TP = np.asarray(X[:, 1], dtype=float)
    AP = np.asarray(X[:, 2], dtype=float)
    DP = np.asarray(X[:, 3], dtype=float)
    UR = np.asarray(X[:, 4], dtype=float)
    AT_C = np.asarray(X[:, 5], dtype=float)
    AT_K = AT_C + _AT_K_OFFSET
    a4_AT = a4 ** AT_K
    inner = np.maximum(DP / GDP + UR ** 2 / (a1 * GDP), _LOG_FLOOR)
    exponent = -a3 / AP
    log_arg = np.maximum(a2 ** DP * TP, _LOG_FLOOR)
    log_term = np.log(log_arg)
    log_NOE = a4 + a4_AT * inner ** exponent * log_term
    return np.exp(log_NOE)
