USED_INPUTS = ['wavelength_nm']
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {'h': 6.62607015e-34, 'c': 299792458.0, 'k_B': 1.380649e-23}
LOCAL_FITTABLE = {'T_eff': {'init': None}}

def _planck_nm(lambda_nm, T_eff):
    exponent = _hc_kB * 1000000000.0 / (lambda_nm * T_eff)
    exponent = np.minimum(exponent, 709.0)
    L_per_m = _2hc2 * (lambda_nm * 1e-09) ** (-5) / (np.exp(exponent) - 1.0)
    return L_per_m * 1e-09

def predict(X: np.ndarray, T_eff: float) -> np.ndarray:
    lambda_nm = np.asarray(X[:, 0], dtype=float)
    return _planck_nm(lambda_nm, float(T_eff))
