import numpy as np

def predict(X):
    """
    Compute Planck spectral radiance L(λ, T) in W m⁻² nm⁻¹ sr⁻¹.
    
    Input X is a 2-D array where X[:, 0] = wavelength in nm.
    Returns a 1-D array of L(λ, T).
    """
    wavelength_nm = X[:, 0]
    
    # Physical constants
    h = 6.62607015e-34      # Planck constant (J·s)
    c = 2.99792458e8        # Speed of light (m/s)
    k = 1.380649e-23        # Boltzmann constant (J/K)
    T = 5772.0              # Solar effective temperature (K)
    
    # Convert wavelength from nm to m
    wavelength_m = wavelength_nm * 1e-9
    
    # Planck radiance formula: L(λ, T) = (2 h c^2 / λ^5) * 1 / (exp(h c / (λ k T)) - 1)
    # This gives spectral radiance in W m⁻² m⁻¹ sr⁻¹
    # Multiply by 1e-9 to convert per m to per nm
    L_per_m = (2.0 * h * c**2) / (wavelength_m**5) * 1.0 / (np.exp(h * c / (wavelength_m * k * T)) - 1.0)
    
    L_per_nm = L_per_m * 1e-9  # W m⁻² nm⁻¹ sr⁻¹
    
    return L_per_nm
