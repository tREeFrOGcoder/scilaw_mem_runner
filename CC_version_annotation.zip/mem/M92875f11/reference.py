USED_INPUTS = ['phi']
LAW_CONSTANTS = {'C_GLOBAL': 3.220265}
OTHER_CONSTANTS = {'KC_PRE_FACTOR': 0.0083}
LOCAL_FITTABLE = {}

def predict(X: np.ndarray, C_GLOBAL: float=3.220265) -> np.ndarray:
    phi = np.clip(np.asarray(X[:, 0], dtype=float), _EPS, 1.0 - _EPS)
    return 3.0 * np.log10(phi) - 2.0 * np.log10(1.0 - phi) + C_GLOBAL
