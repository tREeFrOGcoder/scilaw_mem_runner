import numpy as np

def predict(X):
    # Kozeny-Carman equation for permeability (k) in terms of porosity (φ)
    # k = (φ^3) / (C * (1 - φ)^2) where C is a constant (typically around 5)
    C = 5.0
    phi = X[:, 0]
    
    # Calculate permeability (k)
    k = (phi**3) / (C * (1 - phi)**2)
    
    # Calculate log10(k) in millidarcy (mD)
    log_k = np.log10(k) + 3  # Convert to mD by adding 3 (since 1 Darcy = 1000 mD)
    
    return log_k
