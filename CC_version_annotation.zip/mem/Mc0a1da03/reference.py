USED_INPUTS = ['t', 'Q_0']
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {'a': {'init': None}, 'b': {'init': None}}

def _Q_t(t: np.ndarray, Q_0: np.ndarray, a: float, b: float) -> np.ndarray:
    one_minus_b = 1.0 - b
    inner = np.asarray(Q_0, dtype=float) ** one_minus_b + a * (b - 1.0) * np.asarray(t, dtype=float)
    inner = np.maximum(inner, 1e-20)
    return inner ** (1.0 / one_minus_b)

def _log_deriv_init(t: np.ndarray, Q_0: np.ndarray, y: np.ndarray):
    sort_idx = np.argsort(t)
    t_s, y_s = (t[sort_idx], y[sort_idx])
    dt_diff = np.diff(t_s)
    dQ_diff = np.diff(y_s)
    neg_dQdt = -dQ_diff / np.where(dt_diff > 0, dt_diff, 1.0)
    Q_mid = (y_s[:-1] + y_s[1:]) / 2.0
    valid = (neg_dQdt > 0) & (Q_mid > 0)
    if valid.sum() < 3:
        return (0.05, 1.3)
    log_neg_dQdt = np.log(neg_dQdt[valid])
    log_Q = np.log(Q_mid[valid])
    A_mat = np.column_stack([np.ones(valid.sum()), log_Q])
    try:
        coeffs, _, _, _ = np.linalg.lstsq(A_mat, log_neg_dQdt, rcond=None)
        log_a0, b0 = (float(coeffs[0]), float(coeffs[1]))
        a0 = float(np.exp(log_a0))
    except Exception:
        return (0.05, 1.3)
    a0 = float(np.clip(a0, _A_LO * 10, _A_HI / 10))
    b0 = float(np.clip(b0, _B_LO + 0.01, _B_HI - 0.1))
    return (a0, b0)

def predict(X: np.ndarray, a: float, b: float) -> np.ndarray:
    t = np.asarray(X[:, 0], dtype=float)
    Q_0 = np.asarray(X[:, 1], dtype=float)
    return _Q_t(t, Q_0, a, b)
