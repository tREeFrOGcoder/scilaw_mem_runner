import numpy as np

def predict(X):
    """
    Predicts the daily-mean streamflow discharge Q(t) using the canonical 
    closed-form Boussinesq late-time recession equation (corresponding to the 
    b = 1.5 exponent in the dQ/dt = -a*Q^b framework of Brutsaert and Nieber, 1977).
    
    Inputs:
    - X: 2-D numpy array where:
        - X[:, 0] = t (elapsed time in days since the start of recession)
        - X[:, 1] = Q_0 (observed discharge at the start of the recession, t=0)
        
    Returns:
    - 1-D numpy array of predicted Q(t) values.
    """
    t = X[:, 0]
    Q_0 = X[:, 1]
    
    # recession parameter 'a' for the dQ/dt = -a * Q^1.5 relationship
    # A typical value is chosen here for representation.
    a = 0.05 
    
    # Analytical solution of dQ/dt = -a * Q^1.5:
    # Q(t) = Q_0 / (1 + 0.5 * a * sqrt(Q_0) * t)^2
    Q_t = Q_0 / (1.0 + 0.5 * a * np.sqrt(Q_0) * t) ** 2
    
    return Q_t
