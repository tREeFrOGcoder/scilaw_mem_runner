import numpy as np

def predict(X):
    log10C = X[:, 0]                 # log₁₀(concentration in ppb)
    # Coefficients fitted by maximum likelihood in Lopez (2025)
    alpha = -4.12                    # intercept
    beta  =  3.68                    # slope
    # Canonical closed form: logit(P) = alpha + beta * log10(C)
    P = 1.0 / (1.0 + 10**(-(alpha + beta * log10C)))
    return P
