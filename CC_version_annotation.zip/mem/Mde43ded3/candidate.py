import numpy as np

def predict(X):
    R = X[:, 0]
    RA = X[:, 1]
    exponent = 2.0  # Bill James Pythagorean expectation
    return R**exponent / (R**exponent + RA**exponent)
