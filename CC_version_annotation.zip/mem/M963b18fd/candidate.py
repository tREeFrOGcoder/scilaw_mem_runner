import numpy as np

def predict(X):
    A_s = X[:, 0]
    Z_max = X[:, 1]
    
    # Canonical empirical relationship for thermocline depth (Boehrer & Schultze, 2008)
    # z_t scales with the square root of the wind fetch, which scales with A_s^0.25
    z_t = 2.5 * (A_s ** 0.25)
    
    # Apply physical upper bound constraint
    z_t = np.minimum(z_t, Z_max)
    
    return z_t
