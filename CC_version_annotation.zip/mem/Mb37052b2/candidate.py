import numpy as np

def predict(X):
    # Holling Type II functional response:
    # Na = (a * N * T) / (1 + a * h * N)
    # With no additional data, use the simplest standard closed-form
    # dependence on prey density alone by setting T=1 and absorbing
    # attack rate / handling time into a generic saturating form:
    N = X[:, 0]
    return N / (1.0 + N)
