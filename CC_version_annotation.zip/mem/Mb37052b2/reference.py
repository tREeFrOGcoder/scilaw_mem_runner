USED_INPUTS = ['prey_density']
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {'a': {'init': 0.5}, 'h': {'init': 0.1}}

def predict(X: np.ndarray, a: float, h: float) -> np.ndarray:
    N = np.asarray(X[:, 0], dtype=float)
    a = float(a)
    h = float(h)
    denom = 1.0 + a * h * N
    denom = np.where(np.abs(denom) < 1e-12, 1e-12, denom)
    return a * N / denom
