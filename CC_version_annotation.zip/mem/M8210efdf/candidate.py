import numpy as np

def predict(X):
    c = X[:, 0]
    l = X[:, 1]
    
    # Beer-Lambert Law: A = a * c * l
    # where 'a' is the specific absorptivity (L g^-1 cm^-1) of potassium dichromate at a given wavelength
    a = 1.0
    
    A = a * c * l
    return A
