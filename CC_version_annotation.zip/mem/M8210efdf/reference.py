USED_INPUTS = ['concentration', 'path_length']
LAW_CONSTANTS = {'alpha': 1.0, 'beta': 1.0}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {'epsilon': {'init': None}}

def predict(X: np.ndarray, alpha: float, beta: float, epsilon: float) -> np.ndarray:
    c = np.asarray(X[:, 0], dtype=float)
    l = np.asarray(X[:, 1], dtype=float)
    c_safe = np.where(c > 0, c, 1e-12)
    l_safe = np.where(l > 0, l, 1e-12)
    return epsilon * np.power(c_safe, alpha) * np.power(l_safe, beta)
