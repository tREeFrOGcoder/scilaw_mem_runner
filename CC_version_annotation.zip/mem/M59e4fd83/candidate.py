import numpy as np

def predict(X):
    t = X[:, 0]
    # Hathaway, Wilson, and Reichmann (1994) standard parametric model for the shape of the sunspot cycle.
    # F(t) = A * x^3 / (1 + x^4) * exp(-x^2 / 2), where x = (t - t0) / b
    
    A = 180.0  # Typical cycle amplitude (ISN v2.0 scale)
    b = 4.0    # Typical width parameter in years (~48 months)
    T = 11.0   # Average solar cycle period in years
    
    # Approximate cycle start times (minima) assuming an 11-year periodicity
    t0 = np.floor((t - 1749.0) / T) * T + 1749.0
    dt = t - t0
    x = dt / b
    
    # Calculate the standard sunspot cycle shape
    R = A * (x**3) / (1.0 + x**4) * np.exp(-x**2 / 2.0)
    
    # Sunspot numbers cannot be negative
    return np.maximum(R, 0)
