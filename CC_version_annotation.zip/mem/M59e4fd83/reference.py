USED_INPUTS = ['t_year']
LAW_CONSTANTS = {'c': 0.8}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {'A': {'init': [195.0, 290.0]}, 't0': {'init': [None, None, None]}, 'b': {'init': [3.5, 4.6667, 6.0]}}

def _hwrf(t, A, t0, b, c):
    u = (t - t0) / b
    denom = np.exp(u * u) - c
    with np.errstate(over='ignore', invalid='ignore'):
        val = A * u ** 3 / denom
    val = np.where(np.isfinite(val), val, 0.0)
    return val

def predict(X: np.ndarray, A: float, t0: float, b: float, c: float=0.8) -> np.ndarray:
    t = np.asarray(X[:, 0], dtype=float)
    return _hwrf(t, A, t0, b, c)
