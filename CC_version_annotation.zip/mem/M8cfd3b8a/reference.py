USED_INPUTS = ['density']
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {'A': {'init': None}, 'B': {'init': None}, 'theta': {'init': None}}

def _predict_core(p, A, B, theta):
    p = np.asarray(p, dtype=float)
    arg = A * np.power(np.clip(p, 0.0, None), theta) + B
    arg = np.clip(arg, 1e-300, None)
    return arg ** (-1.0 / theta)

def predict(X: np.ndarray, A: float, B: float, theta: float) -> np.ndarray:
    p = np.asarray(X[:, 0], dtype=float)
    return _predict_core(p, A, B, theta)
