import numpy as np

def predict(X):
    # Reciprocal yield law (competition-density effect):
    # 1/w = a + b*N  =>  w = 1 / (a + b*N)
    # This is the standard closed-form for mean mass per plant vs density,
    # consistent with the law of constant final yield.
    N = X[:, 0]
    a = 0.02   # intercept ~ 1/(max individual mass)
    b = 0.05   # slope ~ crowding coefficient
    w = 1.0 / (a + b * N)
    return w
