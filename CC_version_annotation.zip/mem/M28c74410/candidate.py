import numpy as np

def predict(X):
    """
    Predict natural log central death rate ln(m) for adult ages using a Lee-Carter style parametric form.
    Inputs:
      X[:,0] = age x (integer years, typical 30..95)
      X[:,1] = calendar year t (typical 1751..2025)
    Output:
      1-D numpy array of ln(m) of same length as X.
    Model (closed form):
      ln m(x,t) = a(x) + b(x) * k(t)
    where we use simple parametric forms (no data-fit; plausible demographic shapes):
      a(x) = a0 + a1 * (x - 30)        (baseline Gompertz-like increase with age)
      b(x) = 1.0 + b1 * (x - 65) * 0.01 (age-varying sensitivity)
      k(t) = k0 + k1 * (t - t_ref)     (linear period trend; k1 < 0 => mortality improvement)
    """
    X = np.asarray(X, dtype=float)
    if X.ndim != 2 or X.shape[1] < 2:
        raise ValueError("Input X must be a 2-D array with at least 2 columns (age, year).")
    x = X[:, 0]
    t = X[:, 1]

    # Parameters (chosen as plausible demography-oriented constants; not estimated from data)
    a0 = -7.5       # baseline log mortality at age 30 around exp(-7.5) ~ 0.00055
    a1 = 0.09       # Gompertz slope (mortality roughly doubles every ~8 years -> ln2/8 ~ 0.087)
    b1 = 1.0        # scale for age-sensitivity (b(x) centered about 1)
    # we implement a small linear age-dependence in b(x) with modest amplitude
    b_slope = 0.01

    k0 = 0.0        # index level at reference year
    k1 = -0.02      # yearly decline in the mortality index (negative -> improvement)
    t_ref = 2000.0  # reference year for k(t)

    # Compute components
    a_x = a0 + a1 * (x - 30.0)
    b_x = b1 + b_slope * (x - 65.0)
    k_t = k0 + k1 * (t - t_ref)

    ln_m = a_x + b_x * k_t

    return ln_m.astype(float)
