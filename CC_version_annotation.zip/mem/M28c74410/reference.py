USED_INPUTS = ['age']
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {'alpha': {'init': None}, 'beta': {'init': None}}

def predict(X: np.ndarray, alpha: float, beta: float) -> np.ndarray:
    age = np.asarray(X[:, 0], dtype=float)
    return alpha + beta * age
