USED_INPUTS = ['orientation_deg']
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {'A': {'init': None}, 'k': {'init': None}, 'varphi': {'init': None}, 'nu': {'init': 0.0}}

def _predict_rad(theta_rad, A, k, varphi_rad, nu):
    phi_r = theta_rad - varphi_rad
    return A * np.exp(k * (np.cos(2.0 * (phi_r + nu * np.sin(2.0 * phi_r))) - 1.0))

def predict(X: np.ndarray, A: float, k: float, varphi: float, nu: float) -> np.ndarray:
    theta_deg = np.asarray(X[:, 0], dtype=float)
    theta_rad = theta_deg * (np.pi / 180.0)
    varphi_rad = varphi * (np.pi / 180.0)
    return _predict_rad(theta_rad, A, k, varphi_rad, nu)
