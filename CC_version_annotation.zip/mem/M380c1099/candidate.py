import numpy as np

def predict(X):
    theta = X[:, 0] * np.pi / 180.0  # convert to radians
    
    # Von Mises tuning curve (standard model for orientation tuning)
    # Orientation is pi-periodic, so use 2*theta
    R0 = 0.5      # baseline response
    Rmax = 1.0    # response amplitude
    kappa = 2.0   # concentration (tuning width)
    theta_pref = 90.0 * np.pi / 180.0  # preferred orientation
    
    R = R0 + Rmax * np.exp(kappa * (np.cos(2 * (theta - theta_pref)) - 1))
    
    return R
