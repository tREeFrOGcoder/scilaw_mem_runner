USED_INPUTS = ['log_p_above']
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {'alpha': {'init': None}, 'C': {'init': None}}

def predict(X: np.ndarray, alpha: float, C: float) -> np.ndarray:
    log_p = np.asarray(X[:, 0], dtype=float)
    slope = 1.0 - 1.0 / alpha
    return slope * log_p + C
