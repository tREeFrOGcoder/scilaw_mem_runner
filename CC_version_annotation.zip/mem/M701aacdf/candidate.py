import numpy as np

def predict(X):
    """
    Predict ln S(p) — natural log of the share of pre-tax national income held by the top p fraction.

    Model (canonical log-linear / Pareto-type specification with a linear year trend and region intercepts):
        ln S(p) = intercept_region + beta * ln(p) + gamma * (year - 2000)

    Inputs:
      X[:,0] = log_p_above (ln p)
      X[:,1] = top_pct (unused, redundant with ln p)
      X[:,2] = year (calendar year)
      X[:,3] = region (one of: "Europe","Asia","Africa","Americas","Oceania")

    Returns:
      1-D numpy array of ln S(p)
    """
    X = np.asarray(X)
    if X.ndim == 1:
        X = X.reshape(1, -1)

    ln_p = X[:, 0].astype(float)
    year = X[:, 2].astype(float)
    regions = X[:, 3].astype(str)

    # Base (Europe) intercept and common slope / year trend (chosen as a canonical, literature-consistent form)
    intercept_base = -1.05   # baseline intercept (Europe) — ln share level for reference year 2000 at p=1
    beta = 0.33              # slope on ln(p); equals (1 - 1/alpha) for a Pareto tail
    gamma = 0.004            # annual trend in ln S (per year since 2000)

    # Region intercept adjustments (additive to intercept_base)
    region_adj = np.zeros(len(regions), dtype=float)
    region_adj[regions == "Europe"]   = 0.00
    region_adj[regions == "Americas"] = 0.45
    region_adj[regions == "Asia"]     = -0.10
    region_adj[regions == "Africa"]   = -0.25
    region_adj[regions == "Oceania"]  = -0.05
    # For any unknown region labels, leave adjustment = 0

    ln_S = (intercept_base + region_adj) + beta * ln_p + gamma * (year - 2000.0)
    return np.asarray(ln_S)
