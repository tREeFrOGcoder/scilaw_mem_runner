import numpy as np

def predict(X):
    X = np.asarray(X)
    t = X[:, 0].astype(float)

    # Empirical Keeling-curve form: smooth accelerating trend + annual harmonics.
    z = t - 1959.5
    trend = 315.97 + 0.9315 * z + 0.00535 * z**2 + 9.28e-5 * z**3

    w = 2.0 * np.pi * t
    seasonal = (
        -0.913 * np.cos(w) + 2.631 * np.sin(w)
        + 0.621 * np.cos(2.0 * w) - 0.558 * np.sin(2.0 * w)
        - 0.024 * np.cos(3.0 * w) - 0.047 * np.sin(3.0 * w)
    )

    amp = 1.0 + 0.0018 * (t - 1958.0)
    return trend + amp * seasonal
