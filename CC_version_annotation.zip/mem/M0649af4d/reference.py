USED_INPUTS = ['year_decimal']
LAW_CONSTANTS = {'A': 337.5921, 'B': 1.3395, 'C': 0.012806}
OTHER_CONSTANTS = {'T0': 1980.0}
LOCAL_FITTABLE = {}

def predict(X: np.ndarray, A: float=337.5921, B: float=1.3395, C: float=0.012806) -> np.ndarray:
    t = np.asarray(X[:, 0], dtype=float)
    dt = t - OTHER_CONSTANTS['T0']
    return A + B * dt + C * dt * dt
