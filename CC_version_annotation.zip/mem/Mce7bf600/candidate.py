import numpy as np


def predict(X):
    # Extract environmental distance (d)
    d = X[:, 0]

    # Standard exponential distance-decay model parameters:
    # S(d) = a * exp(-b * d)
    # where 'a' is the similarity at zero environmental distance (intercept)
    # and 'b' is the rate of similarity decay with environmental distance.
    a = 0.65
    b = 0.25

    # Calculate Sørensen taxonomic similarity
    S = a * np.exp(-b * d)

    # Ensure output is strictly bounded within [0, 1]
    return np.clip(S, 0.0, 1.0)
