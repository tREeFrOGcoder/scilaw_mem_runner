import numpy as np

def predict(X):
    """
    Predict Bowen-ratio-preserving energy-balance-corrected half-hourly latent heat flux
    (LE) using the Penman-Monteith equation, which is the canonical closed-form solution
    that inherently satisfies both the surface energy balance and the Bowen ratio.
    
    Inputs (columns of X):
    0: SWdown [W m^-2]       (not used directly; Rnet is used)
    1: VPD [kPa]
    2: Tair [K]
    3: RH [-]                (not used directly)
    4: Wind [m s^-1]         (not used directly; Ga is used)
    5: Rnet [W m^-2]
    6: Qg [W m^-2]
    7: LAI [m^2 m^-2]
    8: LWdown [W m^-2]       (not used directly)
    9: Ga [m s^-1]
    10: delta [kPa K^-1]
    11: theta_FC [m^3 m^-3]  (used to indicate no water stress when soil is at field capacity)
    12: theta_WP [m^3 m^-3]  (used to indicate no water stress when soil is at field capacity)
    
    Returns:
    LE [W m^-2]
    """
    # Extract inputs
    VPD = X[:, 1]      # kPa
    Tair = X[:, 2]     # K
    Rnet = X[:, 5]     # W m^-2
    Qg = X[:, 6]       # W m^-2
    LAI = X[:, 7]      # m^2 m^-2
    Ga = X[:, 9]       # m s^-1
    delta = X[:, 10]   # kPa K^-1
    theta_FC = X[:, 11]
    theta_WP = X[:, 12]

    # Constants
    cp = 1005.0          # J kg^-1 K^-1, specific heat of dry air
    Rd = 287.0           # J kg^-1 K^-1, gas constant for dry air
    P0 = 101300.0        # Pa, standard atmospheric pressure (assumed)
    gamma = 0.066        # kPa K^-1, psychrometric constant (typical at sea level)
    g_smax = 0.02        # m s^-1, maximum stomatal conductance per unit LAI (typical)

    # Air density (ideal gas law) and volumetric heat capacity
    rho = P0 / (Rd * Tair)          # kg m^-3
    rho_cp = rho * cp               # J m^-3 K^-1

    # Surface conductance (simplified Jarvis-type model)
    # Assume no water stress when soil moisture is at field capacity (θ = θ_FC).
    # Since actual θ is not provided, we set stress factor = 1.
    # The limits theta_FC and theta_WP are accepted but not used in this simplified form.
    Gs = g_smax * LAI               # m s^-1
    Gs = np.maximum(Gs, 1e-6)       # avoid division by zero

    # Penman-Monteith equation for latent heat flux (W m^-2)
    # LE = (Δ*(Rn - G) + ρ*cp*VPD*Ga) / (Δ + γ*(1 + Ga/Gs))
    num = delta * (Rnet - Qg) + rho_cp * VPD * Ga
    den = delta + gamma * (1.0 + Ga / Gs)
    LE = num / den

    return LE
