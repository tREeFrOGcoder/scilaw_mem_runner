import numpy as np


def predict(X):
    # Extract Q^2 from the first column of the input array
    Q2 = X[:, 0]

    # Proton mass squared (M_p = 0.938272 GeV)
    M_p2 = 0.938272**2
    tau = Q2 / (4.0 * M_p2)

    # Standard dipole form factor G_D
    G_D = (1.0 + Q2 / 0.71) ** -2

    # Arrington (2007) / AMT (2007) parameterization coefficients for G_E
    a1 = -0.114
    b1 = 11.16
    b2 = 13.58
    b3 = 22.02

    # Calculate G_E using the rational function form
    G_E = (1.0 + a1 * tau) / (1.0 + b1 * tau + b2 * tau**2 + b3 * tau**3)

    # Return the ratio G_E / G_D
    return G_E / G_D
