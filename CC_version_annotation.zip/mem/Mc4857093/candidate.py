import numpy as np


def predict(X):
    # Extract inputs
    I_prev = X[:, 0]
    biweek = X[:, 1]
    births = X[:, 2]
    log_pop = X[:, 3]
    z_t = X[:, 4]

    # Calculate population size N
    N = 10**log_pop

    # Reconstruct susceptibles S_t = S_bar + z_t
    # In measles TSIR models, the mean susceptible fraction (S_bar/N) is typically around 5% to 6%
    S_bar = 0.055 * N
    S = S_bar + z_t

    # Ensure susceptibles remain physically realistic (positive and bounded)
    S = np.clip(S, 0.01 * N, 0.20 * N)

    # Seasonal transmission rate beta_s
    # Modeled via a standard parametric harmonic profile
    # Peak transmission is typically in autumn/winter, lowest in summer
    beta_0 = 24.5  # Mean biweekly transmission rate
    beta_1 = 0.15  # Amplitude of seasonality
    phi = 2.0  # Phase shift (peak around biweek 2, trough around biweek 15)
    beta = beta_0 * (1.0 + beta_1 * np.cos(2 * np.pi * (biweek - phi) / 26.0))

    # Mixing exponent (alpha < 1 accounts for discretization and spatial clustering)
    alpha = 0.97

    # TSIR dynamics equation: I_t = beta_t * I_{t-1}^alpha * (S_{t-1} / N)
    I_t = beta * np.power(I_prev, alpha) * (S / N)

    return I_t
