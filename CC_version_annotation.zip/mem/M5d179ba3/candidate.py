import numpy as np

def predict(X):
    # Basal Metabolic Rate (BMR) can be estimated using the Kleiber's Law:
    # log10(B) = log10(70) + 0.75 * log10(M)
    # where B is the BMR in watts and M is the body mass in grams.
    
    body_mass_g = X[:, 0]
    log10_B = np.log10(70) + 0.75 * np.log10(body_mass_g)
    
    return log10_B
