USED_INPUTS = ['body_mass_g']
LAW_CONSTANTS = {'B_EXPONENT': 0.75, 'LOG_B0': -1.713}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {}

def predict(X: np.ndarray, B_EXPONENT: float=0.75, LOG_B0: float=-1.713) -> np.ndarray:
    M = np.asarray(X[:, 0], dtype=float)
    return LOG_B0 + B_EXPONENT * np.log10(M)
