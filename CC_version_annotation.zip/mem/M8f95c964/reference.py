USED_INPUTS = ['s']
LAW_CONSTANTS = {'c0': 37.32, 'c1': -1.44, 'c2': 0.2817}
OTHER_CONSTANTS = {'s_0': 2 * _MP_GEV ** 2, 'betaP': 37.1, 'mu': 0.5, 'delta': -28.56, 'alpha': 0.415}
LOCAL_FITTABLE = {}

def predict(X: np.ndarray, c0: float, c1: float, c2: float) -> np.ndarray:
    s_0 = OTHER_CONSTANTS['s_0']
    s = np.asarray(X[:, 0], dtype=float)
    log_s = np.log(s / s_0)
    return c0 + c1 * log_s + c2 * log_s ** 2
