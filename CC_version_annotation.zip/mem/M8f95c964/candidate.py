import numpy as np

def predict(X):
    s = X[:, 0]
    # PDG / COMPETE parametrization for total pp cross-section (in mb)
    # sigma_tot = Z + B ln^2(s/s0) + Y1*(s1/s)^eta1 - Y2*(s1/s)^eta2
    Z    = 35.45   # mb
    B    = 0.308   # mb
    s0   = 28.94   # GeV^2
    s1   = 1.0     # GeV^2
    Y1   = 42.53   # mb
    Y2   = 33.34   # mb
    eta1 = 0.458
    eta2 = 0.545

    sigma = (Z
             + B * np.log(s / s0)**2
             + Y1 * (s1 / s)**eta1
             - Y2 * (s1 / s)**eta2)
    return sigma
