USED_INPUTS = ['distance_m', 'sex_M']
LAW_CONSTANTS = {'vm_M': 5.8914, 'gamma_l_M': 0.078037, 'vm_F': 5.3367, 'gamma_l_F': 0.075702}
OTHER_CONSTANTS = {'tc': 360.0}
LOCAL_FITTABLE = {}

def _emig_velocity(d, vm, gamma_l, tc=360.0):
    d = np.asarray(d, dtype=float)
    dc = vm * tc
    z = -(d / dc) * np.exp(-1.0 / gamma_l)
    z_clipped = np.clip(z, -1.0 / np.e + 1e-12, -1e-300)
    W = np.real(lambertw(z_clipped, k=-1))
    T = -(tc / gamma_l) * (d / dc) / W
    return d / T

def predict(X: np.ndarray, vm_M: float, gamma_l_M: float, vm_F: float, gamma_l_F: float) -> np.ndarray:
    X = np.asarray(X, dtype=float)
    d = X[:, 0]
    sex_M = X[:, 1].astype(bool)
    sex_F = ~sex_M
    tc = OTHER_CONSTANTS['tc']
    v_out = np.empty(len(d), dtype=float)
    if np.any(sex_M):
        v_out[sex_M] = _emig_velocity(d[sex_M], vm_M, gamma_l_M, tc=tc)
    if np.any(sex_F):
        v_out[sex_F] = _emig_velocity(d[sex_F], vm_F, gamma_l_F, tc=tc)
    return v_out
