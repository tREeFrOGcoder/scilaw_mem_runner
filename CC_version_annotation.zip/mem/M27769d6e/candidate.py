import numpy as np

def predict(X):
    X = np.asarray(X, dtype=float)
    d = np.maximum(X[:, 0], np.finfo(float).tiny)
    sex_M = X[:, 1]

    # Riegel power-law form: T(d) = T0 * (d / d0)^b
    b = 1.06
    d0 = 10000.0

    # Sex-specific 10,000 m world-record anchors, in seconds
    T0_men = 26 * 60 + 11.00
    T0_women = 28 * 60 + 54.14

    T0 = np.where(sex_M >= 0.5, T0_men, T0_women)
    T = T0 * (d / d0) ** b

    return d / T
