USED_INPUTS = ['GDP', 'TP', 'DP', 'AT']
LAW_CONSTANTS = {'a1': -9.654e-26, 'a2': -0.278, 'a3': -21.508, 'a4': -0.02858, 'a5': 91.108, 'a6': -1954.0, 'a7': -11.293}
OTHER_CONSTANTS = {'K_OFFSET': 273.15, 'LOG_FLOOR': 1e-300}
LOCAL_FITTABLE = {}

def predict(X: np.ndarray, **params) -> np.ndarray:
    a1 = params.get('a1', LAW_CONSTANTS['a1'])
    a2 = params.get('a2', LAW_CONSTANTS['a2'])
    a3 = params.get('a3', LAW_CONSTANTS['a3'])
    a4 = params.get('a4', LAW_CONSTANTS['a4'])
    a5 = params.get('a5', LAW_CONSTANTS['a5'])
    a6 = params.get('a6', LAW_CONSTANTS['a6'])
    a7 = params.get('a7', LAW_CONSTANTS['a7'])
    GDP = np.asarray(X[:, 0], dtype=float)
    TP = np.asarray(X[:, 1], dtype=float)
    DP = np.asarray(X[:, 2], dtype=float)
    AT = np.asarray(X[:, 3], dtype=float)
    AT_K = AT + _K_OFFSET
    denom1 = a4 * a5 / GDP - TP ** a4
    term1 = a3 / denom1
    exp_dp = a4 ** 2 * a6 / np.maximum(DP, _LOG_FLOOR)
    numer2 = np.exp(exp_dp * np.log(np.maximum(DP, _LOG_FLOOR)))
    neg_a4_ATK = -a4 * AT_K
    denom2 = a1 * GDP * neg_a4_ATK ** (-a3) + a2
    term2 = numer2 / denom2
    log_ME = a7 + term1 + term2
    return np.exp(log_ME)
