import numpy as np

def predict(X):
    # Vazquez (2022) canonical STIRPAT-type multiplicative form for national CH4 emissions
    # I_CH4 = exp(b0) * GDP^b1 * P^b2 * AP^b3 * DP^b4 * UR^b5 * exp(b6*AT)
    GDP = X[:, 0]
    P   = X[:, 1]
    AP  = X[:, 2]
    DP  = X[:, 3]
    UR  = X[:, 4]
    AT  = X[:, 5]

    b0 = -3.5      # intercept
    b1 = 0.35      # GDP elasticity
    b2 = 1.00      # population elasticity
    b3 = 0.50      # active-population elasticity
    b4 = -0.10     # density elasticity
    b5 = -0.15     # urbanization elasticity
    b6 = 0.02      # temperature coefficient

    lnI = (b0
           + b1 * np.log(GDP)
           + b2 * np.log(P)
           + b3 * np.log(AP)
           + b4 * np.log(DP)
           + b5 * np.log(UR)
           + b6 * AT)

    return np.exp(lnI)
