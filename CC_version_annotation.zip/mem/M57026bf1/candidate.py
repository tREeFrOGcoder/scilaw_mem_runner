import numpy as np

def predict(X):
    d = X[:, 0]  # environmental distance
    a = 1.0      # coefficient for the linear relationship
    b = 0.0      # intercept
    S = a * np.exp(-d) + b  # Mean occurrence-based Sørensen similarity
    S = np.clip(S, 0, 1)     # Ensure S is bounded between 0 and 1
    return S
