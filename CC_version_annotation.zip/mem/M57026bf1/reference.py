USED_INPUTS = ['env_dist']
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {'alpha': {'init': None}, 'beta': {'init': None}}

def predict(X: np.ndarray, alpha: float, beta: float) -> np.ndarray:
    d = np.asarray(X[:, 0], dtype=float)
    return np.exp(alpha + beta * d)
