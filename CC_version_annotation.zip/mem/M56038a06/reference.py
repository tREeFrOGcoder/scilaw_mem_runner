USED_INPUTS = ['chan_discharge']
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {'a': {'init': None}, 'b': {'init': None}}

def _width(Q, a, b):
    return a * np.power(np.asarray(Q, dtype=float), b)

def predict(X: np.ndarray, a: float, b: float) -> np.ndarray:
    Q = np.asarray(X[:, 0], dtype=float)
    return _width(Q, a, b)
