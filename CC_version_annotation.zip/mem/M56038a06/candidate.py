import numpy as np

def predict(X):
    Q = X[:, 0]
    # Leopold and Maddock (1953) at-a-station hydraulic geometry
    a = 2.5  # typical coefficient for width (ft) and discharge (cfs)
    b = 0.26 # typical at-a-station exponent for width
    w = a * (Q ** b)
    return w
