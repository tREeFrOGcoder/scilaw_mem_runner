USED_INPUTS = ['T', 'sio2', 'tio2', 'al2o3', 'feo', 'fe2o3', 'mno', 'mgo', 'cao', 'na2o', 'k2o', 'p2o5', 'h2o']
LAW_CONSTANTS = {'A': -4.55, 'b1': 159.6, 'b2': -173.3, 'b3': 72.1, 'b4': 75.7, 'b5': -39.0, 'b6': -84.1, 'b7': 141.5, 'b11': -2.43, 'b12': -0.91, 'b13': 17.6, 'c1': 2.75, 'c2': 15.7, 'c3': 8.3, 'c4': 10.2, 'c5': -12.3, 'c6': -99.5, 'c11': 0.3}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {}

def predict(X: np.ndarray, **law_constants) -> np.ndarray:
    A = float(law_constants['A'])
    b1 = float(law_constants['b1'])
    b2 = float(law_constants['b2'])
    b3 = float(law_constants['b3'])
    b4 = float(law_constants['b4'])
    b5 = float(law_constants['b5'])
    b6 = float(law_constants['b6'])
    b7 = float(law_constants['b7'])
    b11 = float(law_constants['b11'])
    b12 = float(law_constants['b12'])
    b13 = float(law_constants['b13'])
    c1 = float(law_constants['c1'])
    c2 = float(law_constants['c2'])
    c3 = float(law_constants['c3'])
    c4 = float(law_constants['c4'])
    c5 = float(law_constants['c5'])
    c6 = float(law_constants['c6'])
    c11 = float(law_constants['c11'])
    X = np.asarray(X, dtype=float)
    T = X[:, 0]
    sio2 = X[:, 1]
    tio2 = X[:, 2]
    al2o3 = X[:, 3]
    feo = X[:, 4]
    fe2o3 = X[:, 5]
    mno = X[:, 6]
    mgo = X[:, 7]
    cao = X[:, 8]
    na2o = X[:, 9]
    k2o = X[:, 10]
    p2o5 = X[:, 11]
    h2o = X[:, 12]
    feot = feo + 2.0 * fe2o3
    V = h2o
    TA = tio2 + al2o3
    FM = feot + mno + mgo
    NK = na2o + k2o
    B = b1 * (sio2 + tio2) + b2 * al2o3 + b3 * (feot + mno + p2o5) + b4 * mgo + b5 * cao + b6 * (na2o + V) + b7 * (V + np.log(1.0 + h2o)) + b11 * (sio2 + tio2) * FM + b12 * (sio2 + TA + p2o5) * (NK + h2o) + b13 * al2o3 * NK
    C = c1 * sio2 + c2 * TA + c3 * FM + c4 * cao + c5 * NK + c6 * np.log(1.0 + V) + c11 * (al2o3 + FM + cao - p2o5) * (NK + V)
    denom = T - C
    safe_denom = np.where(np.abs(denom) > 0.001, denom, np.sign(denom + 1e-10) * 0.001)
    raw = A + B / safe_denom
    TG_LOG10_ETA = 12.0
    A_FLOOR = A
    out = np.where(denom <= 0, TG_LOG10_ETA, raw)
    return np.clip(out, A_FLOOR, TG_LOG10_ETA)
