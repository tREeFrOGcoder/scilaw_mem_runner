import numpy as np

def predict(X):
    X = np.asarray(X, dtype=float)

    T = X[:, 0]
    sio2 = X[:, 1]
    tio2 = X[:, 2]
    al2o3 = X[:, 3]
    feo = X[:, 4]
    fe2o3 = X[:, 5]
    mno = X[:, 6]
    mgo = X[:, 7]
    cao = X[:, 8]
    na2o = X[:, 9]
    k2o = X[:, 10]
    p2o5 = X[:, 11]
    h2o = X[:, 12]

    # Giordano, Russell & Dingwell (2008) VFT silicate-melt viscosity model.
    # Total iron is represented as FeO-equivalent on a molar basis.
    feot = feo + 2.0 * fe2o3

    A = -4.55

    B = (
        159.56 * (sio2 + tio2)
        - 173.34 * al2o3
        + 72.13 * (feot + mno + p2o5)
        + 75.69 * mgo
        - 38.98 * cao
        - 84.08 * (na2o + k2o)
        + 141.54 * h2o
    )

    C = (
        2.75 * sio2
        + 15.72 * tio2
        + 8.32 * al2o3
        + 10.20 * (feot + mno + mgo)
        - 12.29 * cao
        - 99.54 * (na2o + k2o)
        + 0.30 * (sio2 + tio2) * (feot + mno + mgo)
        + 1.54 * (sio2 + tio2 + al2o3 + p2o5) * (na2o + k2o)
        - 0.29 * al2o3 * (na2o + k2o)
        - 0.52 * (feot + mno + mgo) * h2o
    )

    return A + B / (T - C)
