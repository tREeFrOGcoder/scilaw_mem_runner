USED_INPUTS = ['T_ei', 'T_ci', 'Q_e']
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {'Delta_S_T': {'init': None}, 'Q_leak_eqv': {'init': None}, 'R': {'init': None}}

def predict(X: np.ndarray, Delta_S_T: float, Q_leak_eqv: float, R: float) -> np.ndarray:
    T_ei = X[:, 0].astype(float)
    T_ci = X[:, 1].astype(float)
    Q_e = X[:, 2].astype(float)
    numerator = 1.0 + Delta_S_T * (T_ei / Q_e) + Q_leak_eqv * (T_ci - T_ei) / (T_ci * Q_e)
    denominator = (T_ei - R * Q_e) / T_ci
    denom_safe = np.where(np.abs(denominator) < 1e-12, np.sign(denominator + 1e-15) * 1e-12, denominator)
    u = numerator / denom_safe
    return u - 2.0
