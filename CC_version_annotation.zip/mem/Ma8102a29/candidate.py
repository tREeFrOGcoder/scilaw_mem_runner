import numpy as np

def predict(X):
    # Reversible (Carnot) refrigeration cycle relationship:
    # COP_Carnot = T_cold / (T_hot - T_cold)
    # => 1/COP = (T_hot - T_cold) / T_cold
    # => 1/COP - 1 = (T_hot - 2*T_cold) / T_cold
    T_ei = X[:, 0]   # evaporator (cold-side) inlet temperature [K]
    T_ci = X[:, 1]   # condenser (hot-side) inlet temperature [K]

    inv_COP = (T_ci - T_ei) / T_ei
    return inv_COP - 1.0
