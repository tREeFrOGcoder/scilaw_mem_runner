USED_INPUTS = ['GDP', 'TP', 'AP', 'DP', 'UR', 'AT']
LAW_CONSTANTS = {'a': 4.748, 'w_GDP': 0.566, 'w_TP': 0.914, 'w_AP': 2.741, 'w_DP': -0.052, 'w_UR': 0.484, 'w_AT': -2.318}
OTHER_CONSTANTS = {'K_OFFSET': 273.15}
LOCAL_FITTABLE = {}

def predict(X: np.ndarray, **params) -> np.ndarray:
    a = params.get('a', LAW_CONSTANTS['a'])
    w_GDP = params.get('w_GDP', LAW_CONSTANTS['w_GDP'])
    w_TP = params.get('w_TP', LAW_CONSTANTS['w_TP'])
    w_AP = params.get('w_AP', LAW_CONSTANTS['w_AP'])
    w_DP = params.get('w_DP', LAW_CONSTANTS['w_DP'])
    w_UR = params.get('w_UR', LAW_CONSTANTS['w_UR'])
    w_AT = params.get('w_AT', LAW_CONSTANTS['w_AT'])
    GDP = np.asarray(X[:, 0], dtype=float)
    TP = np.asarray(X[:, 1], dtype=float)
    AP = np.asarray(X[:, 2], dtype=float)
    DP = np.asarray(X[:, 3], dtype=float)
    UR = np.asarray(X[:, 4], dtype=float)
    AT = np.asarray(X[:, 5], dtype=float)
    AT_K = AT + _K_OFFSET
    log_CDE = a + w_GDP * np.log(GDP) + w_TP * np.log(TP) + w_AP * np.log(AP) + w_DP * np.log(DP) + w_UR * np.log(UR) + w_AT * np.log(AT_K)
    return np.exp(log_CDE)
