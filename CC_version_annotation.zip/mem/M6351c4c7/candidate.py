import numpy as np

def predict(X):
    """
    Extended STIRPAT model for national annual CO2 emissions.
    
    Standard form: I_CO2 = exp(b0) * P^b1 * A^b2 * AP^b3 * DP^b4 * UR^b5 * exp(b6 * AT)
    Log-linear:    ln(I_CO2) = b0 + b1*ln(P) + b2*ln(A) + b3*ln(AP) + b4*ln(DP) + b5*ln(UR) + b6*AT
    """
    A  = X[:, 0]   # GDP per capita (Affluence) [constant 2015 USD]
    P  = X[:, 1]   # Total population
    AP = X[:, 2]   # Active population share [%]
    DP = X[:, 3]   # Population density [persons/km2]
    UR = X[:, 4]   # Urbanization rate [%]
    AT = X[:, 5]   # Annual mean surface air temperature [°C]

    # STIRPAT elasticities / coefficients
    b0 = -2.0      # intercept
    b1 =  1.0      # population elasticity
    b2 =  0.8      # affluence elasticity
    b3 =  0.5      # active-population elasticity
    b4 = -0.1      # density elasticity (agglomeration efficiency)
    b5 =  0.3      # urbanization elasticity
    b6 = -0.02     # temperature semi-elasticity (heating demand effect)

    ln_I = (b0
            + b1 * np.log(P)
            + b2 * np.log(A)
            + b3 * np.log(AP)
            + b4 * np.log(DP)
            + b5 * np.log(UR)
            + b6 * AT)

    return np.exp(ln_I)
