import numpy as np

def predict(X):
    X = np.asarray(X, dtype=float)
    log_Kow = X[:, 6]
    foc = X[:, 13]

    # Standard hydrophobic partitioning relationship:
    #   Kd = foc * Koc   ->   log Kd = log10(foc) + log Koc
    # with the canonical linear free-energy relationship (Sabljic-type):
    #   log Koc = 0.60 * log Kow + 0.50
    log_Koc = 0.60 * log_Kow + 0.50

    foc = np.clip(foc, 1e-6, None)
    log_kd = np.log10(foc) + log_Koc
    return log_kd
