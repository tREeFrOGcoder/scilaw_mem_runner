USED_INPUTS = ['log_Kow', 'foc']
LAW_CONSTANTS = {'slope': 0.58, 'intercept': 0.06}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {}

def predict(X: np.ndarray, slope: float, intercept: float) -> np.ndarray:
    log_kow = np.asarray(X[:, 0], dtype=float)
    foc = np.clip(np.asarray(X[:, 1], dtype=float), 1e-09, None)
    return slope * log_kow + intercept + np.log10(foc)
