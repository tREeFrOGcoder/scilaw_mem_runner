import numpy as np

def predict(X):
    delta = np.asarray(X[:, 0], dtype=float)
    R = np.asarray(X[:, 1], dtype=float)

    # Hertz/Sneddon spherical-indenter contact model:
    # F = (4/3) * E/(1 - nu^2) * sqrt(R) * delta^(3/2)
    YOUNG_MODULUS_PA = 1.0
    POISSON_RATIO = 0.5

    delta_pos = np.maximum(delta, 0.0)
    E_reduced = YOUNG_MODULUS_PA / (1.0 - POISSON_RATIO**2)

    F = (4.0 / 3.0) * E_reduced * np.sqrt(R) * delta_pos**1.5
    return F
