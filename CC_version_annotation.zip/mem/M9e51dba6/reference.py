USED_INPUTS = ['indentation_m', 'R_m']
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {'E_star': {'init': None}}

def _design_col(h, R):
    h_clamped = np.maximum(h, 0.0)
    return 4.0 / 3.0 * np.sqrt(np.abs(R)) * h_clamped ** 1.5

def predict(X: np.ndarray, E_star: float) -> np.ndarray:
    h = np.asarray(X[:, 0], dtype=float)
    R = np.asarray(X[:, 1], dtype=float)
    phi = _design_col(h, R)
    return E_star * phi
