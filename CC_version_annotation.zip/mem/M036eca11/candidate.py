import numpy as np


def predict(X):
    # Inputs:
    # X[:, 0] = f_Hz (frequency in Hz)
    # X[:, 1] = B_peak_T (peak flux density in T)
    # X[:, 2] = T_C (temperature in degC)
    # X[:, 3] = waveform_id (0: sine, 1: triangle, 2: trapezoid)

    f = X[:, 0]
    B = X[:, 1]
    T = X[:, 2]
    w = X[:, 3]

    # Core loss parameters (typical for MnZn power ferrites like N87)
    alpha = 1.65
    beta = 2.55
    k0 = 1.8e-4

    # Temperature dependence (quadratic behavior with minimum loss around 75-80 °C)
    f_T = 1.0 - 0.008 * (T - 75.0) + 0.00011 * (T - 75.0) ** 2

    # Waveform shape correction factor
    # Triangular waves have slightly lower loss than sine waves for the same peak B and f.
    # Trapezoidal waves have higher loss due to faster transitions (higher dB/dt).
    f_W = np.ones_like(w)
    f_W[w == 1] = 0.88
    f_W[w == 2] = 1.25

    # Volumetric core loss in kW/m^3 (equivalent to mW/cm^3)
    P_vol = k0 * f_T * f_W * (f**alpha) * (B**beta)

    # Ensure no non-positive values before log10
    P_vol = np.clip(P_vol, a_min=1e-6, a_max=None)

    return np.log10(P_vol)
