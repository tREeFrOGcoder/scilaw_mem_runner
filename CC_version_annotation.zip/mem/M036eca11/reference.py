USED_INPUTS = ['f_Hz', 'B_peak_T']
LAW_CONSTANTS = {'K_H': 0.11351, 'K_E': 1.5515e-07}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {}

def predict(X: np.ndarray, K_H: float=0.11351, K_E: float=1.5515e-07) -> np.ndarray:
    f = np.asarray(X[:, 0], dtype=float)
    B = np.asarray(X[:, 1], dtype=float)
    P_lin = K_H * f * B * B + K_E * (f * B) * (f * B)
    return np.log10(np.maximum(P_lin, 1e-09))
