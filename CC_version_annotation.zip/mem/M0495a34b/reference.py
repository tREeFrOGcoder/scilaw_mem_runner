USED_INPUTS = ['A_s_km2']
LAW_CONSTANTS = {'a_patalas': 4.6, 'b_patalas': 0.205}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {}

def predict(X: np.ndarray, a_patalas: float, b_patalas: float) -> np.ndarray:
    A_s = X[:, 0]
    return a_patalas * np.power(A_s, b_patalas)
