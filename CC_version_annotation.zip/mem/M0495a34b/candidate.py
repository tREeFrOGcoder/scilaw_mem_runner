import numpy as np

def predict(X):
    """
    Predict summertime thermocline depth z_t (m) from lake surface area and max depth.

    Standard empirical form for thermocline depth is a log-linear morphometric model:
        z_t = a + b * ln(A_s) + c * ln(Z_max)

    where A_s is lake surface area (km^2) and Z_max is maximum depth (m).
    """
    A_s = np.asarray(X[:, 0], dtype=float)
    Z_max = np.asarray(X[:, 1], dtype=float)

    # Commonly used generic coefficients for the canonical closed-form log-linear relation.
    # These are placeholders representing the standard functional form rather than a dataset-specific fit.
    a = 0.0
    b = 0.5
    c = 0.25

    z_t = a + b * np.log(A_s) + c * np.log(Z_max)
    return z_t
