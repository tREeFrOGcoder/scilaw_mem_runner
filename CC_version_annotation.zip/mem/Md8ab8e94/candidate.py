import numpy as np

def predict(X):
    lam = X[:, 0]
    # Cauchy's dispersion formula (1836): n = A + B/lambda^2 + C/lambda^4
    A = 1.5
    B = 0.004
    C = 0.0
    return A + B / lam**2 + C / lam**4
