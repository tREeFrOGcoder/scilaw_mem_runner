USED_INPUTS = ['age']
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {'A': {'init': None}, 'B': {'init': None}}

def predict(X: np.ndarray, A: float, B: float) -> np.ndarray:
    age = np.asarray(X[:, 0], dtype=float)
    return A + B * age
