import numpy as np

# Adult Gompertz sex-specific mortality:
# m_s(x,t) = A_s(t) * exp(B_s(t) * x)
# Therefore:
# ln alpha(x,t) = ln(m_male / m_female)
#               = [ln A_m(t) - ln A_f(t)] + [B_m(t) - B_f(t)] * x
#
# The constants below are fitted Gompertz-parameter differences.  With no data,
# they are left as named coefficients in the standard closed form.

T_REF = 2000.0

LOG_A_RATIO_0 = 0.0      # ln A_m(T_REF) - ln A_f(T_REF)
LOG_A_RATIO_T = 0.0      # linear period trend in the log-level difference
B_DIFF_0 = 0.0           # B_m(T_REF) - B_f(T_REF)
B_DIFF_T = 0.0           # linear period trend in the Gompertz-slope difference


def predict(X):
    X = np.asarray(X, dtype=float)
    x = X[:, 0]
    t = X[:, 1]

    tau = t - T_REF

    log_A_ratio_t = LOG_A_RATIO_0 + LOG_A_RATIO_T * tau
    b_diff_t = B_DIFF_0 + B_DIFF_T * tau

    return log_A_ratio_t + b_diff_t * x
