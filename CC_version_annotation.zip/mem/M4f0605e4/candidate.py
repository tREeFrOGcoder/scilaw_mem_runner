import numpy as np


def predict(X):
    """Predicts tumor volume (V) in mm^3 based on the time post-implantation (t)

    using a pooled Gompertz growth model.

    Parameters:
    X : ndarray of shape (n_samples, n_features)
        X[:, 0] contains the time in days post-implantation.

    Returns:
    V : ndarray of shape (n_samples,)
        Predicted tumor volume in mm^3.
    """
    t = X[:, 0]

    # Standard Gompertz parameters tuned for pooled LLC and LM2-4LUC data
    V_0 = 3.2  # Initial tumor volume (mm^3) at t=0
    alpha = 0.31  # Initial specific growth rate (day^-1)
    beta = 0.042  # Rate of growth deceleration (day^-1)

    # Closed-form Gompertz equation
    V = V_0 * np.exp((alpha / beta) * (1.0 - np.exp(-beta * t)))

    return V
