USED_INPUTS = ['time_day']
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {'surf_exp': 2.0 / 3.0, 'V0': 1.0}
LOCAL_FITTABLE = {'a': {'init': None}, 'b': {'init': None}, 'K0': {'init': None}}

def _solve(t_eval: np.ndarray, V0: float, a: float, b: float, K0: float) -> np.ndarray:
    surf = OTHER_CONSTANTS['surf_exp']
    t_span = (0.0, float(np.max(t_eval)))
    y0 = [V0, K0]

    def rhs(t, y):
        V, K = y
        V = max(V, 1e-12)
        K = max(K, V * 1e-12)
        dVdt = a * V * np.log(K / V)
        dKdt = b * V ** surf
        return [dVdt, dKdt]
    try:
        sol = solve_ivp(rhs, t_span, y0, t_eval=np.sort(t_eval), method='RK45', rtol=1e-06, atol=1e-09, dense_output=False)
        if sol.success:
            sort_idx = np.argsort(t_eval)
            inv_idx = np.argsort(sort_idx)
            return sol.y[0][inv_idx]
        else:
            return np.full_like(t_eval, V0, dtype=float)
    except Exception:
        return np.full_like(t_eval, V0, dtype=float)

def predict(X: np.ndarray, a: float, b: float, K0: float) -> np.ndarray:
    V0 = OTHER_CONSTANTS['V0']
    t = np.asarray(X[:, 0], dtype=float)
    return _solve(t, V0, a, b, K0)
