import numpy as np

def predict(X):
    # Manning's equation (SI form) as the canonical closed form for
    # cross-section mean velocity: V = (1/n) * R^(2/3) * S^(1/2)
    R = X[:, 0]
    S = X[:, 1]
    n = 0.035  # representative Manning roughness coefficient
    R = np.clip(R, 0.0, None)
    S = np.clip(S, 0.0, None)
    V = (1.0 / n) * np.power(R, 2.0 / 3.0) * np.sqrt(S)
    return V
