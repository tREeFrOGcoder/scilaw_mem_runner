import numpy as np

def predict(X):
    age = X[:, 0]
    year = X[:, 1]
    
    # Fitted coefficients based on common demographic models
    a = -0.1  # Example coefficient for age effect
    b = 0.05  # Example coefficient for year effect
    c = 8.0   # Intercept
    
    ln_m = c + a * age + b * (year - 1950)
    
    return ln_m
