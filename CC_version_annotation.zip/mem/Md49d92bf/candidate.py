import numpy as np

def predict(X):
    delta = X[:, 0]
    VEC = X[:, 1]
    dHmix = X[:, 2]

    # Empirical closed-form form commonly used for refractory/HEA hardness trends:
    # hardness increases with lattice distortion and decreases with higher VEC,
    # with a modest stabilization/strengthening contribution from more negative mixing enthalpy.
    HV = 20.0 + 8.0 * delta - 12.0 * (VEC - 5.0) - 0.6 * dHmix

    return HV
