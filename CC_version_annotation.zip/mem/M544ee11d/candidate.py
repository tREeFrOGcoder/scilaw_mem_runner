import numpy as np

def predict(X):
    """
    Predicts the room-temperature Vickers hardness (HV) of refractory or 
    complex-concentrated high-entropy alloys using an empirical linear model 
    based on atomic-size mismatch (delta), valence electron concentration (VEC), 
    and Miedema enthalpy of mixing (dHmix).
    """
    delta = X[:, 0]
    VEC = X[:, 1]
    dHmix = X[:, 2]
    
    # Empirical multiple linear regression coefficients
    # Intercept (base hardness)
    C0 = 450.0  
    # Lattice distortion strengthening coefficient (positive effect)
    C_delta = 35.0 
    # Electronic structure / phase stability coefficient (higher VEC typically 
    # promotes softer FCC phases or reduces BCC refractory strength)
    C_VEC = -50.0  
    # Mixing enthalpy coefficient (more negative dHmix implies stronger 
    # cross-element bonding / short-range order, increasing hardness)
    C_dHmix = -3.5 
    
    HV = C0 + C_delta * delta + C_VEC * VEC + C_dHmix * dHmix
    
    return HV
