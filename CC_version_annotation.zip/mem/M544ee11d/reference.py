USED_INPUTS = ['VEC', 'dHmix']
LAW_CONSTANTS = {'a': -122.18, 'b_VEC': 109.75, 'c_dHmix': -11.23}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {}

def predict(X: np.ndarray, a: float, b_VEC: float, c_dHmix: float) -> np.ndarray:
    VEC = X[:, 0]
    dHmix = X[:, 1]
    return a + b_VEC * VEC + c_dHmix * dHmix
