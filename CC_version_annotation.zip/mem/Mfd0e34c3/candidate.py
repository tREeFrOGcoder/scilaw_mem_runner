import numpy as np

def predict(X):
    z = X[:, 0]
    
    # Cosmological parameters (canonical flat w0waCDM from Linder 2003)
    c = 299792.458  # speed of light in km/s
    H0 = 70.0       # Hubble constant in km/s/Mpc
    Om = 0.3        # Matter density parameter
    Ode = 0.7       # Dark energy density parameter
    w0 = -1.0       # Present dark energy equation of state
    wa = 0.0        # Evolution of dark energy equation of state
    
    # Linder (2003) dark energy density evolution:
    # rho_de(z) = Ode * (1+z)^(3*(1+w0+wa)) * exp(-3 * wa * z / (1+z))
    
    # To compute the luminosity distance d_L, we integrate 1/H(z) from 0 to z.
    # We use a fine grid for numerical integration (as no elementary closed form exists for the general CPL integral).
    z_max = np.max(z) if len(z) > 0 else 1.0
    # Ensure z_max is at least slightly above 0
    z_max = max(z_max, 1e-5)
    
    N_grid = 2000
    z_grid = np.linspace(0, z_max, N_grid)
    dz = z_grid[1] - z_grid[0]
    
    # Hubble parameter H(z)
    H_grid = H0 * np.sqrt(
        Om * (1.0 + z_grid)**3 + 
        Ode * (1.0 + z_grid)**(3.0 * (1.0 + w0 + wa)) * np.exp(-3.0 * wa * z_grid / (1.0 + z_grid))
    )
    
    # Comoving distance integral: integral of dz / H(z)
    integrand = 1.0 / H_grid
    # Cumulative integral using the trapezoidal rule
    comoving_grid = np.cumsum(integrand) * dz
    # Adjust for trapezoidal rule offset (approximate, fine for large N_grid)
    comoving_grid -= 0.5 * (integrand[0] + integrand) * dz 
    comoving_grid[0] = 0.0
    
    # Interpolate to get the comoving distance at the requested redshifts
    comoving = np.interp(z, z_grid, comoving_grid)
    
    # Luminosity distance in Mpc
    d_L = (1.0 + z) * comoving
    
    # Distance modulus mu = 5 * log10(d_L / 10 pc)
    # Since d_L is in Mpc, 10 pc = 1e-5 Mpc, so mu = 5 * log10(d_L) + 25
    mu = 5.0 * np.log10(d_L) + 25.0
    
    return mu
