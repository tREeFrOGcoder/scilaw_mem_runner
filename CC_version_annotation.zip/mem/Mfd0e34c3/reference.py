USED_INPUTS = ['z_hd']
LAW_CONSTANTS = {'H0': 73.04, 'Om': 0.334, 'w0': -1.0, 'wa': 0.0}
OTHER_CONSTANTS = {'c_km_s': 299792.458}
LOCAL_FITTABLE = {}

def _dL_Mpc(z: np.ndarray, H0: float, Om: float, w0: float, wa: float) -> np.ndarray:
    c_km_s = OTHER_CONSTANTS['c_km_s']
    z_half = z[:, None] / 2.0
    z_nodes = z_half * (_GL_X[None, :] + 1.0)
    weights = z_half * _GL_W[None, :]
    zp1 = 1.0 + z_nodes
    X_DE = zp1 ** (3.0 * (1.0 + w0 + wa)) * np.exp(-3.0 * wa * z_nodes / zp1)
    E2 = Om * zp1 ** 3 + (1.0 - Om) * X_DE
    E = np.sqrt(np.maximum(E2, 1e-30))
    eta_Mpc = np.sum(weights / E, axis=1) * (c_km_s / H0)
    return (1.0 + z) * eta_Mpc

def predict(X: np.ndarray, H0: float, Om: float, w0: float, wa: float) -> np.ndarray:
    z = np.asarray(X[:, 0], dtype=float)
    dL = _dL_Mpc(z, H0=H0, Om=Om, w0=w0, wa=wa)
    return 5.0 * np.log10(np.maximum(dL, 1e-30)) + 25.0
