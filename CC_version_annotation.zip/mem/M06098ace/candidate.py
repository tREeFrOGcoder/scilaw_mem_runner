import numpy as np

def predict(X):
    """
    Predict log10(T_ij + 1) using the canonical radiation model (Simini et al. 2012).
    Inputs (X columns):
      X[:,0] = m_i  (total resident workers at origin; here also T_i)
      X[:,1] = m_j  (total jobs at destination)
      X[:,2] = d_ij_km (distance, not used by the pure radiation model)
      X[:,3] = s_ij (intervening opportunities: total workers in circle excluding i and j)
    Returns:
      1-D numpy array of log10(T_ij + 1)
    Formula:
      T_ij = T_i * (m_i * m_j) / ((m_i + s_ij) * (m_i + m_j + s_ij))
      Here T_i is the total outflow from i; given input m_i is the total resident workers
      (sum of outbound flows), we set T_i = m_i.
    """
    X = np.asarray(X, dtype=float)
    if X.ndim == 1:
        X = X.reshape(1, -1)
    m_i = X[:, 0]
    m_j = X[:, 1]
    # d_ij_km = X[:, 2]  # distance not used in the pure radiation model
    s_ij = X[:, 3]

    # Ensure non-negative and avoid division by zero numerically
    m_i = np.maximum(m_i, 0.0)
    m_j = np.maximum(m_j, 0.0)
    s_ij = np.maximum(s_ij, 0.0)

    denom = (m_i + s_ij) * (m_i + m_j + s_ij)
    # Small epsilon to avoid any potential divide-by-zero (shouldn't be needed with given ranges)
    eps = 1e-12
    Tij = m_i * (m_i * m_j) / (denom + eps)

    # Return log10(Tij + 1)
    return np.log10(Tij + 1.0)
