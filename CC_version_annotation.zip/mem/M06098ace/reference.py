USED_INPUTS = ['m_i', 'm_j', 's_ij']
LAW_CONSTANTS = {'alpha': 1.91, 'Nc_over_N': 1.0}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {}

def predict(X: np.ndarray, alpha: float=1.91, Nc_over_N: float=1.0) -> np.ndarray:
    m_i = np.asarray(X[:, 0], dtype=float)
    m_j = np.asarray(X[:, 1], dtype=float)
    s_ij = np.asarray(X[:, 2], dtype=float)
    A = m_i + s_ij
    B = m_i + m_j + s_ij
    A_a = np.power(np.maximum(A, 0.0), alpha)
    B_a = np.power(np.maximum(B, 0.0), alpha)
    mi_a = np.power(np.maximum(m_i, 0.0), alpha)
    numer = (B_a - A_a) * (mi_a + 1.0)
    denom = (A_a + 1.0) * (B_a + 1.0)
    P = np.where(denom > 0.0, numer / denom, 0.0)
    T_i = Nc_over_N * m_i
    T_ij = np.clip(T_i * P, 0.0, None)
    return np.log10(T_ij + 1.0)
