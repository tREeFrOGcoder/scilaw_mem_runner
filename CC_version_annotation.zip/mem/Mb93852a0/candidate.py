import numpy as np

def predict(X):
    """
    Abbott-corrected mortality (P) of third-instar Culex larvae after 48 h
    exposure to Lysinibacillus sphaericus, modeled with the canonical
    log-logistic (Hill) dose-response relationship in natural-log form:

        P = 1 / (1 + exp( beta * (ln(LC50) - ln(C)) ))

    Parameters are representative literature values for susceptible Culex
    quinquefasciatus third-instar larvae exposed to Ls for 48 h.
    """
    ln_C = X[:, 1]               # natural log of concentration (ppb)

    LC50 = 50.0                  # ppb, typical 48-h LC50 for susceptible Culex 3rd instar
    beta = 2.5                   # slope (proportional to Hill coefficient n)

    P = 1.0 / (1.0 + np.exp(beta * (np.log(LC50) - ln_C)))
    return P
