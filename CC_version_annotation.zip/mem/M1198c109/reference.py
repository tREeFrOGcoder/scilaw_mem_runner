USED_INPUTS = ['nu_max', 'Teff']
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {'delta_nu_sun': 134.9, 'nu_max_sun': 3090.0, 'Teff_sun': 5777.0, 'M_RG_canonical': 1.2}
LOCAL_FITTABLE = {}

def predict(X: np.ndarray) -> np.ndarray:
    delta_nu_sun = OTHER_CONSTANTS['delta_nu_sun']
    nu_max_sun = OTHER_CONSTANTS['nu_max_sun']
    Teff_sun = OTHER_CONSTANTS['Teff_sun']
    M_RG_canonical = OTHER_CONSTANTS['M_RG_canonical']
    nu_max = np.asarray(X[:, 0], dtype=float)
    Teff = np.asarray(X[:, 1], dtype=float)
    mass_factor = float(M_RG_canonical) ** (-0.25)
    return float(delta_nu_sun) * (nu_max / float(nu_max_sun)) ** (3.0 / 4.0) * (Teff / float(Teff_sun)) ** (3.0 / 8.0) * mass_factor
