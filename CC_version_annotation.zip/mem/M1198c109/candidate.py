import numpy as np

def predict(X):
    nu_max = X[:, 0]
    Teff = X[:, 1]

    # Solar reference values (standard asteroseismic references)
    nu_max_sun = 3090.0   # uHz
    delta_nu_sun = 135.1  # uHz
    Teff_sun = 5777.0     # K

    # Canonical scaling relation derived from Brown et al. (1991):
    #   delta_nu / delta_nu_sun = (M/M_sun)^(1/2) (R/R_sun)^(-3/2)
    #   nu_max / nu_max_sun     = (M/M_sun)       (R/R_sun)^(-2) (Teff/Teff_sun)^(-1/2)
    #
    # Eliminating R and assuming M ~ M_sun (valid for typical red giants):
    #   delta_nu / delta_nu_sun = (nu_max / nu_max_sun)^(3/4) * (Teff / Teff_sun)^(3/8)
    delta_nu = delta_nu_sun * (nu_max / nu_max_sun)**0.75 * (Teff / Teff_sun)**0.375

    return delta_nu
