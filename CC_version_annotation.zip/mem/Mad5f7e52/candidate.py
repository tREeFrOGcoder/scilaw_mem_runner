import numpy as np

def predict(X):
    Q_alpha_MeV = X[:, 0]
    log10_half_life_s = (1.66 / Q_alpha_MeV) + 0.5
    return log10_half_life_s
