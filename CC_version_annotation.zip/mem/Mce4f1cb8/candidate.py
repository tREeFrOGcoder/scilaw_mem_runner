import numpy as np

def predict(X):
    # Priestley-Taylor / energy-balance style latent heat flux estimate
    # Inputs:
    # X[:,0]  SWdown
    # X[:,1]  VPD
    # X[:,2]  Tair
    # X[:,3]  RH
    # X[:,4]  Wind
    # X[:,5]  Rnet
    # X[:,6]  Qg
    # X[:,7]  LAI
    # X[:,8]  LWdown
    # X[:,9]  Ga
    # X[:,10] delta
    # X[:,11] theta_FC
    # X[:,12] theta_WP

    Rn = X[:, 5]
    G = X[:, 6]
    delta = X[:, 10]

    # Psychrometric constant (kPa K^-1), using standard atmospheric pressure
    gamma = 0.066

    # Priestley-Taylor coefficient for wet/reference vegetated surfaces
    alpha_PT = 1.26

    # Available energy
    A = Rn - G

    # Latent heat flux (W m^-2) proxy
    LE = alpha_PT * (delta / (delta + gamma)) * A

    return LE
