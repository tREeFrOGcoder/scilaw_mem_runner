USED_INPUTS = ['R', 'RA']
LAW_CONSTANTS = {'gamma': 2.0}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {}

def predict(X: np.ndarray, gamma: float) -> np.ndarray:
    R = np.asarray(X[:, 0], dtype=float)
    RA = np.asarray(X[:, 1], dtype=float)
    Rg = np.power(R, gamma)
    RAg = np.power(RA, gamma)
    return Rg / (Rg + RAg)
