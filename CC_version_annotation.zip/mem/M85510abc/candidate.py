import numpy as np

def predict(X):
    # Calculate the win percentage (W%) using the Pythagorean expectation formula
    # W% = R^2 / (R^2 + RA^2)
    R = X[:, 0]
    RA = X[:, 1]
    win_pct = (R**2) / (R**2 + RA**2)
    return win_pct
