import numpy as np

def predict(X):
    """
    Predict melt pool depth d [um] from laser power P [W], scan velocity V [mm/s],
    and beam diameter D [um] using a conduction-mode energy balance model.

    d = (eta * P) / (V * D * rho * cp * (Tm - T0)) * (2/pi)   [all in SI, then converted to um]
    """
    # Unpack inputs
    P = X[:, 0]   # laser power [W]
    V = X[:, 1]   # scan velocity [mm/s]
    D = X[:, 2]   # beam diameter (D4sigma) [um]

    # Material constants (typical values for Ti-6Al-4V)
    eta = 0.35          # absorptivity [-]
    rho = 4420.0        # density [kg/m^3]
    cp  = 560.0         # specific heat capacity [J/(kg*K)]
    Tm  = 1923.0        # melting temperature [K]
    T0  = 300.0         # pre-heat / ambient temperature [K]
    shape_factor = 2.0 / np.pi   # geometric factor for a moving line source

    # Convert inputs to SI units
    V_ms = V * 1e-3      # m/s
    D_m  = D * 1e-6      # m

    # Melt pool depth in meters
    d_m = (eta * P) / (V_ms * D_m * rho * cp * (Tm - T0)) * shape_factor

    # Convert to micrometers
    d_um = d_m * 1e6
    return d_um
