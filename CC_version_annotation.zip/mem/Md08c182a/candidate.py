import numpy as np

def predict(X):
    X = np.asarray(X)
    log_distance_km = X[:, 0]

    intercept = 0.0
    slope = 1.0

    M = intercept + slope * log_distance_km
    return M
