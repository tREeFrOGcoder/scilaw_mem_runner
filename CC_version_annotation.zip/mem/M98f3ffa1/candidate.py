import numpy as np

def predict(X):
    X = np.asarray(X)
    k = X[:, 0].astype(float)

    Q0_AH = 1.0          # fitted begin-of-life discharge capacity [Ah]
    A_AH = 1.0e-3        # fitted cycle-aging coefficient [Ah / cycle^beta]
    BETA = 0.5           # common diffusion/SEI-limited capacity-fade exponent

    Q = Q0_AH - A_AH * np.power(np.maximum(k - 1.0, 0.0), BETA)
    return Q
