USED_INPUTS = ['cycle_index']
LAW_CONSTANTS = {'A': 2.0288, 'B': -0.003649, 'C': 0.0042, 'D': 0.02736}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {}

def predict(X: np.ndarray, A: float=2.0288, B: float=-0.003649, C: float=0.0042, D: float=0.02736) -> np.ndarray:
    k = np.asarray(X[:, 0], dtype=float)
    return A * np.exp(B * k) + C * np.exp(D * k)
