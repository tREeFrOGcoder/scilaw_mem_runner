import numpy as np

def predict(X):
    """
    dE/dX along the shower axis, described by the standard
    Gaisser-Hillas function (Aab et al. 2019, JCAP 2019:018).

        dE/dX(X) = (dE/dX)_max * ((X - X0)/(Xmax - X0))^((Xmax - X0)/lambda)
                                * exp((Xmax - X)/lambda)

    Units: X in g/cm^2, dE/dX in PeV/(g/cm^2).
    """
    x = np.asarray(X[:, 0], dtype=float)

    # Canonical fitted shower parameters (typical ~10^19 eV EAS)
    dEdX_max = 40.0     # PeV/(g/cm^2)  -- peak energy deposit
    Xmax     = 750.0    # g/cm^2        -- depth of shower maximum
    X0       = -100.0   # g/cm^2        -- effective first-interaction depth
    lam      = 60.0     # g/cm^2        -- profile width parameter

    z    = (x - X0) / (Xmax - X0)
    expo = (Xmax - X0) / lam

    val = np.zeros_like(x)
    good = z > 0.0
    val[good] = dEdX_max * np.power(z[good], expo) * np.exp((Xmax - x[good]) / lam)

    return val
