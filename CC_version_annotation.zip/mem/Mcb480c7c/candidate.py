import numpy as np


def predict(X):
    # X[:, 0] contains the calendar year (t)
    t = X[:, 0]

    # Oeppen and Vaupel (2002) canonical linear relationship for record life expectancy.
    # The record life expectancy has risen linearly at a rate of ~0.243 years per year
    # (or 2.43 years per decade) since 1840.
    # e0(t) = 0.243 * t - 402.7
    e0 = 0.243 * t - 402.7

    return e0
