USED_INPUTS = ['year']
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {'year_center': 1900.0}
LOCAL_FITTABLE = {'a': {'init': None}, 'b': {'init': None}}

def predict(X: np.ndarray, a: float, b: float) -> np.ndarray:
    yc = OTHER_CONSTANTS['year_center']
    year = np.asarray(X[:, 0], dtype=float)
    return a + b * (year - yc)
