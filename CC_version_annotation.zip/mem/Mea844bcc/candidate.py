import numpy as np

def predict(X):
    # Constants
    alpha = 0.1  # empirical coefficient related to the energy balance
    beta = 0.3   # empirical coefficient related to vapor pressure deficit
    k = 2.0      # empirical coefficient related to temperature and humidity
    c = 0.5      # correction factor based on leaf area index
    
    SWdown = X[:, 0]  # Downward shortwave radiation
    VPD = X[:, 1]     # Vapour pressure deficit
    Tair = X[:, 2]    # Near-surface air temperature
    RH = X[:, 3]      # Relative humidity
    Wind = X[:, 4]    # Scalar wind speed
    Rnet = X[:, 5]    # Net radiation
    Qg = X[:, 6]      # Soil heat flux
    LAI = X[:, 7]     # Leaf area index
    LWdown = X[:, 8]  # Downward longwave radiation
    Ga = X[:, 9]      # Aerodynamic conductance
    delta = X[:, 10]  # Slope of the saturation vapour pressure curve
    theta_FC = X[:, 11]  # Field-capacity volumetric soil water content
    theta_WP = X[:, 12]   # Wilting-point volumetric soil water content

    # Estimate latent heat flux (λE) using the energy balance equation
    LE = (alpha * SWdown + beta * VPD * (1 - RH) + k * (Tair - 273.15) * Wind - c * (Rnet - Qg + LWdown)) * LAI

    return LE
