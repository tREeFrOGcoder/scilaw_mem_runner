USED_INPUTS = ['lambda11', 'lambda22']
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {'alpha': {'init': None}, 'beta': {'init': None}}

def _sigma11(lam1, lam2, alpha, beta):
    lam3_sq = (lam1 * lam2) ** (-2.0)
    I1 = lam1 ** 2 + lam2 ** 2 + lam3_sq
    arg = np.clip(alpha * (I1 - 3.0), -700.0, 700.0)
    return beta * (lam1 ** 2 - lam3_sq) * np.exp(arg)

def predict(X: np.ndarray, alpha: float, beta: float) -> np.ndarray:
    lam1 = np.asarray(X[:, 0], dtype=float)
    lam2 = np.asarray(X[:, 1], dtype=float)
    return _sigma11(lam1, lam2, alpha, beta)
