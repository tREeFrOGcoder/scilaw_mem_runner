import numpy as np

def predict(X):
    lambda11 = X[:, 0]
    lambda22 = X[:, 1]
    
    # Constants for the material properties (example values)
    mu = 1.0  # shear modulus [MPa]
    kappa = 1.0  # bulk modulus [MPa]
    
    # Cauchy stress in the first principal direction (σ₁₁)
    sigma11 = (mu * (lambda11 - 1) / lambda11) + (kappa * (lambda22 - 1) / lambda22)
    
    return sigma11
