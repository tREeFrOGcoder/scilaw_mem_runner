import numpy as np

def predict(X):
    s = np.asarray(X)[:, 0]
    m = 0.9382720813  # proton mass in GeV
    nu = (s - 2.0 * m * m) / (2.0 * m)  # lab energy; exact high-energy relation used in BHS parametrization
    nu0 = 7.59  # GeV, fitted scale in Block-Halzen (2005)
    s0 = 4.0 * m * m * nu0 * nu0  # equivalent scale in GeV^2
    # Canonical Block-Halzen form for pp total cross section (mb)
    return (
        45.924
        - 3.801 * (2.0 * m * m / s) ** 0.5
        + 0.09924 * np.log(nu / nu0)
        + 0.8454 * np.log(nu / nu0) ** 2
    )
