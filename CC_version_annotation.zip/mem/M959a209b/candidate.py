import numpy as np

def predict(X):
    m = X[:, 0]
    S = X[:, 1]
    return 4.77 * np.power(m, 0.16) * np.power(S, -0.34)
