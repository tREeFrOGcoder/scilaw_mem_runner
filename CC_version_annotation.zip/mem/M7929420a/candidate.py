import numpy as np

def predict(X):
    # Temperature in K
    T = X[:, 0]
    
    # Convert oxide compositions from mol% to mole fraction
    SiO2 = X[:, 1] / 100.0
    TiO2 = X[:, 2] / 100.0
    Al2O3 = X[:, 3] / 100.0
    FeO = X[:, 4] / 100.0
    Fe2O3 = X[:, 5] / 100.0
    MnO = X[:, 6] / 100.0
    MgO = X[:, 7] / 100.0
    CaO = X[:, 8] / 100.0
    Na2O = X[:, 9] / 100.0
    K2O = X[:, 10] / 100.0
    P2O5 = X[:, 11] / 100.0
    H2O = X[:, 12] / 100.0
    
    # Giordano, Russell, and Dingwell (2008) Vogel-Fulcher-Tammann (VFT) model structure
    # log10(eta) = A + B / (T - C)
    # Coefficients below are representative reconstructions of the canonical GRD2008 parameterization
    
    # Parameter A (high-temperature asymptotic limit, often constrained near the Frenkel limit)
    A = -4.55 
    
    # Parameter B (pseudo-activation energy term, strongly dependent on network formers and H2O)
    B = (13000.0 * SiO2 + 11000.0 * TiO2 + 14000.0 * Al2O3 + 
         16000.0 * (FeO + Fe2O3 + MnO + MgO + CaO) + 
         6000.0 * (Na2O + K2O) + 12000.0 * P2O5 - 25000.0 * H2O)
         
    # Parameter C (Vogel temperature / ideal glass transition temperature offset)
    C = (250.0 * SiO2 + 200.0 * TiO2 + 350.0 * Al2O3 + 
         150.0 * (FeO + Fe2O3 + MnO + MgO + CaO) + 
         450.0 * (Na2O + K2O) + 250.0 * P2O5 - 150.0 * H2O)
         
    # Calculate log10 of dynamic viscosity
    log_viscosity = A + B / (T - C)
    
    return log_viscosity
