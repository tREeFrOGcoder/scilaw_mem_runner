import numpy as np

def predict(X):
    delta = X[:, 0]
    R = X[:, 1]
    
    # Hertzian contact model for a spherical indenter on an elastic half-space:
    # F = (4/3) * E_eff * sqrt(R) * delta^(3/2)
    # Since only geometry is provided (no modulus), use the standard closed-form
    # proportional relation with a unit effective modulus constant.
    E_eff = 1.0
    F = (4.0 / 3.0) * E_eff * np.sqrt(R) * np.power(delta, 1.5)
    return F
