import numpy as np

def predict(X):
    X = np.asarray(X, dtype=float)

    I_prev = np.maximum(X[:, 0], 0.0)
    s = ((np.rint(X[:, 1]).astype(int) - 1) % 26)
    B = np.maximum(X[:, 2], 1e-12)
    N = np.maximum(10.0 ** X[:, 3], 1e-12)
    z = X[:, 4]

    # Canonical deterministic TSIR form:
    #   E[I_t] = beta_s * (S_t / N) * I_{t-1}^alpha
    #   S_t    = Sbar + z_t
    ALPHA = 0.97
    R0_MEAN = 15.0

    # Simple term-time seasonal forcing over 26 biweeks, normalized to mean 1.
    holiday = np.zeros(26, dtype=bool)
    holiday[[0, 6, 7, 14, 15, 16, 17, 25]] = True
    term_factor = 1.10
    holiday_factor = (26.0 - term_factor * np.sum(~holiday)) / np.sum(holiday)

    seasonal = np.empty(26)
    seasonal[~holiday] = term_factor
    seasonal[holiday] = holiday_factor

    beta_s = R0_MEAN * seasonal[s]

    # Endemic mean susceptible approximation, with z_t as reconstructed deviation.
    Sbar = N * np.power(B, 1.0 - ALPHA) / R0_MEAN
    S = np.maximum(Sbar + z, 0.0)

    return beta_s * (S / N) * np.power(I_prev, ALPHA)
