import numpy as np

def predict(X):
    """
    Standard closed-form scaling relation for dynamically measured supermassive 
    black hole mass, combining the M-sigma and M-M_sph relations with 
    a bulge-to-total correction and a pseudobulge offset. 
    Coefficients are drawn from the consensus literature (e.g., Kormendy & Ho 2013;
    Graham & Scott 2013; Sahu et al. 2019; Jin & Davis 2023).
    """
    # Unpack inputs
    sigma0 = X[:, 0]          # central stellar velocity dispersion [km/s]
    logM_sph = X[:, 1]        # log10(spheroid stellar mass / M_sun)
    B_T = X[:, 2]             # bulge-to-total luminosity ratio (0 < B_T <= 1)
    Pseudobulge = X[:, 3]     # 1 for pseudobulge, 0 for classical bulge/elliptical

    # Fitted coefficients (typical values from multi-variate regressions)
    # Intercept for classical bulges (sigma = 200 km/s, M_sph = 10^11 M_sun, B_T=1)
    A = 8.20                   
    # M-sigma slope
    B = 4.00                   
    # M-M_sph slope (complementary to sigma)
    C = 0.50                   
    # Bulge-to-total ratio slope
    D = 0.35                   
    # Pseudobulge offset (pseudobulges host systematically lower mass BHs)
    E = -0.60                  

    # Reference values for scaling
    sigma_ref = 200.0          # km/s
    M_sph_ref = 11.0           # log10(M_sph/M_sun)

    logM_BH = (A 
               + B * np.log10(sigma0 / sigma_ref) 
               + C * (logM_sph - M_sph_ref) 
               + D * np.log10(B_T) 
               + E * Pseudobulge)
    return logM_BH
