import numpy as np

def predict(X):
    """
    Predicts the Voigt-Reuss-Hill average polycrystalline bulk modulus (K_VRH)
    using the standard empirical scaling law based on atomic volume.
    
    The most commonly cited canonical form for bulk modulus scaling in solids 
    relates K to the atomic volume via a power law (e.g., from cohesive energy 
    density or Lennard-Jones/Cohen scaling): K ∝ V_a^(-4/3). 
    For simplicity and physical robustness, we use this universal scaling.
    
    Inputs:
    X[:, 0] = V_atomic_A3 (V_a) [angstrom^3]
    X[:, 1] = M_avg_amu (M_avg) [amu]
    X[:, 2] = density_g_cm3 (rho) [g/cm^3]
    X[:, 3] = crystal_system_id (cs)
    """
    V_a = X[:, 0]
    
    # Empirical constant derived from typical cohesive energy densities
    # Typical K ~ 100-200 GPa for V_a ~ 10-20 A^3
    C = 2000.0  # GPa * A^4
    
    # K_VRH = C * V_a^(-4/3)
    K_VRH = C * np.power(V_a, -4.0 / 3.0)
    
    return K_VRH
