USED_INPUTS = ['P_bar']
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {'q_m': {'init': None}, 'b': {'init': None}}

def _q_co2(P, q_m, b):
    bP = b * np.asarray(P, dtype=float)
    return q_m * bP / (1.0 + bP)

def predict(X: np.ndarray, q_m: float, b: float) -> np.ndarray:
    P = np.asarray(X[:, 0], dtype=float)
    return _q_co2(P, q_m, b)
