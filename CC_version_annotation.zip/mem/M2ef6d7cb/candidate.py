import numpy as np

def predict(X):
    P = X[:, 0]  # CO2 equilibrium partial pressure in bar
    # Constants from Swenson Stadie (2019) for the canonical form
    q_max = 5.0  # maximum adsorption capacity in mmol/g (example value)
    b = 0.5      # Langmuir constant (example value)
    
    # Langmuir isotherm equation for CO2 adsorption
    q = (q_max * b * P) / (1 + b * P)
    
    return q
