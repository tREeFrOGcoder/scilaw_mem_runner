import numpy as np

def predict(X):
    """
    Predicts the binding energy (term value) of a Rydberg level in cm^-1.
    Uses the standard Rydberg formula. In the absence of specific quantum 
    defect coefficients for a particular element, the hydrogenic limit 
    (where the quantum defect delta_l = 0) is used, making the binding 
    energy depend only on the principal quantum number n.
    """
    n = X[:, 0]
    # l = X[:, 1] is not used in the hydrogenic limit, as energy depends only on n.
    
    # Rydberg constant in cm^-1
    R_inf = 109737.31 
    
    # Rydberg formula: E_bind = R_inf / (n - delta_l)^2
    # Assuming delta_l = 0 for the generic closed-form relationship
    E_bind = R_inf / (n ** 2)
    
    return E_bind
