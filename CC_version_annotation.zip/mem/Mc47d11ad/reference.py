USED_INPUTS = ['gdppc']
LAW_CONSTANTS = {'alpha': 2.9920451796666057, 'beta': -0.7487360435089442}
OTHER_CONSTANTS = {'ceiling': 80.0}
LOCAL_FITTABLE = {}

def predict(X: np.ndarray, alpha: float, beta: float) -> np.ndarray:
    ceiling = OTHER_CONSTANTS['ceiling']
    Y = np.asarray(X[:, 0], dtype=float)
    log_Y = np.log(Y)
    return ceiling / (1.0 + np.exp(alpha + beta * log_Y))
