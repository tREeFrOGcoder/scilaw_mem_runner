import numpy as np

def predict(X):
    """
    Predicts sex-averaged life expectancy at birth (e0) based on Preston (1975) 
    cross-sectional relation for the 1960s.
    
    Preston, S. H. (1975). "The changing relation between mortality and level of 
    economic development." Population Studies, 29(2), 231-248.
    
    The fitted relation is of the form:
    e0 = a + b * ln(gdppc)
    where gdppc is national income per head in constant 1963 US dollars.
    """
    gdppc = X[:, 0]
    
    # Canonical fitted coefficients for the 1960s cross-section
    a = 22.0
    b = 6.4
    
    e0 = a + b * np.log(gdppc)
    
    return e0
