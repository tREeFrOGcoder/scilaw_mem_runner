import numpy as np

def predict(X):
    """
    Empirical accretion-luminosity relation for pre-main-sequence
    (T Tauri) stars from UV-excess / Balmer-continuum slab modelling.

    The most commonly cited closed form (e.g. Alcala et al. 2017, Lupus
    X-shooter survey) is a linear correlation in log-log space between the
    accretion luminosity and the stellar bolometric luminosity:

        log(L_acc/L_sun) = a * log(L_star/L_sun) + b

    with slope a ~ 1.9 and intercept b ~ -0.5.
    """
    logL_star = X[:, 0]          # log(L_star/L_sun)
    # M_star = X[:, 1]           # not used in canonical L_acc-L_star relation
    # R_star = X[:, 2]           # not used
    # Teff   = X[:, 3]           # not used

    a = 1.9    # slope
    b = -0.5   # intercept

    logL_acc = a * logL_star + b
    return logL_acc
