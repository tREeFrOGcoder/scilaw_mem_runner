USED_INPUTS = ['logL_star']
LAW_CONSTANTS = {'slope': 1.9, 'intercept': -0.8}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {}

def predict(X: np.ndarray, slope: float, intercept: float) -> np.ndarray:
    logL_star = np.asarray(X[:, 0], dtype=float)
    return slope * logL_star + intercept
