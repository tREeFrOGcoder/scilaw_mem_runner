import numpy as np


def predict(X):
    # Extract inputs
    SWdown = X[:, 0]
    VPD = X[:, 1]
    Tair = X[:, 2]
    RH = X[:, 3]
    Wind = X[:, 4]
    Rnet = X[:, 5]
    Qg = X[:, 6]
    LAI = X[:, 7]
    LWdown = X[:, 8]
    Ga = X[:, 9]
    delta = X[:, 10]
    theta_FC = X[:, 11]
    theta_WP = X[:, 12]

    # Physical constants
    Cp = 1005.0  # Specific heat of air [J kg^-1 K^-1]
    Rd = 287.05  # Gas constant for dry air [J kg^-1 K^-1]
    P = 101.325  # Standard atmospheric pressure [kPa]

    # Air density [kg m^-3]
    rho_a = (P * 1000.0) / (Rd * Tair)

    # Psychrometric constant [kPa K^-1]
    gamma = 0.066

    # Estimate canopy conductance Gs [m s^-1] using a Jarvis-type model
    g_s_max = 0.012  # Maximum stomatal conductance [m s^-1]

    # Environmental response functions
    f_light = SWdown / (SWdown + 100.0)
    f_light = np.clip(f_light, 0.0, 1.0)

    f_vpd = 1.0 / (1.0 + VPD / 1.5)

    # Soil moisture availability proxy (assumed at 70% of plant available water capacity)
    f_sm = 0.7

    # Combined canopy conductance
    Gs = g_s_max * LAI * f_light * f_vpd * f_sm
    Gs = np.maximum(Gs, 0.0001)  # Minimum conductance to prevent division by zero

    # Available energy [W m^-2]
    A = Rnet - Qg

    # Penman-Monteith Equation
    # Since VPD, delta, and gamma are all in kPa, the units cancel out perfectly
    numerator = delta * A + rho_a * Cp * Ga * VPD
    denominator = delta + gamma * (1.0 + Ga / Gs)

    LE = numerator / denominator

    return LE
