USED_INPUTS = ['SWdown', 'VPD', 'RH', 'Rnet', 'Qg', 'Ga', 'delta', 'theta_FC']
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {'RHO_A': 1.225, 'CP': 1013.0, 'GAMMA': 0.0664}
LOCAL_FITTABLE = {'scale': {'init': None}, 'a1': {'init': None}}

def _gs(SWdown, RH, theta_FC, scale, a1):
    a1_safe = np.maximum(a1, 1.0)
    f_Rs = SWdown * (1000.0 + a1_safe) / (1000.0 * (SWdown + a1_safe))
    return np.maximum(scale * RH * f_Rs * np.exp(-theta_FC), 1e-06)

def _le(X, scale, a1):
    SWdown, VPD, RH, Rnet, Qg, Ga, delta, theta_FC = (X[:, 0], X[:, 1], X[:, 2], X[:, 3], X[:, 4], X[:, 5], X[:, 6], X[:, 7])
    gs = _gs(SWdown, RH, theta_FC, scale, a1)
    num = delta * (Rnet - Qg) + OTHER_CONSTANTS['RHO_A'] * OTHER_CONSTANTS['CP'] * VPD * Ga
    den = delta + OTHER_CONSTANTS['GAMMA'] * (1.0 + Ga / gs)
    return num / den

def predict(X: np.ndarray, scale: float, a1: float) -> np.ndarray:
    return _le(np.asarray(X, dtype=float), scale, a1)
