import numpy as np


def predict(X):
    """Predicts the log of annual wage income using the canonical Mincer Earnings Function.

    Parameters:
    X : np.ndarray
        A 2-D array where:
        - X[:, 0] represents years of schooling (s)
        - X[:, 1] represents potential experience (x)

    Returns:
    np.ndarray
        1-D array of predicted log annual wages (ln Y)
    """
    s = X[:, 0]
    x = X[:, 1]

    # Canonical Mincerian coefficients estimated from typical US ACS/CPS data:
    # ln(Y) = beta_0 + beta_1 * s + beta_2 * x + beta_3 * x^2
    beta_0 = 8.5  # Baseline log wage (intercept)
    beta_1 = 0.10  # Rate of return to schooling (approx 10% per year)
    beta_2 = 0.04  # Linear return to potential experience
    beta_3 = -0.0006  # Quadratic experience term representing diminishing returns

    log_wage = beta_0 + beta_1 * s + beta_2 * x + beta_3 * (x**2)

    return log_wage
