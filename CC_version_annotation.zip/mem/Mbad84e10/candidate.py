import numpy as np

def predict(X):
    s = X[:, 0]
    x = X[:, 1]
    
    # Standard Mincer earnings function:
    # ln(wage) = alpha + beta*s + gamma*x + delta*x^2
    # Common canonical values used here are illustrative placeholders.
    alpha = 0.0
    beta = 0.08
    gamma = 0.04
    delta = -0.0008
    
    return alpha + beta * s + gamma * x + delta * (x ** 2)
