import numpy as np

def predict(X):
    lam = np.asarray(X)[:, 0]
    # Cauchy-type closed-form dispersion relation
    # n(λ) = A + B/λ^2 + C/λ^4
    A = 1.0
    B = 0.0
    C = 0.0
    return A + B / lam**2 + C / lam**4
