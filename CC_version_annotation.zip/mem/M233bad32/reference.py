USED_INPUTS = ['wavelength_um']
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {'A': {'init': None}, 'B': {'init': None}, 'C': {'init': None}, 'D': {'init': None}}

def _n2(lam, A, B, C, D):
    lam2 = lam * lam
    lam4 = lam2 * lam2
    return A + B / lam2 + C / lam4 + D / (lam4 * lam2)

def predict(X: np.ndarray, A: float, B: float, C: float, D: float) -> np.ndarray:
    lam = np.asarray(X[:, 0], dtype=float)
    n2 = _n2(lam, A, B, C, D)
    return np.sqrt(np.clip(n2, _N2_FLOOR, None))
