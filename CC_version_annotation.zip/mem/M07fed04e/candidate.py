import numpy as np

def predict(X):
    # Classic gravity model for commuting flows:
    #   T_ij = K * m_i^a * m_j^b / d_ij^gamma
    # taken to log10 (with +1 shift applied to the modelled flow).
    m_i = np.asarray(X[:, 0], dtype=float)
    m_j = np.asarray(X[:, 1], dtype=float)
    d   = np.asarray(X[:, 2], dtype=float)

    # Fitted / canonical gravity-model coefficients
    logK  = -3.0    # normalisation constant (log10 K)
    a     = 0.90    # origin-mass exponent
    b     = 0.90    # destination-mass exponent
    gamma = 2.00    # distance-decay exponent

    log10_T = (logK
               + a * np.log10(m_i + 1.0)
               + b * np.log10(m_j + 1.0)
               - gamma * np.log10(d + 1.0))

    # convert modelled flow to log10(T+1) space, guarding against negatives
    T = np.power(10.0, log10_T)
    return np.log10(T + 1.0)
