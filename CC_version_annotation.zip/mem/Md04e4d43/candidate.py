import numpy as np

def predict(X):
    """
    Predict E/P (long-term mean annual evapotranspiration ratio) using the 
    classic Budyko (1974) curve, which is the geometric mean of the Schreiber 
    and Ol'dekop equations.

    Parameters
    ----------
    X : np.ndarray of shape (n_samples, 9)
        X[:,0] = pet_over_p (φ)  — aridity index
        (Other columns are not used by this standard relationship.)

    Returns
    -------
    et_over_p : np.ndarray of shape (n_samples,)
        Dimensionless evaporative fraction E/P ∈ [0,1].
    """
    phi = X[:, 0]                     # aridity index PET/P
    # Budyko curve: E/P = sqrt( φ * tanh(1/φ) * (1 - exp(-φ)) )
    et_over_p = np.sqrt(phi * np.tanh(1.0 / phi) * (1.0 - np.exp(-phi)))
    return et_over_p
