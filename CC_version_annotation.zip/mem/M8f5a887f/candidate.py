import numpy as np

def predict(X):
    # Langmuir-Freundlich (Sips) isotherm, canonical form
    P = X[:, 0]
    n_max = 7.0   # mmol/g, saturation capacity
    b = 0.5       # affinity constant [bar^-1/t]
    t = 1.0       # heterogeneity exponent
    n = n_max * (b * P**(1.0/t)) / (1.0 + b * P**(1.0/t))
    return n
