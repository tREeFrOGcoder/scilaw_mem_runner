USED_INPUTS = ['P_bar']
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {'n_s': {'init': None}, 'K': {'init': None}, 'm': {'init': None}}

def _toth(P, n_s, K, m):
    KP = K * np.asarray(P, dtype=float)
    KPm = np.clip(KP, 0.0, None) ** m
    denom = (1.0 + KPm) ** (1.0 / m)
    return n_s * KP / denom

def predict(X: np.ndarray, n_s: float, K: float, m: float) -> np.ndarray:
    P = np.asarray(X[:, 0], dtype=float)
    return _toth(P, n_s, K, m)
