USED_INPUTS = ['H_upper']
LAW_CONSTANTS = {'A0': 266.56}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {}

def predict(X: np.ndarray, A0: float=266.56) -> np.ndarray:
    H = np.asarray(X[:, 0], dtype=float)
    return np.full_like(H, A0)
