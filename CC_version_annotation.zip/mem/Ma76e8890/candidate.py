import numpy as np

def predict(X):
    """
    Predict cumulative number of NEOs N(<H) as a function of absolute magnitude H_upper.
    Model: log10 N(<H) = a + b * H  ->  N = 10^(a + b H)
    Coefficients set to match N(12)=2 and N(18)=1097 (consistent with the stated range).
    Input:
      X : 2-D numpy array, X[:,0] = H_upper (mag)
    Returns:
      1-D numpy array of predicted cumulative counts N(<H).
    """
    X = np.asarray(X)
    H = X[:, 0]
    # coefficients (derived from N(12)=2 and N(18)=1097)
    a = -5.17810378
    b =  0.45659450
    N = 10.0 ** (a + b * H)
    return N
