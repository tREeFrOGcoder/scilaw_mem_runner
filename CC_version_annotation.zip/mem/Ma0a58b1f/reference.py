USED_INPUTS = ['p_mean', 'pet_mean']
LAW_CONSTANTS = {'N': 1.6872}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {}

def predict(X: np.ndarray, N: float=1.6872) -> np.ndarray:
    P = np.asarray(X[:, 0], dtype=float)
    PET = np.asarray(X[:, 1], dtype=float)
    return P - P / (1.0 + (P / PET) ** N) ** (1.0 / N)
