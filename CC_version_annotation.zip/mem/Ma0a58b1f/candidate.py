import numpy as np

def predict(X):
    """
    Predict long-term mean daily runoff Q [mm/day] using the classic Budyko curve
    (geometric mean of Schreiber and Ol'dekop, Budyko 1974).

    Q = P - E, where actual evapotranspiration E is:
    E = P * sqrt( [1 - exp(-PET/P)] * (PET/P) * tanh(P/PET) )

    Parameters
    ----------
    X : np.ndarray, shape (n, 13)
        Array of input features. Only columns 0 (p_mean) and 1 (pet_mean) are used.

    Returns
    -------
    Q : np.ndarray, shape (n,)
        Predicted long-term mean daily runoff [mm/day].
    """
    P = X[:, 0]    # mean daily precipitation [mm/day]
    PET = X[:, 1]  # mean daily potential evapotranspiration [mm/day]

    # Guard against division by zero and negative values
    P_safe = np.maximum(P, 1e-10)
    PET_safe = np.maximum(PET, 1e-10)

    # Aridity index
    phi = PET_safe / P_safe

    # Budyko curve: E/P = sqrt( (1 - exp(-phi)) * phi * tanh(1/phi) )
    term1 = 1.0 - np.exp(-phi)
    term2 = phi * np.tanh(1.0 / phi)
    E_over_P = np.sqrt(np.maximum(term1 * term2, 0.0))

    # Actual evapotranspiration and runoff
    E = P_safe * E_over_P
    Q = P - E

    # Enforce physical bounds: 0 <= Q <= P
    Q = np.clip(Q, 0.0, P)
    return Q
