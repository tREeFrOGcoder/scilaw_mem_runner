USED_INPUTS = ['time_h']
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {'A': {'init': None}, 'mu_m': {'init': None}, 'lambda_': {'init': None}}

def _gompertz(t, A, mu_m, lambda_):
    arg = np.clip(mu_m * np.e / A * (lambda_ - t) + 1.0, -700.0, 700.0)
    return A * np.exp(-np.exp(arg))

def predict(X: np.ndarray, A: float, mu_m: float, lambda_: float) -> np.ndarray:
    t = np.asarray(X[:, 0], dtype=float)
    return _gompertz(t, A, mu_m, lambda_)
