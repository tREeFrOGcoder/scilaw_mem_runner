import numpy as np

def predict(X):
    X = np.asarray(X, dtype=float)
    t = X[:, 0]

    # Modified Gompertz primary microbial growth model
    od0 = 0.03          # initial/background-subtracted OD600
    od_max = 1.00      # stationary-phase OD600
    A = od_max - od0   # total OD increase
    mu_max = 0.18      # maximum growth rate in OD600 units per hour
    lag_h = 4.0        # lag time in hours

    od = od0 + A * np.exp(-np.exp((mu_max * np.e / A) * (lag_h - t) + 1.0))
    return od
