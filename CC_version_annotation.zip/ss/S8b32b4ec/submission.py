"""Kelly-style rational parametrization of the proton electric form factor, divided by the standard dipole form factor."""
import numpy as np

USED_INPUTS = ["Q2_GeV2"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {}

def predict(X):
    Q2 = X[:, 0]
    tau = Q2 / (4.0 * 0.9382720813**2)
    GE = (1.0 - 0.4518407897 * tau) / (
        1.0
        + 10.2045411130 * tau
        + 18.8761082712 * tau**2
        + 0.8546133130 * tau**3
    )
    GD_inverse = (1.0 + Q2 / 0.71)**2
    return GE * GD_inverse
