"""Conformal z-expansion of G_E^p / G_D — memorization-proof variant.

A physically-motivated alternative shape for the proton electric Sachs form
factor relative to the standard dipole.  Instead of the Arrington-2007 rational
polynomial in tau = Q^2/(4 M_p^2)

    G_E(tau) = (1 + a1 tau + a2 tau^2 + a3 tau^3)
               / (1 + b1 tau + ... + b5 tau^5)            [textbook form]

this variant writes G_E as a low-order POLYNOMIAL in the conformal variable z,
the analyticity-based "z-expansion" parameterisation (Hill-Paz / Lee-Arrington-
Hill / Ye-2018 family):

    z(Q^2) = (sqrt(t_c + Q^2) - sqrt(t_c)) / (sqrt(t_c + Q^2) + sqrt(t_c))

    G_E(Q^2) = 1 + a1 z + a2 z^2 + a3 z^3 + a4 z^4 + a5 z^5

    Target: GE_over_GD(Q^2) = G_E(Q^2) / G_D(Q^2),
            G_D(Q^2) = (1 + Q^2 / Lambda2)^(-2).

Here t_c = (2 m_pi)^2 is the two-pion production threshold (the nearest
branch-point singularity of the form factor in the complex Q^2 plane).  The
conformal map z(Q^2) sends the whole physical spacelike region 0 <= Q^2 < inf
into the unit disk |z| < 1, so a few low powers of z give a controlled,
rapidly-converging description grounded in the known analytic structure of
G_E.  This is a GENUINELY DISTINCT functional element from the Arrington
rational-polynomial-in-tau (and from the Bradford Pade form): a downstream
refit re-optimizes a1..a4 but cannot turn a polynomial in the conformal
variable z into a ratio of polynomials in tau — the two families remain
structurally different after refit.

Normalisation a0 = 1 is FIXED (not fitted), enforcing the exact low-Q^2 limit
G_E(0) = 1 and hence GE_over_GD(0) = 1 (z(0) = 0, G_D(0) = 1).

Validity:
  * canonical-dipole reference: G_E is expressed relative to G_D, the standard
    dipole form factor of a finite spatial proton charge distribution;
  * GE_over_GD = 1 at Q2_GeV2 = 0 exactly (z(0) = 0, a0 = 1, G_D(0) = 1);
  * no poles / divergences over the physical domain — G_D > 0 for all Q^2 >= 0
    and the numerator is a finite polynomial in the bounded variable |z| < 1.

LAW_CONSTANTS — fitted on the full GE/GD data (train+test) with scipy
---------------------------------------------------------------------
- a1, a2, a3, a4, a5 : z-expansion coefficients (5 fitted constants).

OTHER_CONSTANTS — fixed structural / universal values
-----------------------------------------------------
- a0       = 1.0      normalisation enforcing G_E(0) = 1 (not fitted).
- t_c      = (2 m_pi)^2 = 0.0779 GeV^2  two-pion threshold (conformal map).
- Lambda2  = 0.71 GeV^2  canonical dipole scale.
"""

import numpy as np

USED_INPUTS = ["Q2_GeV2"]
PAPER_REF = "summary_formula+dataset_arrington_2007.md"
EQUATION_LOC = (
    "Variant shape: GE/GD = (1 + a1 z + ... + a5 z^5)/G_D, "
    "z = (sqrt(t_c+Q^2)-sqrt(t_c))/(sqrt(t_c+Q^2)+sqrt(t_c)), t_c=(2 m_pi)^2. "
    "Conformal z-expansion of G_E; distinct from the Arrington-2007 rational-"
    "polynomial-in-tau and the Bradford Pade form.  5 coeffs fitted on GE/GD."
)

# === LAW_CONSTANTS — fitted on the full GE/GD dataset (scipy curve_fit) ===
LAW_CONSTANTS = {
    "a1":  -1.323011,
    "a2":   2.439994,
    "a3": -13.090196,
    "a4":  19.739902,
    "a5":  -8.801119,
}

# === OTHER_CONSTANTS — fixed structural / universal physics factors ===
OTHER_CONSTANTS = {
    "a0":      1.0,      # low-Q^2 normalisation G_E(0)=1 (not fitted)
    "t_c":     0.077953, # GeV^2 — two-pion threshold (2 m_pi)^2, m_pi=0.1396 GeV
    "Lambda2": 0.71,     # GeV^2 — canonical dipole scale
}

LOCAL_FITTABLE = {}      # Type I — no per-cluster parameters


def predict(
    X: np.ndarray,
    a1: float =  -1.323011,
    a2: float =   2.439994,
    a3: float = -13.090196,
    a4: float =  19.739902,
    a5: float =  -8.801119,
) -> np.ndarray:
    """Predicted GE_over_GD via the conformal z-expansion of G_E.

    X: (n, 1) — column Q2_GeV2.
    params: LAW_CONSTANTS keys (a1, a2, a3, a4, a5).
    OTHER_CONSTANTS (a0, t_c, Lambda2) read from module namespace.
    """
    a0      = OTHER_CONSTANTS["a0"]
    t_c     = OTHER_CONSTANTS["t_c"]
    Lambda2 = OTHER_CONSTANTS["Lambda2"]

    Q2 = np.asarray(X[:, 0], dtype=float)
    s0 = np.sqrt(t_c)
    sQ = np.sqrt(t_c + Q2)
    z  = (sQ - s0) / (sQ + s0)

    G_E = a0 + a1 * z + a2 * z**2 + a3 * z**3 + a4 * z**4 + a5 * z**5
    G_D = (1.0 + Q2 / Lambda2) ** (-2.0)
    return G_E / G_D
