"""Beer-Lambert with monomer-dimer self-association (chemical deviation).
The dye partly dimerizes: total conc c = M + 2*K*M^2, so monomer
M = (-1+sqrt(1+8Kc))/(4K). Absorbance = l*(eM*M + eD*K*M^2)."""
import numpy as np
from scipy.optimize import curve_fit

USED_INPUTS = ["concentration", "path_length"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {"eM": {"init": None}, "eD": {"init": None}, "K": {"init": None}}

def _form(C, L, eM, eD, K):
    K = max(K, 1e-6)
    M = (-1.0 + np.sqrt(1.0 + 8.0 * K * C)) / (4.0 * K)
    return L * (eM * M + eD * K * M * M)

def fit(X_fit, y_fit):
    C = X_fit[:, 0]; L = X_fit[:, 1]; A = y_fit
    def f(X, eM, eD, K):
        return _form(X[0], X[1], eM, eD, K)
    eM0 = float(A[np.argmin(C)] / (C[np.argmin(C)] * L[np.argmin(C)]))
    best = None
    for K0 in [0.01, 0.05, 0.2, 1.0, 5.0, 20.0]:
        for eD0 in [2.0, 10.0, 50.0]:
            try:
                p, _ = curve_fit(f, (C, L), A, p0=[eM0, eD0, K0],
                                 bounds=([0, 0, 1e-4], [100, 5000, 100]),
                                 maxfev=20000)
                e = np.sqrt(np.mean((A - f((C, L), *p)) ** 2))
                if best is None or e < best[1]:
                    best = (p, e)
            except Exception:
                pass
    if best is None:
        return {"eM": eM0, "eD": 0.0, "K": 1e-3}
    p = best[0]
    return {"eM": float(p[0]), "eD": float(p[1]), "K": float(p[2])}

def predict(X, eM, eD, K):
    return _form(X[:, 0], X[:, 1], eM, eD, K)
