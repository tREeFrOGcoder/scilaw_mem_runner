"""Memorization-proof VARIANT of the generalized Beer-Lambert-Bouguer model.

Baseline (Yeh 2023, textbook power-law extension):
    A_lambda = eps_prime * c^alpha * l^beta      (single power law in c)

VARIANT — additive two-term "Beer-Lambert + equilibrium-deviation" form
-----------------------------------------------------------------------
Physical motivation.  For potassium dichromate the apparent non-linearity is
*chemical*: the chromate/dichromate equilibrium (2 HCrO4- <-> Cr2O7^2- + H2O)
shifts with dilution, so the spectrum is a superposition of two absorbing
species whose relative amounts change with total concentration.  We therefore
write the per-wavelength absorbance as the sum of an EXACT linear
Bouguer-Lambert-Beer term (the dominant species, obeying classical BLB) and a
small concentration-power deviation term that accounts for the second species'
non-linear build-up:

    A = ( eps_lin * c  +  eps_dev * c^p ) * l^beta

with eps_lin, eps_dev >= 0, p the deviation-species exponent, beta the
path-length exponent.  This is a DISTINCT functional SHAPE from the single
power law (a sum of two power terms vs. one), is physically plausible
(explicit BLB leading term + equilibrium correction), and reduces to classical
BLB when eps_dev -> 0.  After per-group (per-wavelength) fitting the two forms
are genuinely distinct: the variant can bend the c-response with a fixed linear
anchor, which the single exponent cannot reproduce.

Validity rubrics satisfied
  - includes Bouguer-Lambert-Beer absorption along the optical path: yes, the
    eps_lin * c * l term is the exact classical BLB contribution.
  - non-negative predictions: all params constrained >= 0 (beta, p > 0).
  - monotone increasing in concentration at fixed l: d A/d c =
    (eps_lin + p*eps_dev*c^(p-1)) * l^beta >= 0.
  - monotone increasing in path_length at fixed c: d A/d l = beta * A / l >= 0.

Type: TYPE II — per-cluster (per-wavelength) fit required.

LOCAL_FITTABLE — per-wavelength:
  - eps_lin : classical BLB specific absorptivity of the dominant species.
  - eps_dev : specific absorptivity scale of the equilibrium-deviation term.
  - p       : concentration exponent of the deviation species (p ~ 1-2).
  - beta    : path-length (Bouguer) exponent (~1).
"""

import numpy as np
from scipy.optimize import minimize

USED_INPUTS = ["concentration", "path_length"]
PAPER_REF = "summary_formula_dataset_yeh_2023.md"

LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}

LOCAL_FITTABLE = {
    "eps_lin": {"init": [0.1, 1.0]},
    "eps_dev": {"init": [0.1, 1.0]},
    "p":       {"init": [1.0, 1.5, 2.0]},
    "beta":    {"init": [1.0]},
}


def predict(X: np.ndarray, eps_lin: float, eps_dev: float, p: float, beta: float) -> np.ndarray:
    """A = (eps_lin * c + eps_dev * c^p) * l^beta.

    X[:, 0] = concentration c [g/L]; X[:, 1] = path_length l [cm].
    """
    c = np.asarray(X[:, 0], dtype=float)
    l = np.asarray(X[:, 1], dtype=float)
    c_safe = np.where(c > 0, c, 1e-12)
    l_safe = np.where(l > 0, l, 1e-12)
    el = max(float(eps_lin), 0.0)
    ed = max(float(eps_dev), 0.0)
    species = el * c_safe + ed * np.power(c_safe, p)
    return species * np.power(l_safe, beta)


def _fit_linear_for(p: float, beta: float, c: np.ndarray, l: np.ndarray, y: np.ndarray):
    """For fixed (p, beta) the model is linear in (eps_lin, eps_dev):
        y = eps_lin * (c * l^beta) + eps_dev * (c^p * l^beta).
    Solve non-negative-ish least squares via lstsq, clip negatives to 0 and
    re-solve the reduced system; return (eps_lin, eps_dev, sse).
    """
    lb = np.power(np.maximum(l, 1e-12), beta)
    b1 = c * lb
    b2 = np.power(np.maximum(c, 1e-12), p) * lb
    A = np.column_stack([b1, b2])
    coef, *_ = np.linalg.lstsq(A, y, rcond=None)
    el, ed = coef
    # enforce non-negativity by projecting onto active constraints
    if el < 0 or ed < 0:
        cands = []
        # only eps_dev
        d = float(np.dot(b2, y) / max(np.dot(b2, b2), 1e-30))
        cands.append((0.0, max(d, 0.0)))
        # only eps_lin
        a = float(np.dot(b1, y) / max(np.dot(b1, b1), 1e-30))
        cands.append((max(a, 0.0), 0.0))
        if el >= 0 and ed >= 0:
            cands.append((float(el), float(ed)))
        best = min(cands, key=lambda t: float(np.sum((A @ np.array(t) - y) ** 2)))
        el, ed = best
    el = max(float(el), 0.0)
    ed = max(float(ed), 0.0)
    sse = float(np.sum((A @ np.array([el, ed]) - y) ** 2))
    return el, ed, sse


def fit(X_fit: np.ndarray, y_fit: np.ndarray) -> dict:
    """Fit per-wavelength params. Outer nonlinear search over (p, beta);
    inner closed-form non-negative least squares for (eps_lin, eps_dev).
    """
    c = np.asarray(X_fit[:, 0], dtype=float)
    l = np.asarray(X_fit[:, 1], dtype=float)
    y = np.asarray(y_fit, dtype=float)

    def obj(params):
        p, beta = params
        if p <= 0 or beta <= 0:
            return 1e12
        _, _, sse = _fit_linear_for(p, beta, c, l, y)
        return sse

    best = None
    best_val = np.inf
    for p0 in LOCAL_FITTABLE["p"]["init"]:
        for be0 in LOCAL_FITTABLE["beta"]["init"]:
            res = minimize(obj, x0=[p0, be0], method="Nelder-Mead",
                           options={"xatol": 1e-7, "fatol": 1e-12, "maxiter": 4000})
            if res.fun < best_val:
                best_val = res.fun
                best = res.x

    if best is None:
        p, beta = 1.0, 1.0
    else:
        p, beta = float(best[0]), float(best[1])
        p = max(p, 1e-3)
        beta = max(beta, 1e-3)

    el, ed, _ = _fit_linear_for(p, beta, c, l, y)
    return {"eps_lin": float(el), "eps_dev": float(ed), "p": float(p), "beta": float(beta)}
