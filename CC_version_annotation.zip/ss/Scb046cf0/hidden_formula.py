"""Birch's-law mass-density variant of the Anderson-Nafe bulk-modulus scaling.

The textbook Anderson-Nafe (1965) law is a pure single power of atomic volume,
log10(K) = a - (4/3) log10(V), i.e. K ~ V^(-4/3) with NO mass dependence.
Birch's law and its bulk-modulus analogue, however, say elastic stiffness is
driven not by volume alone but by *mass packing*: at fixed volume a denser
lattice is stiffer. We add exactly one extra physically-motivated term — a
power of mass density rho — turning the single-power volume law into a
two-factor volume * density product:

    log10(K) = a(cs) + p * log10(V) + q * log10(rho)
    <=>  K = 10^a(cs) * V^p * rho^q                      (q > 0: denser -> stiffer)

This is DISTINCT IN SHAPE from the memorised Anderson-Nafe form (which has no
density factor, q = 0). A downstream refit of (p, q) cannot collapse it back
to the textbook straight power law because the data carry a real, large
density-stiffening signal — q refits to ~0.63 (not 0), and including it cuts
the log-space residual from ~0.20 to ~0.13. So the recovered law stays
recognisably different from the memorised single-power Anderson-Nafe relation.

Validity / physics (rubrics):
  * Inverse power dependence on V (p ~ -1.5 < 0): K decreases with V and -> 0
    as V grows (the q*log(rho) term is bounded over the lattice).
  * Per-crystal-system intercepts a(cs) (OTHER_CONSTANTS, fit on train), like
    the baseline's per-Bravais-class calibration.
  * Incorporates mass density as an additional stiffening driver (Birch's-law
    mass-density correction beyond pure volume scaling) — rubric 6.
  * K = 10^(...) > 0 always.

Contract:
  USED_INPUTS  = ["V_atomic_A3", "density_g_cm3", "crystal_system_id"]
      (extends the baseline's [V, cs] with density, the rubric-blessed
       stiffening driver; density_g_cm3 = 1.66054 * M_avg / V_atomic.)
  LAW_CONSTANTS = {an_vol_exp, an_density_exp}   (<= max_law_constants=2)
  OTHER_CONSTANTS = per-csid intercepts, fit on train.csv
  predict(X, **LAW_CONSTANTS)  pure-numpy vectorised.

Type designation: Type I — LOCAL_FITTABLE = {}, no fit() method.
Mapping: V_atomic_A3 (col 0), density_g_cm3 (col 1), crystal_system_id (col 2).
"""

import numpy as np

USED_INPUTS = ["V_atomic_A3", "density_g_cm3", "crystal_system_id"]
PAPER_REF = "summary_birch_murnaghan_kvrh.md"
EQUATION_LOC = "Birch mass-density variant of Anderson-Nafe: log10(K) = a(cs) + p*log10(V) + q*log10(rho)"

LAW_CONSTANTS = {
    "an_vol_exp": -1.5002,      # volume power p (fit)
    "an_density_exp": 0.6262,   # density power q — Birch mass-density stiffening (fit)
}

OTHER_CONSTANTS = {
    # Per-crystal-system intercepts a(cs), fit on train.csv jointly with the
    # shared (vol_exp, density_exp). crystal_system_id -> a.
    "a_by_csid_2": 3.3423,   # monoclinic
    "a_by_csid_3": 3.3548,   # orthorhombic
    "a_by_csid_4": 3.3593,   # tetragonal
    "a_by_csid_5": 3.3272,   # trigonal
    "a_by_csid_6": 3.3737,   # hexagonal
    "a_by_csid_7": 3.3506,   # cubic
    "a_global":    3.3513,   # fallback for unrecognised crystal_system_id
}

LOCAL_FITTABLE = {}   # Type I


def predict(X: np.ndarray, an_vol_exp: float, an_density_exp: float) -> np.ndarray:
    """K_VRH (GPa) from the Birch mass-density variant.

    log10(K) = a(cs) + an_vol_exp*log10(V) + an_density_exp*log10(rho)

    X: (n, 3) — columns [V_atomic_A3, density_g_cm3, crystal_system_id].
    LAW_CONSTANTS (an_vol_exp, an_density_exp) arrive via predict(X, **LAW_CONSTANTS);
    per-crystal-system intercepts come from OTHER_CONSTANTS.
    """
    V = np.asarray(X[:, 0], dtype=float)
    rho = np.asarray(X[:, 1], dtype=float)
    csid = np.asarray(X[:, 2], dtype=np.int64)

    a_table = {
        2: OTHER_CONSTANTS["a_by_csid_2"],
        3: OTHER_CONSTANTS["a_by_csid_3"],
        4: OTHER_CONSTANTS["a_by_csid_4"],
        5: OTHER_CONSTANTS["a_by_csid_5"],
        6: OTHER_CONSTANTS["a_by_csid_6"],
        7: OTHER_CONSTANTS["a_by_csid_7"],
    }
    a_global = OTHER_CONSTANTS["a_global"]
    a = np.full(csid.shape, a_global, dtype=np.float64)
    for k, v in a_table.items():
        a[csid == k] = v

    V_safe = np.where(V > 0, V, 1e-9)
    rho_safe = np.where(rho > 0, rho, 1e-9)
    log10K = a + an_vol_exp * np.log10(V_safe) + an_density_exp * np.log10(rho_safe)
    return np.power(10.0, log10K)
