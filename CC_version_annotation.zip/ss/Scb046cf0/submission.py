"""Low-order inverse-volume polynomial with density interaction."""
import numpy as np

USED_INPUTS = ["V_atomic_A3", "density_g_cm3"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {}

def predict(X):
    V = X[:, 0]
    rho = X[:, 1]
    invV = 1.0 / V
    return (
        26.3
        - 5.75 * rho
        - 637.8 * invV
        + 305.5 * rho * invV
        + 10245.0 * invV * invV
    )
