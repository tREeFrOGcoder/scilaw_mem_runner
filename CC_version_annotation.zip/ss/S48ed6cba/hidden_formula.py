"""Logistic-saturation mass-metallicity relation (memorization-proof variant).

A physically-motivated VARIANT of the SDSS mass-metallicity relation (MZR)
that deliberately departs from the published closed forms in FUNCTIONAL SHAPE.

Formula
-------
    12 + log(O/H) = Z_asm - A / (1 + (M_* / M_0)^gamma)

    where M_* = 10^log_Mstar and M_0 = 10^log_M0, equivalently

    12 + log(O/H) = Z_asm - A / (1 + 10^(gamma * (log_Mstar - log_M0)))

This is a logistic (Hill / rational-sigmoid) saturation in log stellar mass:
metallicity rises monotonically from a low-mass floor (Z_asm - A) and
saturates onto an asymptotic plateau Z_asm at high mass, with the transition
centred at log_M0 and sharpness gamma.

Why this is a distinct shape — not a re-coefficiented textbook law
------------------------------------------------------------------
  * It is NOT a polynomial in m = log_Mstar - 10 (Mannucci 2010 Eq. 1,
    Tremonti 2004 Eq. 3): a sigmoid cannot be reproduced by a refit of a
    fixed-order polynomial template.
  * It is NOT the Andrews & Martini (2013) / Curti (2020) asymptotic form
    Z_asm - log10(1 + (M_TO/M_*)^gamma): that is a log-of-a-sum; this is a
    rational logistic (a reciprocal-of-a-sum). These are mathematically
    different functions, so a downstream refit of either textbook template
    stays distinct from this one.
The two forms saturate to the same physics (high-mass chemical plateau,
low-mass power-law-like rise) yet have different curvature, so the variant
remains recognizably its own functional family after any coefficient refit.

Physical plausibility / validity
---------------------------------
  * High-mass saturation: as M_* -> infinity the second term -> 0, so
    12+log(O/H) -> Z_asm (chemical-enrichment plateau).
  * Monotone enrichment: for A>0, gamma>0 the prediction is strictly
    increasing in log_Mstar, so higher stellar mass => higher gas-phase
    oxygen abundance over the whole SDSS domain.
  * No log_SFR dependence (pure MZR), so oh is constant — hence
    non-increasing — with log_SFR at fixed log_Mstar.

LAW_CONSTANTS — fitted here (scipy curve_fit) on the released SDSS sample
------------------------------------------------------------------------
    Z_asm  : asymptotic (high-mass) plateau metallicity (dex)
    A      : total rise from the low-mass floor to the plateau (dex)
    log_M0 : log10 transition (half-saturation) stellar mass (log M_sun)
    gamma  : sharpness of the logistic transition (dimensionless)

OTHER_CONSTANTS — none
LOCAL_FITTABLE  — {} (Type I: each galaxy independent, one global curve).

Column mapping: log_Mstar -> log10 M_* / M_sun.
"""

import numpy as np

USED_INPUTS = ["log_Mstar"]

# === LAW_CONSTANTS — fitted on the released SDSS sample (scipy curve_fit) ===
LAW_CONSTANTS = {
    "Z_asm":  9.1223,   # high-mass asymptotic plateau metallicity (dex)
    "A":      0.8784,   # total low-mass-to-plateau rise (dex)
    "log_M0": 9.3441,   # log10 half-saturation stellar mass (log M_sun)
    "gamma":  0.8042,   # logistic transition sharpness (dimensionless)
}
# === OTHER_CONSTANTS — universal physics factors ===
OTHER_CONSTANTS = {}
LOCAL_FITTABLE  = {}   # Type I — no per-cluster parameters


def predict(X: np.ndarray, Z_asm: float, A: float,
            log_M0: float, gamma: float) -> np.ndarray:
    """Predict 12+log(O/H) from log stellar mass (logistic saturation).

    X: (n, 1) — column log_Mstar (= log10 M_star / M_sun).
    Returns: (n,) array of 12+log(O/H) in dex.
    """
    log_Mstar = np.asarray(X[:, 0], dtype=float)
    # rational logistic in log-mass: rises from (Z_asm - A) onto plateau Z_asm
    return Z_asm - A / (1.0 + 10.0 ** (gamma * (log_Mstar - log_M0)))
