"""Logistic mass-metallicity relation (MZR): oh = a + b / (1 + exp(-k * (log_Mstar - x0))).
The gas-phase oxygen abundance saturates at high stellar mass and drops at low mass,
following a sigmoid in log-stellar-mass space."""
import numpy as np

USED_INPUTS = ["log_Mstar"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {}

def predict(X):
    x = X[:, 0]
    a = 8.2881
    b = 0.8370
    k = 1.9352
    x0 = 9.4233
    return a + b / (1.0 + np.exp(-k * (x - x0)))
