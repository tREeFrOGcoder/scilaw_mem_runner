"""Piecewise-Ey drive with linear damping and sqrt-pressure correction:
dDst/dt = c0 + a_pos * max(Ey,0) + b * Dst + c * sqrt(P_dyn)
"""
import numpy as np

USED_INPUTS = ["Dst", "Ey", "P_dyn"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {}

def predict(X):
    Dst = X[:, 0]
    Ey = X[:, 1]
    P = X[:, 2]
    posEy = np.maximum(Ey, 0.0)
    return 1.6339107442931566 + (-2.532320208951164) * posEy + (-0.04890753767407403) * Dst + (-0.4244184088070549) * np.sqrt(P)
