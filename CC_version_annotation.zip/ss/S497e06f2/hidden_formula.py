"""Memorization-proof VARIANT of the ring-current dDst/dt law (sim3 Type I).

Developed FROM the O'Brien & McPherron (2000) AK2 baseline, but DISTINCT in
functional SHAPE so a model that memorized the textbook AK2 form
    dDst*/dt = Q(VBs) - Dst*/tau(VBs),  Q = q*(VBs-vbs_thresh)_+ ,
               tau = tau_amp*exp(tau_num/(tau_off+VBs))
cannot recognize it and must recover this form from the simulator's data.

Two SHAPE changes vs. AK2 (both physically motivated, not just re-coefficients):

  (1) SMOOTH (softplus) injection in place of the hard rectified threshold.
      The AK2 injection term is the non-differentiable ramp
      q*max(VBs - vbs_thresh, 0). Real ring-current injection turns on
      gradually around the dawn-dusk field threshold, so we replace the
      kink with a softplus that has a finite turn-on width `inj_width`:
          Q = q_coef * inj_width * softplus((VBs - vbs_thresh)/inj_width)
      As inj_width -> 0 this collapses to the AK2 ramp; for fitted
      inj_width = O(1) the shape near threshold is genuinely different
      and does NOT refit back to the rectified-threshold form.

  (2) LINEAR ring-current decay -Dst*/tau replaced by a CONSTANT-rate
      linear decay -decay_rate * Dst* (Burton-1975-style first-order
      relaxation) plus a direct dynamic-pressure tendency term
      pres_coef*sqrt(P_dyn). This removes the VBs-dependent exponential
      decay-time tau(VBs) of AK2 entirely, changing the Dst- and
      VBs-dependence of the decay branch.

Pressure-corrected storm-time index (kept from the ring-current tradition):
    Dst_star = Dst - b*sqrt(P_dyn) + c

Full form:
    dDst/dt =  q_coef*inj_width*softplus((max(Ey,0) - vbs_thresh)/inj_width)
             - decay_rate*(Dst - b*sqrt(P_dyn) + c)
             + pres_coef*sqrt(P_dyn)

Physics / validity:
    * recovery/decay driven by existing depletion: -decay_rate*Dst_star,
      decay_rate > 0 (positive tendency when Dst is depleted/negative).
    * dynamic-pressure / magnetopause-current effects: the
      -b*sqrt(P_dyn) correction and the direct pres_coef*sqrt(P_dyn) term.
    * southward-field injection: q_coef<0 acting on VBs=max(Ey,0).
    * dDst/dt > 0 for strongly negative Dst with no southward driving.
    * dDst/dt < 0 for strong southward driving near quiet Dst.
    * dDst/dt does not decrease as Dst becomes more negative
      (d/dDst = -decay_rate < 0 ... wait: monotone in Dst is
      d(dDst/dt)/dDst = -decay_rate < 0, so as Dst DECREASES, dDst/dt
      INCREASES -> non-decreasing requirement satisfied).

Coefficients below are fitted by scipy least squares on the released
train+test pool (curve_fit, RMSE ~2.96 nT/hr, vs AK2 refit ~2.91).
"""

import numpy as np

USED_INPUTS = ["Dst", "Ey", "P_dyn"]

# === LAW_CONSTANTS — fitted (scipy curve_fit on released data) ===
LAW_CONSTANTS = {
    "q_coef":     -2.4655,   # nT/(hr*mV/m)   injection coupling (softplus amplitude)
    "vbs_thresh": -0.5384,   # mV/m           soft injection turn-on location
    "inj_width":   0.7284,   # mV/m           softplus turn-on width (>0)
    "decay_rate":  0.0462,   # hr^-1          constant ring-current relaxation rate
    "b":           8.8388,   # nT/sqrt(nPa)   magnetopause pressure coefficient
    "c":         -62.0115,   # nT             pressure-correction offset
    "pres_coef":  -0.7835,   # nT/hr/sqrt(nPa) direct dynamic-pressure tendency
}

# === OTHER_CONSTANTS — universal physics factors ===
OTHER_CONSTANTS = {}

LOCAL_FITTABLE = {}


def _softplus(z):
    # numerically stable log(1+exp(z))
    return np.maximum(z, 0.0) + np.log1p(np.exp(-np.abs(z)))


def predict(X: np.ndarray, q_coef: float, vbs_thresh: float, inj_width: float,
            decay_rate: float, b: float, c: float, pres_coef: float) -> np.ndarray:
    """Predict dDst/dt from (Dst, Ey, P_dyn).

    X.shape = (n, 3); columns in USED_INPUTS order: Dst, Ey, P_dyn.
    LAW_CONSTANTS arrive as named params via predict(X, **LAW_CONSTANTS).
    """
    Dst   = np.asarray(X[:, 0], dtype=float)
    Ey    = np.asarray(X[:, 1], dtype=float)
    P_dyn = np.asarray(X[:, 2], dtype=float)

    VBs    = np.maximum(Ey, 0.0)
    width  = np.maximum(inj_width, 1e-6)
    Q      = q_coef * width * _softplus((VBs - vbs_thresh) / width)

    sqrtP    = np.sqrt(np.maximum(P_dyn, 0.0))
    Dst_star = Dst - b * sqrtP + c
    return Q - decay_rate * Dst_star + pres_coef * sqrtP
