"""Heligman-Pollard-style mortality law: infant decline + accident hump + senescent Gompertz tail, fit per cluster."""
import numpy as np
from scipy.optimize import curve_fit

USED_INPUTS = ["age"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {
    "A": {"init": [1e-3]},
    "B": {"init": [0.0]},
    "C": {"init": [0.1]},
    "D": {"init": [1e-3]},
    "E": {"init": [1.0]},
    "F": {"init": [20.0]},
    "G": {"init": [1e-5]},
    "H": {"init": [1.08]},
}

def _rate(x, A, B, C, D, E, F, G, H):
    x = np.asarray(x, dtype=float)
    z = x + 1.0
    infant = np.power(np.maximum(A, 1e-12), np.power(np.maximum(z + B, 1e-12), C))
    hump = D * np.exp(-E * (np.log(z) - np.log(np.maximum(F, 1e-12)))**2)
    senescent = G * np.power(np.maximum(H, 1e-12), x)
    r = infant + hump + senescent
    return np.maximum(r, 1e-300)

def fit(X_fit, y_fit):
    x = np.asarray(X_fit[:, 0], dtype=float)
    y = np.asarray(y_fit, dtype=float)

    # Reasonable starting point for all clusters.
    p0 = [1e-3, 0.0, 0.1, 1e-3, 1.0, 20.0, 1e-5, 1.08]

    # Soft but safe bounds keep the optimizer in finite regions.
    lb = [1e-12, -5.0, -5.0, 1e-12, 1e-4, 1e-3, 1e-12, 1.0001]
    ub = [1.0,   5.0,  5.0,  10.0,  20.0, 200.0, 10.0,   1.5]

    def model(x, A, B, C, D, E, F, G, H):
        return np.log(_rate(x, A, B, C, D, E, F, G, H))

    try:
        popt, _ = curve_fit(
            model, x, y, p0=p0, bounds=(lb, ub), maxfev=50000
        )
        return {
            "A": float(popt[0]),
            "B": float(popt[1]),
            "C": float(popt[2]),
            "D": float(popt[3]),
            "E": float(popt[4]),
            "F": float(popt[5]),
            "G": float(popt[6]),
            "H": float(popt[7]),
        }
    except Exception:
        return {
            "A": p0[0], "B": p0[1], "C": p0[2], "D": p0[3],
            "E": p0[4], "F": p0[5], "G": p0[6], "H": p0[7],
        }

def predict(X, A, B, C, D, E, F, G, H):
    x = np.asarray(X[:, 0], dtype=float)
    return np.log(_rate(x, A, B, C, D, E, F, G, H))
