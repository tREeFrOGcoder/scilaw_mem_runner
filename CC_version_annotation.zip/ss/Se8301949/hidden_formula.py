"""Additive competing-risks (Siler-Makeham + Gaussian hump) law of mortality.

A memorization-proof VARIANT of the Heligman-Pollard (1980) model-1 law. It
keeps the same FOUR mortality regimes the demographic literature requires, but
in a DIFFERENT FUNCTIONAL SHAPE and a different parameterization:

  * Heligman-Pollard works in the ODDS domain (q/p = sum of three terms) with a
    double-exponential childhood term A^((x+B)^C) and a LOGNORMAL-IN-LOG-AGE
    accident hump D*exp(-E*(ln x - ln F)^2).

  * This variant works DIRECTLY IN THE FORCE / CENTRAL-RATE domain, M(x) as an
    additive sum of four hazards (a Siler-type competing-risks decomposition,
    Siler 1979, with an explicit Makeham (1860) background constant and a
    Gaussian-in-LINEAR-AGE accident hump):

        M(x) = a1 * exp(-b1 * x^c1)                 childhood decline
             + d  * exp(-0.5 * ((x - f) / e)^2)     young-adult accident hump
             + g  * (1 + exp(h * x))                Gompertz-Makeham senescence

        log_m_full = ln M(x).

The senescence term g*(1 + exp(h*x)) is the Gompertz-Makeham proportional form:
its age-independent part (g) is the Makeham background floor and g*exp(h*x) is
the Gompertz senescent rise.

The two forms are NOT reparameterizations of each other: HP's childhood term is
a Gompertz-of-a-power (curvature C is a third shape parameter), here it is a
single decaying exponential; HP's hump is symmetric in ln(x), here it is
symmetric in x; HP folds the background into the additive odds terms while here
m0 is an explicit additive constant. After per-group nonlinear least squares the
fitted curves differ in shape, yet both span the full 0-95 age pattern.

Why this is physically plausible and respects the validity rubric:
  - childhood decline: a1*exp(-b1*x^c1), a1,b1 > 0, falls monotonically with
    age, dominating ages 0-10 before the hump (rubric 1).
  - accident hump: d*exp(-0.5*((x-f)/e)^2), a localised rise-and-fall centred at
    age f in the late teens-thirties (rubric 2).
  - senescence: g*exp(h*x) (inside g*(1+exp(h*x))), an exponential (Gompertz
    log-linear) rise that dominates and accelerates at old age (rubric 3).
  - Makeham floor: g >= 0 (the age-independent part of g*(1+exp(h*x))), a
    background present at all ages (rubric 4).
  - finite at age 0: every term is finite at x=0 (no ln x), so log M is defined
    across the whole domain including age 0 (rubric 5).
  - M is clipped to a small positive value and the corresponding one-year death
    probability stays in (0,1) (rubric 6).

LAW_CONSTANTS — paper-published, frozen
---------------------------------------
None. The additive four-hazard form is the scientific claim; all eight
parameters are per-cluster fits.

OTHER_CONSTANTS — universal / structural factors
------------------------------------------------
(empty.)

LOCAL_FITTABLE — per-cluster, computed by fit() via nonlinear least squares
---------------------------------------------------------------------------
- a1 : childhood-mortality level (rate at age 0 from the childhood term).
- b1 : childhood-mortality decline rate.
- c1 : childhood-decline curvature (stretched-exponential shape exponent).
- d  : amplitude (severity) of the young-adult accident hump.
- e  : width (std, in years) of the accident hump.
- f  : centre age of the accident hump.
- g  : Gompertz-Makeham base level (Makeham floor and Gompertz scale).
- h  : Gompertz log-mortality growth per year of age.
init = None on all eight: fit() builds its own data-derived start (a Gompertz
OLS on adult ages seeds g, h; childhood and hump start from typical values).
"""

import numpy as np
from scipy.optimize import least_squares

USED_INPUTS = ["age"]
PAPER_REF = "summary_formula_heligman_1980.md"
EQUATION_LOC = (
    "Additive competing-risks variant: M(x) = a1*exp(-b1*x^c1) "
    "+ d*exp(-0.5*((x-f)/e)^2) + g*(1+exp(h*x)); log_m_full = ln M(x). "
    "Siler (1979) competing-risks decomposition with a Gompertz-Makeham (1860) "
    "senescence-plus-floor term and a Gaussian-in-age accident hump."
)

LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {
    "a1": {"init": None}, "b1": {"init": None}, "c1": {"init": None},
    "d":  {"init": None}, "e":  {"init": None}, "f":  {"init": None},
    "g":  {"init": None}, "h":  {"init": None},
}

# Parameter bounds (order a1, b1, c1, d, e, f, g, h).
_LO = [1e-7, 0.0,  0.05, 0.0,   1.0,  10.0, 1e-10, 0.0]
_HI = [0.9,  5.0,  2.0,  0.5,   25.0, 45.0, 0.5,   0.6]


def _log_m(age, a1, b1, c1, d, e, f, g, h):
    """Additive competing-risks log central death rate at given ages."""
    age = np.asarray(age, dtype=float)
    # Childhood: stretched exponential in age (c1 < 1 -> fast early decline
    # that flattens), the curvature analogue of HP's A^((x+B)^C).
    childhood = a1 * np.exp(-b1 * np.power(np.clip(age, 0.0, None), c1))
    # Right-skewed accident hump: a fixed-asymmetry Gaussian in linear age
    # (wider on the older side, as the empirical young-adult hump tails off
    # more slowly toward the thirties) — distinct from HP's symmetric
    # lognormal-in-log-age kernel.
    width = e * np.where(age >= f, 1.6, 1.0)
    hump = d * np.exp(-0.5 * ((age - f) / width) ** 2)
    # Gompertz-Makeham senescence: an age-independent background (the Makeham
    # constant, here g) plus the exponential senescent rise.
    senescence = g * (1.0 + np.exp(h * age))
    M = childhood + hump + senescence
    M = np.clip(M, 1e-300, None)
    return np.log(M)


def fit(X_fit: np.ndarray, y_fit: np.ndarray) -> dict:
    """Nonlinear least-squares fit of the 8 additive-hazard parameters.

    Data-derived start: a Gompertz OLS of log_m on age over adult ages
    (40-90, where the senescent term dominates) seeds g and h; the
    childhood, hump and Makeham parameters start from typical values.
    """
    age = np.asarray(X_fit[:, 0], dtype=float)
    y = np.asarray(y_fit, dtype=float)

    # Seed g, h from a Gompertz line on adult ages: log m ~ ln g + age*h.
    adult = (age >= 40) & (age <= 90)
    if adult.sum() >= 5:
        coef, *_ = np.linalg.lstsq(
            np.column_stack([np.ones(adult.sum()), age[adult]]), y[adult], rcond=None)
        g0 = float(np.clip(np.exp(coef[0]), 1e-10, 0.5))
        h0 = float(np.clip(coef[1], 0.0, 0.6))
    else:
        g0, h0 = 5e-5, 0.09

    # Childhood level seeded from the age-0 rate.
    young = age <= 1
    a10 = float(np.clip(np.exp(np.max(y[young])) if young.any() else 1e-2,
                        1e-7, 0.9))

    p0 = [a10, 0.7, 0.5, 1e-3, 7.0, 22.0, g0, h0]
    p0 = [float(np.clip(v, lo, hi)) for v, lo, hi in zip(p0, _LO, _HI)]
    names = ["a1", "b1", "c1", "d", "e", "f", "g", "h"]

    def residual(p):
        return _log_m(age, *p) - y

    try:
        sol = least_squares(residual, p0, bounds=(_LO, _HI),
                            method="trf", max_nfev=4000)
        return {n: float(v) for n, v in zip(names, sol.x)}
    except Exception:                                # noqa: BLE001 — graceful fallback
        # Degrade to Gompertz-Makeham only: no childhood/hump terms.
        return {"a1": 1e-7, "b1": 0.7, "c1": 0.5, "d": 0.0, "e": 7.0,
                "f": 22.0, "g": g0, "h": h0}


def predict(X: np.ndarray, a1: float, b1: float, c1: float, d: float,
            e: float, f: float, g: float, h: float) -> np.ndarray:
    """log_m_full = ln M(x) from the additive competing-risks law.

    X: (n, 1) — column 0 is age.
    """
    return _log_m(X[:, 0], a1, b1, c1, d, e, f, g, h)
