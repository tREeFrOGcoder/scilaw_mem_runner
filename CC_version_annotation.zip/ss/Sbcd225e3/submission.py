"""Beer-Lambert absorbance with a concentration-dependent absorptivity: A = path_length * (alpha*concentration + beta*concentration^2)."""
import numpy as np

USED_INPUTS = ["concentration", "path_length"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {"alpha": {"init": None}, "beta": {"init": None}}

def fit(X_fit, y_fit):
    c = np.asarray(X_fit[:, 0], dtype=float)
    l = np.asarray(X_fit[:, 1], dtype=float)
    y = np.asarray(y_fit, dtype=float)
    M = np.column_stack((c * l, c * c * l))
    try:
        coef, _, _, _ = np.linalg.lstsq(M, y, rcond=None)
        alpha, beta = float(coef[0]), float(coef[1])
        if not np.isfinite(alpha) or not np.isfinite(beta):
            raise ValueError
    except Exception:
        denom = float(np.dot(c * l, c * l))
        alpha = float(np.dot(c * l, y) / denom) if denom > 0 else 1.5
        beta = 0.0
    return {"alpha": alpha, "beta": beta}

def predict(X, alpha, beta):
    c = np.asarray(X[:, 0], dtype=float)
    l = np.asarray(X[:, 1], dtype=float)
    return l * (alpha * c + beta * c * c)
