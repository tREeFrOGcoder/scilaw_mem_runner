"""Gaussian thermal performance curve: P = a * exp(-((T - b)^2) / (2 * c^2))"""
import numpy as np
from scipy.optimize import curve_fit

USED_INPUTS = ["temperature"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {"a": {"init": None}, "b": {"init": None}, "c": {"init": None}}

def _gaussian(T, a, b, c):
    return a * np.exp(-((T - b) ** 2) / (2.0 * c ** 2))

def fit(X_fit, y_fit):
    T = X_fit[:, 0]
    a0 = float(np.max(y_fit)) * 1.1
    b0 = float(T[np.argmax(y_fit)])
    c0 = max(float(np.std(T)) * 2.0, 1.0)
    try:
        popt, _ = curve_fit(_gaussian, T, y_fit, p0=[a0, b0, c0], maxfev=5000)
        a, b, c = popt
        a = float(max(a, 1e-30))
        c = float(max(abs(c), 0.1))
        return {"a": a, "b": float(b), "c": c}
    except Exception:
        return {"a": a0, "b": b0, "c": c0}

def predict(X, a, b, c):
    return _gaussian(X[:, 0], a, b, c)
