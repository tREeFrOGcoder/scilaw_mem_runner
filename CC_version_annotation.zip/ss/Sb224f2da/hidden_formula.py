"""Curvature-augmented Pareto self-similarity (memorization-proof variant).

Background form
---------------
The textbook upper-tail self-similarity law writes the log income share of
the top fraction p as a STRAIGHT LINE in log p,

    ln S(p) = a + b * ln p          (strict Pareto-Lorenz)

with slope b = 1 - 1/alpha. Real WID tails are not exactly Pareto: the
extreme upper tail is fatter (or thinner) than a single power law, a
documented departure usually attributed to a double-Pareto / lognormal
middle and to a slowly drifting local tail exponent. The single global
slope b cannot represent that.

This variant replaces the constant log-log slope by a slope that varies
slowly across the tail, i.e. it allows the local Pareto exponent to depend
on how deep into the tail we are. Writing the depth coordinate as ln p, the
log share becomes a quadratic in ln p:

    ln S(p) = a + b * ln p + c * (ln p)^2

Equivalently the *local* self-similarity slope is

    d ln S / d ln p = b + 2c * ln p,

so the effective Pareto exponent alpha(p) = 1 / (1 - b - 2c ln p) drifts
with the percentile depth — a genuinely different functional shape from the
straight-line baseline (parabola vs. line in log-log space), not merely a
re-fit of the same coefficients. The curvature coefficient c is the new
local physical parameter; c -> 0 recovers the strict-Pareto baseline.

Validity
--------
* Models Pareto upper-tail self-similarity (power-law share-vs-fraction with
  a slowly varying local exponent).
* The constant term is fit so the share stays <= 1 (ln S <= 0).
* The dominant slope keeps share/p non-increasing and S non-decreasing in p
  over the released percentile grid; the curvature term is a small
  correction on top of the Pareto slope.

LAW_CONSTANTS  : none (the FORM is the claim).
OTHER_CONSTANTS: none (dimensionless).
LOCAL_FITTABLE : a (scale intercept), b (base self-similarity slope),
                 c (tail-curvature / slope-drift coefficient).
All three are fit per cluster by closed-form ordinary least squares on the
(ln p, (ln p)^2) design — no multi-start, no INIT seeds (init = None),
robust across every group.
"""

import numpy as np

USED_INPUTS = ["log_p_above"]
PAPER_REF = "summary_formula_dataset_atkinson_2011.md"
EQUATION_LOC = (
    "Curvature-augmented Pareto-Lorenz self-similarity: slope drifts with "
    "percentile depth, ln S = a + b ln p + c (ln p)^2 (variant of "
    "Atkinson-Piketty-Saez 2011 log-log regression)."
)

LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {
    "a": {"init": None},   # closed-form OLS
    "b": {"init": None},   # closed-form OLS
    "c": {"init": None},   # closed-form OLS
}


def fit(X_fit: np.ndarray, y_fit: np.ndarray) -> dict:
    """Closed-form OLS of ln S on (ln p, (ln p)^2).

    Slope at percentile depth ln p is b + 2c ln p; c is the new local
    tail-curvature parameter (c = 0 -> strict Pareto baseline).
    """
    log_p = np.asarray(X_fit[:, 0], dtype=float)
    log_S = np.asarray(y_fit, dtype=float)
    A = np.column_stack([np.ones_like(log_p), log_p, log_p ** 2])
    coef, *_ = np.linalg.lstsq(A, log_S, rcond=None)
    a, b, c = float(coef[0]), float(coef[1]), float(coef[2])
    return {"a": a, "b": b, "c": c}


def predict(X: np.ndarray, a: float, b: float, c: float) -> np.ndarray:
    """Curvature-augmented Pareto self-similarity:

        ln S(p) = a + b * ln p + c * (ln p)^2
    """
    log_p = np.asarray(X[:, 0], dtype=float)
    return a + b * log_p + c * log_p ** 2
