"""Cluster-specific quadratic law in ln p for the top income share log."""
import numpy as np

USED_INPUTS = ["log_p_above"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {
    "a": {"init": [0.0]},
    "b": {"init": [0.0]},
    "c": {"init": [0.0]},
}

def fit(X_fit, y_fit):
    x = np.asarray(X_fit, dtype=float)[:, 0]
    y = np.asarray(y_fit, dtype=float)
    A = np.column_stack([np.ones_like(x), x, x * x])
    try:
        coef, *_ = np.linalg.lstsq(A, y, rcond=None)
        if np.all(np.isfinite(coef)):
            return {"a": float(coef[0]), "b": float(coef[1]), "c": float(coef[2])}
    except Exception:
        pass
    mu = float(np.mean(y)) if y.size else 0.0
    return {"a": mu, "b": 0.0, "c": 0.0}

def predict(X, **params):
    x = np.asarray(X, dtype=float)[:, 0]
    a = params["a"]
    b = params["b"]
    c = params["c"]
    return a + b * x + c * x * x
