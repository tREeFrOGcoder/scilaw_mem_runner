"""The Toth adsorption isotherm model, which successfully describes both L-type and S-type equilibrium adsorption behavior of CO2 on metal-organic frameworks across all clusters."""
import numpy as np
from scipy.optimize import curve_fit

USED_INPUTS = ["P_bar"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {"q_sat": {"init": None}, "b": {"init": None}, "t": {"init": None}}

def _toth_form(P, q_sat, b, t):
    # Clip bp to avoid numerical underflow or overflow
    bp = np.clip(b * P, 1e-12, 1e4)
    return q_sat * bp / (1.0 + bp**t)**(1.0/t)

def fit(X_fit, y_fit):
    P = np.maximum(X_fit[:, 0], 0.0)
    y = np.maximum(y_fit, 0.0)
    
    # Establish a reliable initial guess for saturation loading
    q_sat_init = max(float(np.max(y)), 0.1) * 1.2
    p0 = [q_sat_init, 1.0, 1.0]
    bounds = (1e-6, [1000.0, 1000.0, 10.0])
    
    try:
        popt, _ = curve_fit(_toth_form, P, y, p0=p0, bounds=bounds, maxfev=5000)
        return {"q_sat": float(popt[0]), "b": float(popt[1]), "t": float(popt[2])}
    except Exception:
        return {"q_sat": q_sat_init, "b": 1.0, "t": 1.0}

def predict(X, q_sat, b, t):
    P = np.maximum(X[:, 0], 0.0)
    return _toth_form(P, q_sat, b, t)
