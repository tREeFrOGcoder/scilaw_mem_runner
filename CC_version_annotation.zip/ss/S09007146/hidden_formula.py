"""Reparameterized Toth-type CO2 uptake form -- q_CO2 (mmol/g) from P (bar).

MEMORIZATION-PROOF VARIANT (sim3 Type II, multi-group).
-------------------------------------------------------
This is NOT the Sips / Langmuir-Freundlich baseline and NOT the verbatim
textbook Toth isotherm. It is a heterogeneous-surface saturation form written
in a half-saturation parameterization with a tunable approach-to-plateau
exponent and a small linear-affinity scale, so that a model that memorized the
canonical isotherm laws cannot recognize the algebra by inspection while the
form remains physically standard (bounded monolayer, Henry low-P, concave).

Functional form (per group g):
                         a * P
    q(P) = q_m * -------------------------------
                  ( 1 + (a*P / w)^t )^( 1 / t )

with q_m the saturation capacity, a an effective linear affinity
(Henry slope = q_m * a), w a heterogeneity / half-scale, and t > 0 a
plateau-sharpness exponent.

WHY THIS DIFFERS IN SHAPE FROM THE BASELINE (Sips)
--------------------------------------------------
Sips:  q = q_m (bP)^n / (1 + (bP)^n).
  - low-P limit  q ~ q_m b^n P^n   -> a FREUNDLICH POWER LAW (sublinear for
    n<1); it does NOT reproduce Henry's law unless n=1.
This Toth-type form:
  - low-P limit  q ~ q_m * a * P    -> HENRY-LINEAR for every t (the leading
    term in P is exactly linear because the numerator is a*P and the
    denominator -> 1). The heterogeneity instead reshapes the APPROACH to the
    plateau (the `1/t` outer power), not the low-P slope.
So the two forms have genuinely different functional shapes: Sips bends the
low-pressure regime into a power law, this form keeps Henry's law and bends
the high-pressure approach to saturation. After per-group fit the predicted
isotherms are distinct (they cannot be mapped onto each other by reparameter-
ization), and this form additionally satisfies validity rubric #3 (Henry's
law) which the heterogeneous Sips form generally violates.

t = 1 collapses to single-site Langmuir (q = q_m a P / (1 + aP/w)); t != 1
gives the heterogeneous Toth-type plateau approach. Distinct after fit.

Task framing (v2 Type II): cluster = (MOF, T_K); 13 GCMC pressure points each;
P_bar is the sole predict() input; q_m, a, w, t are per-cluster LOCAL params.

Validity (rubric-respecting):
  - finite plateau q -> q_m as P -> inf                 (rubric 1, 2)
  - Henry-linear as P -> 0  (q ~ q_m a P)               (rubric 3)
  - concave / saturating, monotone non-decreasing       (rubric 4, 7)
  - q >= 0 for all P >= 0, q(0) = 0                      (rubric 5, 6)

Contract mirrors sips_langmuir_freundlich_1948.py: USED_INPUTS,
LOCAL_FITTABLE, fit(X_fit, y_fit) -> dict, predict(X, **params); pure
numpy + scipy, deterministic data-derived single-start bounded LS.
"""

import numpy as np
from scipy.optimize import least_squares

USED_INPUTS = ["P_bar"]

LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {
    "q_m": {"init": None},
    "a":   {"init": None},
    "w":   {"init": None},
    "t":   {"init": None},
}


def _q_co2(P, q_m, a, w, t):
    """Reparameterized Toth-type: q = q_m * aP / (1 + (aP/w)^t)^(1/t)."""
    P = np.clip(np.asarray(P, dtype=float), 0.0, None)
    aP = a * P
    # denominator base >= 1, so the outer power is well-defined and >= 1.
    base = 1.0 + np.power(np.clip(aP / w, 0.0, None), t)
    denom = np.power(base, 1.0 / t)
    return q_m * aP / denom


def fit(X_fit: np.ndarray, y_fit: np.ndarray) -> dict:
    """Bounded nonlinear LS, deterministic data-derived single start.

    Start recipe (mirrors the Sips baseline's data-derived strategy):
      q_m0 = 1.1 * max(y)            -- plateau estimate (slightly above max)
      henry = median(y/P) over the lowest-P quartile  -- Henry slope q_m*a
      a0    = henry / q_m0
      w0    = a0 * P_mid             -- half-scale near the mid-pressure point
                                        (puts the saturation knee inside data)
      t0    = 1.0                    -- Langmuir special case (warm start)
    """
    P = np.asarray(X_fit[:, 0], dtype=float)
    y = np.asarray(y_fit, dtype=float)

    y_max = float(np.max(y)) if len(y) > 0 else 1.0
    q_m0 = 1.1 * y_max if y_max > 0.0 else 1.0

    if len(P) > 0:
        P_thresh = np.percentile(P, 25.0)
        low_mask = P <= P_thresh
        if not low_mask.any():
            low_mask = np.ones(len(P), dtype=bool)
        with np.errstate(divide="ignore", invalid="ignore"):
            ratios = np.where(P[low_mask] > 0.0, y[low_mask] / P[low_mask], 0.0)
        henry = float(np.median(ratios[ratios > 0.0])) if (ratios > 0.0).any() else 1e-3
        P_mid = float(np.median(P[P > 0.0])) if (P > 0.0).any() else 1.0
    else:
        henry = 1e-3
        P_mid = 1.0

    a0 = henry / q_m0 if q_m0 > 0.0 else 1e-3
    if not np.isfinite(a0) or a0 <= 0.0:
        a0 = 1e-3
    w0 = a0 * P_mid
    if not np.isfinite(w0) or w0 <= 0.0:
        w0 = 1.0
    t0 = 1.0

    # Bounds: q_m in (0,500]; a in (0,1e4]; w in (0,1e4]; t in (0.1,6].
    param_lo = [1e-6, 1e-8, 1e-8, 0.1]
    param_hi = [500.0, 1e4, 1e4, 6.0]

    p0 = [
        min(max(q_m0, param_lo[0]), param_hi[0]),
        min(max(a0,   param_lo[1]), param_hi[1]),
        min(max(w0,   param_lo[2]), param_hi[2]),
        min(max(t0,   param_lo[3]), param_hi[3]),
    ]

    def residual(p):
        return _q_co2(P, p[0], p[1], p[2], p[3]) - y

    try:
        sol = least_squares(
            residual, p0,
            bounds=(param_lo, param_hi),
            method="trf",
            max_nfev=4000,
        )
        q_m, a, w, t = sol.x
        if not np.all(np.isfinite([q_m, a, w, t])):
            raise RuntimeError("non-finite fit result")
        return {"q_m": float(q_m), "a": float(a), "w": float(w), "t": float(t)}
    except Exception:                                       # noqa: BLE001
        return {"q_m": float(p0[0]), "a": float(p0[1]),
                "w": float(p0[2]), "t": float(p0[3])}


def predict(X: np.ndarray, q_m: float, a: float, w: float, t: float) -> np.ndarray:
    """Reparameterized Toth-type isotherm.

    X: (n_rows, 1) -- column [P_bar]. Returns q_CO2 in mmol/g.
    """
    P = np.asarray(X[:, 0], dtype=float)
    return _q_co2(P, q_m, a, w, t)
