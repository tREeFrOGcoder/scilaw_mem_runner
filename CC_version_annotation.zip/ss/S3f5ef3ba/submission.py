"""PFAS sorption: log10 Kd scales with the average of log10(Kow) and log10(foc) plus offset."""
import numpy as np

USED_INPUTS = ["log_Kow", "foc"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {}

def predict(X):
    log_Kow = X[:, 0]
    foc = X[:, 1]
    # Use log10 of foc (foc already fraction). Model: log_kd = 0.5*(log_Kow + log10(foc)) + offset
    return 0.5 * (log_Kow + np.log10(foc)) - 0.63622374
