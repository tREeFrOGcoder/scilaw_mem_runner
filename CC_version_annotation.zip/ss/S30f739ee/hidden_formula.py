"""Memorization-proof VARIANT of the modified-STIRPAT law for national N2O.

Baseline (textbook, Vazquez 2022 Eq. 9 / Table 2, NOE row):

    log(NOE) = a + w_GDP*log(GDP) + w_TP*log(TP) + w_AP*log(AP)
               + w_DP*log(DP) + w_UR*log(UR) + w_AT*log(AT_K)

That canonical STIRPAT form assumes a CONSTANT population elasticity:
log(NOE) is strictly linear in log(TP). This variant relaxes that single
assumption with one extra physical term — a quadratic curvature in
log-population:

    log(NOE) = a + w_GDP*log(GDP)
               + w_TP*log(TP) + w_TP2*log(TP)^2          # <-- shape change
               + w_AP*log(AP) + w_DP*log(DP)
               + w_UR*log(UR) + w_AT*log(AT_K)

with AT_K = AT_celsius + 273.15.

Why this is a genuine SHAPE change (survives a downstream refit):
    The added term is quadratic in log(TP); it cannot be absorbed by any
    re-optimisation of the linear coefficients of the textbook form. The
    fitted w_TP2 is materially negative (~ -0.012 in log10 units), so a
    refit keeps it — it does not collapse back to the log-linear STIRPAT
    law. The local population ELASTICITY becomes
        d log(NOE) / d log(TP) = w_TP + 2*w_TP2*log(TP),
    i.e. it DECLINES with country size: large-population nations add N2O
    sublinearly per extra person (agricultural-soil/livestock saturation),
    a variable-elasticity refinement of STIRPAT's fixed-elasticity prior.

Physical plausibility / validity rubrics:
    - Sublinear growth with total population: w_TP > 0 with w_TP2 < 0 makes
      the population elasticity fall below 1 over the data range (rubric).
    - Sublinear growth with per-capita GDP: w_GDP in (0,1) (rubric).
    - Dampening of AP, DP, UR, AT_K retained via negative coefficients.
    - exp() output is strictly non-negative (rubric).

Contract: USED_INPUTS identical to the baseline; LAW_CONSTANTS are the
constants fitted here by scipy on the pooled NOE panel (log10 target);
predict(X, **LAW_CONSTANTS) is pure-numpy and vectorised.
"""

import numpy as np

USED_INPUTS = ["GDP", "TP", "AP", "DP", "UR", "AT"]
PAPER_REF   = "summary_formula+dataset_vazquez_2022.md"
EQUATION_LOC = "Variant of Vazquez 2022 Eq. 9: STIRPAT + log(TP)^2 population-saturation curvature"

# === LAW_CONSTANTS — fitted here (scipy curve_fit, log10 target) ===
LAW_CONSTANTS = {
    "a":     20.299,
    "w_GDP":  0.378,
    "w_TP":   0.940,
    "w_TP2": -0.012,
    "w_AP":  -1.656,
    "w_DP":  -0.145,
    "w_UR":  -0.052,
    "w_AT":  -2.542,
}

# OTHER_CONSTANTS: unit conversion only (SI definition, not a fit value).
OTHER_CONSTANTS = {
    "K_OFFSET": 273.15,   # Celsius to Kelvin
}

# Type I: no per-cluster parameters.
LOCAL_FITTABLE = {}

_K_OFFSET = OTHER_CONSTANTS["K_OFFSET"]


def predict(X: np.ndarray, **params) -> np.ndarray:
    """Evaluate the STIRPAT + population-saturation variant for NOE in kg N2O.

    X.shape = (n, 6) in USED_INPUTS order: (GDP, TP, AP, DP, UR, AT[degrees C]).
    Returns NOE in kg N2O (strictly non-negative via exp()).
    """
    a     = params.get("a",     LAW_CONSTANTS["a"])
    w_GDP = params.get("w_GDP", LAW_CONSTANTS["w_GDP"])
    w_TP  = params.get("w_TP",  LAW_CONSTANTS["w_TP"])
    w_TP2 = params.get("w_TP2", LAW_CONSTANTS["w_TP2"])
    w_AP  = params.get("w_AP",  LAW_CONSTANTS["w_AP"])
    w_DP  = params.get("w_DP",  LAW_CONSTANTS["w_DP"])
    w_UR  = params.get("w_UR",  LAW_CONSTANTS["w_UR"])
    w_AT  = params.get("w_AT",  LAW_CONSTANTS["w_AT"])

    GDP = np.asarray(X[:, 0], dtype=float)
    TP  = np.asarray(X[:, 1], dtype=float)
    AP  = np.asarray(X[:, 2], dtype=float)
    DP  = np.asarray(X[:, 3], dtype=float)
    UR  = np.asarray(X[:, 4], dtype=float)
    AT  = np.asarray(X[:, 5], dtype=float)

    AT_K = AT + _K_OFFSET   # Celsius -> Kelvin; range 268-303 K, always positive
    log_TP = np.log(TP)

    log_NOE = (
        a
        + w_GDP * np.log(GDP)
        + w_TP  * log_TP
        + w_TP2 * log_TP * log_TP        # population-saturation curvature
        + w_AP  * np.log(AP)
        + w_DP  * np.log(DP)
        + w_UR  * np.log(UR)
        + w_AT  * np.log(AT_K)
    )
    return np.exp(log_NOE)
