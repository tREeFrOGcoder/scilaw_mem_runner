"""NOE = TP * k * GDP / (GDP + g0) with fitted k and g0."""
import numpy as np

USED_INPUTS = ["GDP", "TP", "AP", "DP", "UR", "AT"]  # predict reads GDP and TP but must list inputs in X-column order
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {}

def predict(X):
    # X[:,0] = GDP, X[:,1] = TP
    GDP = X[:, 0].astype(float)
    TP = X[:, 1].astype(float)
    # Fitted parameters (baked in)
    k = 1.7712259008537865
    g0 = 2019.4698806308463
    return TP * k * (GDP / (GDP + g0))
