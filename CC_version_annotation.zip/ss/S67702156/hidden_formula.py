"""Generalized-skew thermal performance curve (memorization-proof variant).

A physically-plausible thermal performance curve with the same three landmark
quantities as the universal attractor (peak performance, optimal temperature,
critical temperature) but a tunable cold-side/denaturation balance. The form
is written about the rescaled coordinate

    x = (T - Topt) / (Tc - Topt)

so that x = 0 at the optimum and x = 1 at the critical temperature, and the
curve is

    performance(T) = Pfmax * (1 - x)_+^m * exp(m * x)

where (1 - x)_+ = max(1 - x, 0) and m > 0 is a single shape (skew) exponent.

Why this is a valid thermal performance curve
----------------------------------------------
- Cold side (x < 0): the factor exp(m*x) is the thermodynamic / Q10-like
  exponential acceleration of the rate with warming; the (1-x)^m factor is
  >= 1 and slowly varying, so performance rises smoothly toward the peak.
- Peak: d/dx [ m*ln(1-x) + m*x ] = m * ( -1/(1-x) + 1 ) = -m*x/(1-x), which
  vanishes only at x = 0. The curve therefore has a single optimum exactly at
  T = Topt, where performance = Pfmax. It is unimodal.
- High side: as x -> 1 the (1-x)^m denaturation factor drives performance to
  zero; for x >= 1 (T >= Tc) the clamped factor is identically 0, so
  performance is exactly zero at and above the critical temperature.
- Non-negativity: both factors are non-negative for all T, so the prediction
  is non-negative everywhere.

Relation to the textbook attractor
----------------------------------
Setting m = 1 reduces the high-side factor's leading behaviour and recovers
the same landmark structure as the classic attractor, but for m != 1 the
cold-side curvature and the high-side roll-off skew differ in functional
shape, not merely in coefficients. After a per-experiment fit the exponent m
adapts the asymmetry of each curve, giving a form that is distinct from the
fixed-shape textbook law.

LAW_CONSTANTS — none. OTHER_CONSTANTS — none.

LOCAL_FITTABLE — per-cluster, computed by fit() via nonlinear least squares
---------------------------------------------------------------------------
- Pfmax : peak performance of this experiment (cluster's own units).
- Topt  : optimal temperature (degrees C).
- Tc    : critical temperature (degrees C), Tc > Topt.
- m     : shape / skew exponent (> 0); controls cold-side rise vs high-side
          denaturation asymmetry. m = 1 is the symmetric-landmark baseline.
"""

import numpy as np
from scipy.optimize import least_squares

USED_INPUTS = ["temperature"]

LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {
    "Pfmax": {"init": None},
    "Topt":  {"init": None},
    "Tc":    {"init": None},
    "m":     {"init": None},
}

_M_LO, _M_HI = 0.1, 8.0


def _tpc(T, Pfmax, Topt, Tc, m):
    denom = Tc - Topt
    if abs(denom) < 1e-9:
        denom = 1e-9 if denom >= 0 else -1e-9
    x = (T - Topt) / denom
    one_minus = np.maximum(1.0 - x, 0.0)        # zero at and above Tc
    arg = np.clip(m * x, -700.0, 700.0)         # guard exp overflow
    return Pfmax * (one_minus ** m) * np.exp(arg)


def fit(X_fit: np.ndarray, y_fit: np.ndarray) -> dict:
    """Bounded nonlinear least-squares fit of the generalized-skew TPC.

    Deterministic, data-derived start:
      Topt0  = temperature at the largest observed performance,
      Pfmax0 = the largest observed performance,
      Tc0    = Topt0 + half the observed temperature span (Tc above Topt),
      m0     = 1.0 (the symmetric-landmark baseline shape).
    Tc is bounded above Topt and m to a positive range; the solve is wrapped
    so non-convergence falls back to the deterministic start.
    """
    T = np.asarray(X_fit[:, 0], dtype=float)
    y = np.asarray(y_fit, dtype=float)

    Topt0 = float(T[int(np.argmax(y))])
    Pfmax0 = float(np.max(y))
    if Pfmax0 <= 0:
        Pfmax0 = float(np.max(np.abs(y))) or 1.0
    span = float(T.max() - T.min())
    half = max(0.5 * span, 1.0)
    Tc0 = Topt0 + half
    m0 = 1.0

    # Parameterise Tc as Topt + gap with gap > 0 so the optimum stays below
    # the critical temperature; m bounded positive.
    lo = [-np.inf, -np.inf, 1e-3, _M_LO]
    hi = [np.inf, np.inf, np.inf, _M_HI]

    def residual(p):
        Pfmax, Topt, gap, m = p
        Tc = Topt + gap
        return _tpc(T, Pfmax, Topt, Tc, m) - y

    p0 = [Pfmax0, Topt0, half, m0]
    p0 = [min(max(v, l), h) for v, l, h in zip(p0, lo, hi)]
    try:
        sol = least_squares(residual, p0, bounds=(lo, hi),
                            method="trf", max_nfev=4000)
        Pfmax, Topt, gap, m = sol.x
        Tc = Topt + gap
        if not np.all(np.isfinite([Pfmax, Topt, Tc, m])) or gap < 1e-9:
            raise RuntimeError("degenerate fit")
        return {"Pfmax": float(Pfmax), "Topt": float(Topt),
                "Tc": float(Tc), "m": float(m)}
    except Exception:                              # noqa: BLE001 — fall back
        return {"Pfmax": Pfmax0, "Topt": Topt0, "Tc": Tc0, "m": m0}


def predict(X: np.ndarray, Pfmax: float, Topt: float, Tc: float, m: float) -> np.ndarray:
    """performance = Pfmax * (1 - x)_+^m * exp(m*x), x = (T-Topt)/(Tc-Topt).

    X: (n, 1) — column 0 is temperature (degrees C).
    """
    T = np.asarray(X[:, 0], dtype=float)
    return _tpc(T, Pfmax, Topt, Tc, m)
