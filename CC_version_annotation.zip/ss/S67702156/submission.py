"""High-temperature Sharpe-Schoolfield thermal performance curve with per-cluster scale, activation energy, deactivation energy, and high-temperature midpoint."""
import numpy as np
from scipy.optimize import curve_fit

USED_INPUTS = ["temperature"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {"kB": 8.617333262145e-5}
LOCAL_FITTABLE = {
    "B0": {"init": None},
    "E": {"init": None},
    "Eh": {"init": None},
    "Th": {"init": None},
}

def _schoolfield_high(T_c, B0, E, Eh, Th):
    kB = OTHER_CONSTANTS["kB"]
    Tk = np.asarray(T_c, dtype=float) + 273.15
    return (B0 * np.exp(-E / (kB * Tk))) / (1.0 + np.exp((Eh / kB) * (1.0 / Th - 1.0 / Tk)))

def fit(X_fit, y_fit):
    T = np.asarray(X_fit[:, 0], dtype=float)
    y = np.asarray(y_fit, dtype=float)

    kB = OTHER_CONSTANTS["kB"]
    Tk0 = float(np.mean(T) + 273.15)
    B0_guess = float(max(np.max(y), 1e-12) * np.exp(0.3 / (kB * Tk0)))

    p0_list = [
        [B0_guess, 0.30, 0.50, 267.0],
        [B0_guess, 0.15, 0.40, 268.0],
        [B0_guess, 0.45, 0.60, 270.0],
    ]
    bounds = ([0.0, 0.0, 0.0, 250.0], [np.inf, 10.0, 10.0, 350.0])

    best = None
    best_sse = np.inf
    for p0 in p0_list:
        try:
            popt, _ = curve_fit(_schoolfield_high, T, y, p0=p0, bounds=bounds, maxfev=20000)
            pred = _schoolfield_high(T, *popt)
            sse = float(np.sum((pred - y) ** 2))
            if np.isfinite(sse) and sse < best_sse:
                best_sse = sse
                best = popt
        except Exception:
            pass

    if best is None:
        best = np.array(p0_list[0], dtype=float)

    return {"B0": float(best[0]), "E": float(best[1]), "Eh": float(best[2]), "Th": float(best[3])}

def predict(X, **params):
    return _schoolfield_high(
        np.asarray(X[:, 0], dtype=float),
        params["B0"],
        params["E"],
        params["Eh"],
        params["Th"],
    )
