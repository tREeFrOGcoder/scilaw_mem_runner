"""Gravity model of trade with GDP interaction term."""
import numpy as np

USED_INPUTS = ["log_gdp_o", "log_gdp_d", "log_dist", "contig", "comlang_off", "col_dep_ever", "fta_wto"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {}

def predict(X):
    log_gdp_o = X[:, 0]
    log_gdp_d = X[:, 1]
    log_dist = X[:, 2]
    contig = X[:, 3]
    comlang_off = X[:, 4]
    col_dep_ever = X[:, 5]
    fta_wto = X[:, 6]
    return (-10.935 + 0.725*log_gdp_o + 0.430*log_gdp_d - 1.153*log_dist
            + 0.624*contig + 0.692*comlang_off + 1.156*col_dep_ever + 0.880*fta_wto
            + 0.0257*log_gdp_o*log_gdp_d)
