"""Size-complementarity gravity variant — non-separable GDP interaction.

A MEMORIZATION-PROOF variant of the naive log-linear gravity law
(Head & Mayer 2014, Eq. 4). The textbook form is strictly SEPARABLE in the
two log-GDPs, with constant, independent elasticities:

    ln X_ni = beta_0 + a*ln Y_i + b*ln Y_n + (trade-cost terms)

This variant breaks that separability with a single bilinear SIZE-COMPLEMENTARITY
term in the product of the two log-GDPs:

    ln X_ni = beta_0 + a*ln Y_i + b*ln Y_n + kappa*(ln Y_i * ln Y_n)
              + beta_dist*ln Dist_ni + beta_contig*Contig_ni
              + beta_comlang*ComLang_ni + beta_col*Colony_ni + beta_fta*RTA_ni

Economic reading: the gravity "mass" effect is super-additive. The effective
origin-GDP elasticity is (a + kappa*ln Y_n) — it RISES with the destination's
economic size, and symmetrically for the destination. Large economies trading
with other large economies exchange disproportionately more than the naive
log-linear (separable, constant-elasticity) law predicts. kappa > 0 encodes
this complementarity; kappa = 0 recovers the textbook separable form exactly.

Why it is memorization-proof / shape-distinct: the bilinear interaction
kappa*(ln Y_i * ln Y_n) is NOT in the column span of the linear regressors
{1, ln Y_i, ln Y_n, ...}. A downstream re-optimization of ALL coefficients
cannot fold it back into a*ln Y_i + b*ln Y_n, so the functional shape stays
distinct from the textbook law after refit. A model that memorized the canonical
"a*ln Y_i + b*ln Y_n" gravity law cannot pattern-match this and must recover the
interaction from the simulator's noisy data.

Validity (matches the task's frozen validity_rubrics):
  * trade-promoting effect of origin-country size       (a, kappa terms in ln Y_i)
  * trade-promoting effect of destination-country size  (b, kappa terms in ln Y_n)
  * trade-suppressing distance resistance                (beta_dist < 0)
  * shared-border / common-language / colonial / RTA frictions reduced
    (beta_contig, beta_comlang, beta_col, beta_fta > 0)

Type designation: TYPE I — a single global parameter set across all
(origin, destination, year) dyads; no per-cluster refit. LOCAL_FITTABLE = {}.

Column mapping (paper notation -> released CSV):
  ln Y_i     -> log_gdp_o    (origin-country log GDP)
  ln Y_n     -> log_gdp_d    (destination-country log GDP)
  ln Dist_ni -> log_dist     (log bilateral distance)
  Contig_ni  -> contig       (contiguity binary)
  ComLang_ni -> comlang_off  (official common language binary)
  Colony_ni  -> col_dep_ever (colonial link binary)
  RTA_ni     -> fta_wto      (WTO-notified RTA binary)
  ln Y_i*ln Y_n -> computed internally (NOT a CSV column — the SR discovery target)

LAW_CONSTANTS below were fit by nonlinear least squares (scipy curve_fit) on the
in-sample train split (year <= 2016, 470,769 dyads). Train RMSE = 2.5127, on par
with the separable baseline (2.5150) while adding a single complementarity coeff.
"""

import numpy as np

USED_INPUTS = [
    "log_gdp_o",
    "log_gdp_d",
    "log_dist",
    "contig",
    "comlang_off",
    "col_dep_ever",
    "fta_wto",
]

PAPER_REF = "summary_formula_head_2014.md"

EQUATION_LOC = (
    "Size-complementarity gravity variant: ln X = beta_0 + a*ln Y_i + b*ln Y_n "
    "+ kappa*(ln Y_i * ln Y_n) + bilateral trade-cost terms. The bilinear "
    "kappa term breaks the textbook separable-elasticity form (kappa=0 recovers "
    "Head & Mayer 2014 Eq. 4)."
)

# === LAW_CONSTANTS — fit on the train split (scipy curve_fit) ===
LAW_CONSTANTS = {
    "a":            0.828699,    # origin log-GDP elasticity (base, at ln Y_n = 0)
    "b":            0.541900,    # destination log-GDP elasticity (base, at ln Y_i = 0)
    "kappa":        0.019666,    # size-complementarity (bilinear GDP interaction), > 0
    "beta_dist":   -1.137409,    # distance resistance, < 0
    "beta_contig":  1.045691,    # shared-border friction reduction, > 0
    "beta_comlang": 0.951118,    # common-language friction reduction, > 0
    "beta_col":     1.054655,    # colonial-link friction reduction, > 0
    "beta_fta":     0.737002,    # trade-agreement friction reduction, > 0
}

# === OTHER_CONSTANTS — data-fit intercept (not a paper value, unit-dependent) ===
OTHER_CONSTANTS = {
    "beta_0": -12.822086,  # gravity constant + log-unit shift; data-fit on train
}

LOCAL_FITTABLE = {}    # Type I — single global parameter set, no per-cluster refit.


def predict(
    X: np.ndarray,
    a: float,
    b: float,
    kappa: float,
    beta_dist: float,
    beta_contig: float,
    beta_comlang: float,
    beta_col: float,
    beta_fta: float,
) -> np.ndarray:
    """Predict log_tradeflow from the size-complementarity gravity variant.

    ln X = beta_0 + a*ln Y_i + b*ln Y_n + kappa*(ln Y_i * ln Y_n)
           + beta_dist*ln Dist + beta_contig*Contig + beta_comlang*ComLang
           + beta_col*Colony + beta_fta*RTA

    X: (n, 7) — columns in USED_INPUTS order
       [log_gdp_o, log_gdp_d, log_dist, contig, comlang_off, col_dep_ever, fta_wto].
    The harness passes predict(X, **LAW_CONSTANTS); beta_0 is read from
    OTHER_CONSTANTS in the module namespace.
    """
    beta_0 = OTHER_CONSTANTS["beta_0"]
    X = np.asarray(X, dtype=np.float64)
    log_gdp_o    = X[:, 0]
    log_gdp_d    = X[:, 1]
    log_dist     = X[:, 2]
    contig       = X[:, 3]
    comlang_off  = X[:, 4]
    col_dep_ever = X[:, 5]
    fta_wto      = X[:, 6]

    return (
        beta_0
        + a            * log_gdp_o
        + b            * log_gdp_d
        + kappa        * (log_gdp_o * log_gdp_d)   # size-complementarity interaction
        + beta_dist    * log_dist
        + beta_contig  * contig
        + beta_comlang * comlang_off
        + beta_col     * col_dep_ever
        + beta_fta     * fta_wto
    )
