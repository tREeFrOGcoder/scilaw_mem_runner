"""Three-parameter log-log quadratic upper-tail share curve: ln S(p) is a cluster-specific quadratic function of ln p."""
import numpy as np

USED_INPUTS = ["log_p_above"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {
    "a": {"init": None},
    "b": {"init": None},
    "c": {"init": None},
}

def fit(X_fit, y_fit):
    x = np.asarray(X_fit[:, 0], dtype=float)
    y = np.asarray(y_fit, dtype=float)
    m = np.isfinite(x) & np.isfinite(y)
    x = x[m]
    y = y[m]
    if x.size == 0:
        return {"a": 0.0, "b": 0.5, "c": 0.0}
    if x.size < 3 or np.unique(x).size < 3:
        A = np.column_stack([np.ones_like(x), x])
        try:
            coef = np.linalg.lstsq(A, y, rcond=None)[0]
            return {"a": float(coef[0]), "b": float(coef[1]), "c": 0.0}
        except Exception:
            return {"a": float(np.mean(y)), "b": 0.5, "c": 0.0}
    A = np.column_stack([np.ones_like(x), x, x * x])
    try:
        coef = np.linalg.lstsq(A, y, rcond=None)[0]
        a, b, c = coef
    except Exception:
        a = float(np.mean(y))
        b = 0.5
        c = 0.0
    return {"a": float(a), "b": float(b), "c": float(c)}

def predict(X, a, b, c):
    x = np.asarray(X[:, 0], dtype=float)
    return a + b * x + c * x * x
