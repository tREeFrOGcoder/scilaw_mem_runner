"""S = 1 / (1 + a * d^b) — generalized Hill/logistic decay in environmental distance."""
import numpy as np
from scipy.optimize import curve_fit

USED_INPUTS = ["env_dist"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {"a": {"init": None}, "b": {"init": None}}

def _form(d, a, b):
    return 1.0 / (1.0 + a * d**b)

def fit(X_fit, y_fit):
    d = X_fit[:, 0]
    S = y_fit
    best_popt = None
    best_ss = np.inf
    for p0 in [[1.0, 1.0], [0.5, 0.5], [2.0, 2.0], [0.1, 0.1], [5.0, 1.5], [0.01, 3.0]]:
        try:
            popt, _ = curve_fit(_form, d, S, p0=p0, maxfev=5000)
            ss = np.sum((S - _form(d, *popt))**2)
            if ss < best_ss:
                best_ss = ss
                best_popt = popt
        except Exception:
            pass
    if best_popt is not None:
        return {"a": float(best_popt[0]), "b": float(best_popt[1])}
    # Fallback: linearize via log(1/S - 1) = log(a) + b*log(d)
    try:
        S_safe = np.clip(S, 1e-10, 1 - 1e-10)
        y = np.log(1.0 / S_safe - 1.0)
        x = np.log(d)
        coef = np.polyfit(x, y, 1)
        return {"a": float(np.exp(coef[1])), "b": float(coef[0])}
    except Exception:
        return {"a": 1.0, "b": 1.0}

def predict(X, a, b):
    d = X[:, 0]
    return 1.0 / (1.0 + a * d**b)
