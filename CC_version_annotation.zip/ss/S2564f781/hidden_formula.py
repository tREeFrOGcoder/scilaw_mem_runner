"""Offset (de-singularised) power-law distance-decay of community similarity.

MEMORIZATION-PROOF VARIANT of the textbook log-log power law
(soininen_powerlaw: Sim = exp(alpha) * d ** beta).

A model that memorised the Soininen et al. (2007) power-law form predicts
Sim(d) = exp(alpha) * d ** beta, which is pathological at the origin: as the
environmental separation d -> 0 the similarity either diverges (beta < 0) or
collapses to 0 (beta > 0), even though two communities at *zero* environmental
distance are not infinitely / un-boundedly similar. The variant introduces a
fixed characteristic separation scale d0 (a minimum environmental distance below
which pairs are effectively co-located) and decays as a power law of the
*shifted* separation:

    Sim(d) = exp(alpha) * (d + d0) ** beta            (beta < 0)

This is the **shifted / offset power law** (a Hill / "modified power-law"
parameterisation). It differs in FUNCTIONAL SHAPE from the textbook d ** beta
form, not merely in coefficients: near the origin it flattens to a finite plateau
exp(alpha) * d0 ** beta instead of diverging, and the two forms remain distinct
after a per-group fit because log(d + d0) is not an affine function of log(d).
For d >> d0 it recovers the familiar power-law tail, so it is observationally
faithful at the distances the literature actually fits.

Physical reading of the offset: ecological communities never sit at literally
zero standardised environmental distance (binning, measurement granularity), so a
small fixed floor d0 on the effective separation is the physically honest model.

LAW_CONSTANTS  — none. d0 is a *structural* regulariser (module-level, like the
                 baseline's _D_FLOOR), not a fitted or theory-named coefficient.
OTHER_CONSTANTS— none.
LOCAL_FITTABLE — alpha, beta. Two per-group parameters fitted by exact closed-form
                 OLS of ln(Sim) on ln(d + d0) (init = None — deterministic).
"""

import numpy as np

USED_INPUTS = ["env_dist"]
PAPER_REF = "summary_formula_dataset_soininen_2007.md"
EQUATION_LOC = (
    "Offset power-law variant of Soininen et al. (2007) log-log form: "
    "ln[Sim(d)] = beta*ln(d + d0) + alpha  =>  Sim(d) = exp(alpha)*(d + d0)**beta, "
    "with d0 a fixed minimum-separation scale that de-singularises the origin."
)

LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {
    "alpha": {"init": None},   # closed-form OLS in shifted log-log space
    "beta":  {"init": None},
}

# --- structural constants (not fitted, not theory coefficients) ---
_D0 = 0.2        # fixed minimum-separation scale that de-singularises d -> 0
_SIM_FLOOR = 1e-6   # similarity floor so ln(Sim) is finite when fitting
_D_FLOOR = 0.0      # env_dist is >= 0; the +_D0 shift keeps the argument positive


def fit(X_fit: np.ndarray, y_fit: np.ndarray) -> dict:
    """Closed-form OLS of ln(Sim_sor) on ln(env_dist + d0)."""
    d = np.clip(np.asarray(X_fit[:, 0], dtype=float), _D_FLOOR, None)
    y = np.clip(np.asarray(y_fit, dtype=float), _SIM_FLOOR, None)
    A = np.column_stack([np.ones_like(d), np.log(d + _D0)])
    coef, *_ = np.linalg.lstsq(A, np.log(y), rcond=None)
    return {"alpha": float(coef[0]), "beta": float(coef[1])}


def predict(X: np.ndarray, alpha: float, beta: float) -> np.ndarray:
    """Sim_sor = exp(alpha) * (env_dist + d0) ** beta.

    X: (n, 1) — column 0 is env_dist.
    """
    d = np.clip(np.asarray(X[:, 0], dtype=float), _D_FLOOR, None)
    sim = np.exp(alpha) * np.power(d + _D0, beta)
    # Sorensen similarity is bounded [0, 1]; clip so predictions stay valid even
    # under extrapolation toward d -> 0 (does not touch any in-data prediction).
    return np.clip(sim, _SIM_FLOOR, 1.0)
