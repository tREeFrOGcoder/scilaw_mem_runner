"""Memorization-proof VARIANT for BNS dynamical-ejecta terminal velocity <v_inf>.

Distinct functional SHAPE from the textbook Nedora (2020) recommended form
(a full 2nd-order polynomial P_2^2(q, Lambda_tilde),
    vej = b0 + b1 q + b2 Lt + b3 q^2 + b4 q Lt + b5 Lt^2).

Instead of the polynomial-in-Lambda_tilde dependence, this variant uses a
single physically-motivated POWER-LAW term in the reduced tidal deformability
plus a linear mass-ratio term:

    vej = a0 + a1 * q + a2 * Lambda_tilde**p .

Physical rationale: the dynamical-ejecta velocity is set by the depth of the
gravitational potential at tidal disruption, i.e. by the stellar compactness
C ~ M/R. The reduced tidal deformability scales steeply with radius,
Lambda_tilde ~ (R/M)^5, so a softer EOS (smaller Lambda_tilde, more compact
star) ejects matter faster. A monomial Lambda_tilde**p (with p fitted, here
p ~ -0.56, near the compactness-scaling exponent -1/5 to -2/5) captures this
saturating decline of vej with Lambda_tilde without imposing the polynomial's
fixed quadratic curvature. The free exponent makes the shape genuinely
non-polynomial: a downstream least-squares refit re-optimizes a0, a1, a2, p
but cannot reduce a fractional/negative power of Lambda_tilde to the
baseline's {Lt, Lt^2} polynomial basis, so the form stays distinct after
refit.

The mass-ratio dependence stays linear in q (heavier asymmetry -> the lighter
star is tidally disrupted earlier at lower velocity, a1 < 0).

Symbol map: paper q -> CSV q (>= 1, label-symmetric by construction); paper
Lambda_tilde -> CSV Lambda_tilde (mass-weighted, label-symmetric); output in
units of c.

Validity:
  - depends on mass-ratio asymmetry q (a1 term);
  - depends on tidal deformability / EOS stiffness Lambda_tilde (a2 power term);
  - q and Lambda_tilde are both invariant under the NS-label interchange, so
    the prediction is label-symmetric by construction;
  - over the calibration support box (q in [1, 2.06], Lambda_tilde in
    [49, 3200]) the prediction stays in ~(0.12, 0.34) c: non-negative and
    safely below the speed of light.

Coefficients refit on the real data (scipy curve_fit, SMAPE space).
"""

import numpy as np

USED_INPUTS = ["q", "Lambda_tilde"]
PAPER_REF = "summary_formula_dataset_nedora_2020.md"
EQUATION_LOC = "variant: linear-q + power-law(Lambda_tilde) terminal-velocity form"
# === LAW_CONSTANTS — fitted on the real data ===
LAW_CONSTANTS = {
    "a0": 0.270631,
    "a1": -0.079580,
    "a2": 1.252526,
    "p": -0.556044,
}
# === OTHER_CONSTANTS — universal physics factors ===
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {}


def predict(
    X,
    a0=LAW_CONSTANTS["a0"],
    a1=LAW_CONSTANTS["a1"],
    a2=LAW_CONSTANTS["a2"],
    p=LAW_CONSTANTS["p"],
):
    X = np.asarray(X, dtype=float)
    q = X[:, 0]
    Lt = X[:, 1]
    return a0 + a1 * q + a2 * np.power(np.maximum(Lt, 1e-12), p)
