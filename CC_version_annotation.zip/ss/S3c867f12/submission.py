"""Dynamical ejecta velocity: additive in q and power-law in tidal deformability.

vej = a + b*(q-1) + c * Lambda_tilde^r
"""
import numpy as np

USED_INPUTS = ["q", "Lambda_tilde"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {}

def predict(X):
    q = X[:, 0]
    lt = X[:, 1]
    a = 0.191314
    b = -0.081346
    c = 1.224626
    r = -0.548726
    return a + b * (q - 1.0) + c * lt**r
