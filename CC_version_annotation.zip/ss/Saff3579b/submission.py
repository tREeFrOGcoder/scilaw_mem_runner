"""
Baseflow recession following Boussinesq power-law: dQ/dt = -a*Q^b
Solution: Q(t) = [Q_0^(1-b) + a*(b-1)*t]^(1/(1-b))
Two per-cluster parameters: a (recession coefficient) and b (power-law exponent).
"""
import numpy as np
from scipy.optimize import minimize

USED_INPUTS = ["t", "Q_0"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {"a": {"init": None}, "b": {"init": None}}

def boussinesq(t, Q0, a, b):
    """Vectorized Boussinesq power-law recession."""
    if abs(b - 1.0) < 1e-6:
        return Q0 * np.exp(-a * t)
    else:
        inner = np.power(Q0, 1.0 - b) + a * (b - 1.0) * t
        inner = np.maximum(inner, 1e-30)
        return np.power(inner, 1.0 / (1.0 - b))

def fit(X_fit, y_fit):
    """Fit per-cluster parameters a and b from one cluster's data."""
    t_vals = X_fit[:, 0]
    Q0_vals = X_fit[:, 1]
    Qt_vals = y_fit
    
    # Use log-space loss for robustness
    def log_loss(params):
        a, b = params
        if a <= 0 or b <= 0.5 or b > 3.0:
            return 1e20
        pred = boussinesq(t_vals, Q0_vals, a, b)
        pred = np.maximum(pred, 1e-10)
        return np.sum((np.log(np.maximum(Qt_vals, 1e-10)) - np.log(pred))**2)
    
    best_loss = np.inf
    best_params = (0.01, 1.5)
    
    starting_points = [
        (0.01, 1.0), (0.001, 1.5), (0.01, 1.5), (0.001, 2.0),
        (0.1, 1.5), (0.005, 1.3), (0.005, 1.7), (0.05, 1.2)
    ]
    
    for a0, b0 in starting_points:
        try:
            res = minimize(log_loss, [a0, b0], method='Nelder-Mead',
                          options={'maxiter': 10000, 'xatol': 1e-8, 'fatol': 1e-8})
            if res.fun < best_loss:
                best_loss = res.fun
                best_params = (res.x[0], res.x[1])
        except Exception:
            pass
    
    a_hat, b_hat = best_params
    # Sanity check
    if a_hat <= 0 or b_hat <= 0.5 or b_hat > 3.0:
        a_hat, b_hat = 0.01, 1.5
    
    return {"a": float(a_hat), "b": float(b_hat)}

def predict(X, a, b):
    """Predict Q_t using the Boussinesq power-law recession model."""
    t = X[:, 0]
    Q0 = X[:, 1]
    return boussinesq(t, Q0, a, b)
