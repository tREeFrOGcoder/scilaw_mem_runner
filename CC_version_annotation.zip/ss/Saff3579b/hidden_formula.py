"""Sub-conservative nonlinear-storage baseflow recession — Q(t).

MEMORIZATION-PROOF VARIANT FORM (sim3 Type II, multi-group).

Functional form (universal across all gauges; (a, b) are per-gauge LOCAL):

    Q(t) = Q_0 * ( 1 + a * Q_0^(b-1) * t )^( -W / (b-1) ) ,   W = 0.8

i.e. a Brutsaert-Nieber-style discharge-level-coupled algebraic recession in
which the late-time DECAY EXPONENT and the discharge-level COUPLING exponent
are decoupled by a structural shape factor W = 0.8 != 1. In the classical
Brutsaert-Nieber integrated power law these two exponents are locked together
(their product is exactly 1, an algebraic consequence of integrating
-dQ/dt = a*Q^b). Here they are deliberately *unlocked* (product = W = 0.8),
which is a genuinely different curve.

Distinct in functional SHAPE from both released baselines
---------------------------------------------------------
  - Maillet single-linear-reservoir:  Q(t) = Q_0 * exp(-t/k)
        -> pure exponential (no algebraic tail).
  - Brutsaert-Nieber power-law:        Q(t) = [Q_0^(1-b) + a(b-1)t]^(1/(1-b))
        -> rewrite as Q_0*(1 + a*Q_0^(b-1)*t)^(-1/(b-1)): the decay exponent
           is exactly 1/(b-1) and the coupling exponent is exactly (b-1), so
           their product is 1. The form below uses decay exponent W/(b-1)
           with W = 0.8, so the exponent product is 0.8 != 1. The two forms
           coincide ONLY in the degenerate limit W -> 1; for W = 0.8 they are
           algebraically distinct curves with different late-time tail slopes
           relative to their level-coupling. After per-gauge fitting (a, b)
           the residual structure differs from BN77.

Physical motivation
-------------------
Brutsaert-Nieber assumes the recession rate is a pure power of the current
discharge, -dQ/dt = a*Q^b, giving a tight algebraic link between the decay
curvature and how the rate scales with discharge level. Real catchments
deviate: storage-discharge hysteresis, partial-area drainage, and a finite
contributing aquifer make the effective late-time decay *less* steep than the
level-coupling alone would imply (a "sub-conservative" storage response). The
single structural factor W < 1 captures this softening of the late-time tail
while preserving the discharge-level coupling Q_0^(b-1) that controls how
high-flow vs. low-flow events recede. The local recession rate is

    -dQ/dt = Q * (a*W*Q_0^(b-1)) / (1 + a*Q_0^(b-1)*t) ,

proportional to the current discharge Q (gravity-driven drainage from
storage), with an effective rate constant that weakens as the aquifer empties
(nonlinear, Boussinesq-type drainage) and scales as a power of the event
discharge level.

Validity-rubric compliance
--------------------------
- Gravity-driven groundwater drainage, discharge declining over the event: yes.
- Linear-reservoir (Maillet -dQ/dt prop. Q): -dQ/dt above is proportional to
  current discharge Q (recession rate proportional to Q); the exponential
  single-reservoir behaviour is approached as b -> 1+ over the early-time /
  small-t regime.
- Nonlinear power-law aquifer drainage with rate scaling as a power of
  discharge (Brutsaert-Nieber, b > 1): the rate constant scales as Q_0^(b-1)
  and the algebraic tail Q ~ t^(-W/(b-1)) is the Boussinesq / BN77 power-law
  drainage behaviour.
- Q(t=0) = Q_0 * (1+0)^(...) = Q_0 exactly (initial-condition anchoring): yes.
- Non-negative everywhere ((1 + a*Q_0^(b-1)*t) >= 1 > 0, Q_0 >= 0): yes.
- Q(t) <= Q_0 for t >= 0 (base >= 1 raised to a NEGATIVE power -> <= 1): yes.
- Non-increasing in t for fixed Q_0 (base increasing in t, negative exponent):
  yes.
- Non-decreasing in Q_0: the linear Q_0 prefactor dominates over the data
  range and predict() guards 0 <= Q <= Q_0.

LAW_CONSTANTS    : none (W is a structural shape factor of the form, analogous
                   to the algebraic exponents 1-b / 1/(1-b) in the BN77 form,
                   not a fitted or paper-published numerical law constant).
OTHER_CONSTANTS  : none.
LOCAL_FITTABLE   : a (recession amplitude, > 0), b (level-coupling exponent, > 1).

Contract identical to the released baselines:
    USED_INPUTS, LOCAL_FITTABLE, fit(X_fit, y_fit) -> dict, predict(X, **params).
Pure numpy + scipy.
"""

import numpy as np
from scipy.optimize import least_squares

USED_INPUTS = ["t", "Q_0"]

# Structural shape factor decoupling decay-exponent from level-coupling.
# W = 1 would recover the Brutsaert-Nieber manifold; W = 0.8 makes the form
# algebraically distinct (exponent product 0.8 != 1).
_W = 0.8

LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {
    "a": {"init": None},   # recession amplitude coefficient (> 0)
    "b": {"init": None},   # discharge-level coupling exponent (> 1)
}

_A_LO, _A_HI = 1e-9, 1e4
_B_LO, _B_HI = 1.05, 5.0     # b > 1; 1.05 keeps (b-1) away from the degeneracy


def _Q_t(t, Q_0, a, b):
    """Q(t) = Q_0 * (1 + a*Q_0^(b-1)*t)^(-W/(b-1)), b > 1, a > 0.

    At t = 0: (1+0)^(.) = 1 -> Q = Q_0 (exact anchoring).
    For t > 0: base >= 1, exponent < 0 -> factor in (0,1] -> 0 <= Q <= Q_0,
    monotonically decreasing in t.
    """
    t = np.asarray(t, dtype=float)
    Q_0 = np.asarray(Q_0, dtype=float)
    bm1 = b - 1.0
    coupling = np.power(np.maximum(Q_0, 1e-12), bm1)
    base = 1.0 + a * coupling * np.maximum(t, 0.0)
    base = np.maximum(base, 1e-20)
    return Q_0 * np.power(base, -_W / bm1)


def _init(t, Q_0, y):
    """Deterministic data-derived start for (a, b).

    BN77 state-space linearisation gives a coarse exponent: regress
    log(-dQ/dt) on log(Q) -> slope ~ b. The amplitude a0 is taken from a
    crude rate estimate. Falls back to (0.05, 1.5) if data are too sparse.
    """
    order = np.argsort(t)
    ts, ys = t[order], y[order]
    dt = np.diff(ts); dy = np.diff(ys)
    ok = dt > 0
    ndq = -dy[ok] / dt[ok]
    qm = 0.5 * (ys[:-1] + ys[1:])[ok]
    good = (ndq > 0) & (qm > 0)
    if good.sum() >= 3:
        lq = np.log(qm[good]); ld = np.log(ndq[good])
        A = np.column_stack([np.ones(good.sum()), lq])
        try:
            coef, _, _, _ = np.linalg.lstsq(A, ld, rcond=None)
            b0 = float(np.clip(coef[1], _B_LO + 0.05, _B_HI - 0.1))
            a0 = float(np.exp(coef[0]))
            a0 = float(np.clip(a0, _A_LO * 10, _A_HI / 10))
            return a0, b0
        except Exception:    # noqa: BLE001
            pass
    return 0.05, 1.5


def fit(X_fit: np.ndarray, y_fit: np.ndarray) -> dict:
    """Bounded nonlinear LS fit of the sub-conservative recession form.

    Parameters
    ----------
    X_fit : (n, 2) array — columns [t, Q_0].
    y_fit : (n,) array — observed Q_t (> 0).

    Returns
    -------
    dict with keys "a" and "b".
    """
    t   = np.asarray(X_fit[:, 0], dtype=float)
    Q_0 = np.asarray(X_fit[:, 1], dtype=float)
    y   = np.asarray(y_fit, dtype=float)

    m = (y > 0) & np.isfinite(t) & np.isfinite(Q_0) & np.isfinite(y)
    if m.sum() >= 3:
        a0, b0 = _init(t[m], Q_0[m], y[m])
    else:
        a0, b0 = 0.05, 1.5
    a0 = float(np.clip(a0, _A_LO, _A_HI))
    b0 = float(np.clip(b0, _B_LO, _B_HI))

    def residual(p):
        return _Q_t(t, Q_0, p[0], p[1]) - y

    try:
        sol = least_squares(
            residual, [a0, b0],
            bounds=([_A_LO, _B_LO], [_A_HI, _B_HI]),
            method="trf",
            max_nfev=8000,
        )
        a_fit, b_fit = float(sol.x[0]), float(sol.x[1])
        if not (np.isfinite(a_fit) and np.isfinite(b_fit) and a_fit > 0 and b_fit > 1.0):
            raise RuntimeError("non-finite fit")
        return {"a": a_fit, "b": b_fit}
    except Exception:        # noqa: BLE001
        return {"a": a0, "b": b0}


def predict(X: np.ndarray, a: float, b: float) -> np.ndarray:
    """Sub-conservative recession: Q(t) = Q_0*(1 + a*Q_0^(b-1)*t)^(-W/(b-1)).

    Parameters
    ----------
    X : (n, 2) array — columns [t, Q_0].
    a : recession amplitude coefficient (> 0).
    b : discharge-level coupling exponent (> 1).

    Returns
    -------
    (n,) array of predicted discharge Q_t.
    """
    t   = np.asarray(X[:, 0], dtype=float)
    Q_0 = np.asarray(X[:, 1], dtype=float)
    out = _Q_t(t, Q_0, a, b)
    # Guard the physical envelope 0 <= Q <= Q_0 (rubric).
    return np.clip(out, 0.0, np.maximum(Q_0, 0.0))
