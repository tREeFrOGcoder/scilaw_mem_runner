"""Exponential decay model for battery capacity loss over cycles."""
import numpy as np

USED_INPUTS = ["cycle_index"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {}

def predict(X):
    k = X[:, 0]
    return 1.978 * np.exp(-0.012 * k)
