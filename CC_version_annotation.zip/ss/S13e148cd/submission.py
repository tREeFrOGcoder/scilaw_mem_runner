"""Linear partitioning law in log Kow and log10(foc)."""
import numpy as np

USED_INPUTS = ["log_Kow", "foc"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {}

def predict(X):
    x = X[:, 0]
    f = X[:, 1]
    return -0.67535263 + 0.51394051 * x + 0.49882890 * np.log10(f)
