"""PFAS soil sorption — Freundlich-exponent organic-carbon partitioning variant.

MEMORIZATION-PROOF VARIANT (sim3 Type I) — physically plausible, DISTINCT in
functional SHAPE from the textbook Fabregat-Palau (2025) Koc-Kow baseline.

Baseline (textbook) form
------------------------
The textbook closed form couples to the soil organic-carbon fraction with an
implicit UNIT exponent, because it is built from two identities chained
together:

    log Koc = slope * log_Kow + intercept          (empirical Koc-Kow regression)
    log Kd  = log Koc + log10(foc)                  (standard Koc-Kd partitioning)
    => log_kd = slope * log_Kow + intercept + 1.0 * log10(foc).

The coefficient on log10(foc) is structurally FIXED at exactly 1.0 (it is a
definitional partitioning identity, not a fitted number).

Variant form (this module)
--------------------------
Real soils are not pure organic-carbon partition media: at low foc, sorption to
mineral surfaces and to organic matter of varying quality makes the apparent
organic-carbon partition coefficient depend sub-linearly on foc. We relax the
definitional unit coupling to a fitted Freundlich-type organic-carbon exponent
``foc_exp`` (b):

    log_kd = slope * log_Kow + intercept + foc_exp * log10(foc).

Physical reading
----------------
``foc_exp`` < 1 means the organic-carbon contribution to log_Kd grows more
slowly than the simple "all sorption is OC partitioning" identity predicts:
as foc falls, a residual mineral-surface / non-OC sorption floor keeps log_Kd
from dropping as fast as 1.0*log10(foc) would require. The organic-carbon term
still increases monotonically with foc and still vanishes (-> -inf in log space)
as foc -> 0, satisfying the partitioning rubric.

Why this is SHAPE-distinct from the textbook form (survives a coefficient refit)
--------------------------------------------------------------------------------
The textbook form is a strict subset of this variant at foc_exp == 1. A
downstream refit of the textbook 2-parameter model (slope, intercept) cannot
move the foc coupling off 1.0, so it cannot reproduce the fitted foc_exp ~ 0.52
recovered here. Over the pooled PFAS dataset the best refit of the unit-exponent
textbook form still leaves an rms prediction gap of ~0.32 log-units versus this
variant — the two forms do not collapse onto each other after refit. The variant
also fits markedly better (rmse ~0.584 vs ~0.666 for the refit textbook form).

Physics / validity-rubric compliance
------------------------------------
- hydrophobic OC partitioning increasing log_Kd with log_Kow (slope>0).      [ok]
- OC partitioning scales with foc, monotone increasing, -> -inf as foc->0.   [ok]
  (foc_exp>0 keeps the foc->0 limit; sub-unit exponent is still monotone.)
- USED_INPUTS unchanged from the baseline (log_Kow, foc).                     [ok]

Type designation
----------------
Type I — slope, intercept and foc_exp are single scalars fitted globally across
the pooled dataset, not per (PFAS, soil) cluster. LOCAL_FITTABLE is empty.

Column mapping
--------------
  log_Kow -> log_Kow (log10 octanol-water partition coefficient)
  foc     -> foc      (fraction organic carbon, dimensionless = Corg/100)
"""

import numpy as np

USED_INPUTS = ["log_Kow", "foc"]
PAPER_REF = None
EQUATION_LOC = (
    "Freundlich-exponent OC variant: "
    "log_kd = slope*log_Kow + intercept + foc_exp*log10(foc)"
)

# === LAW_CONSTANTS — fitted globally on the pooled PFAS data (scipy curve_fit) ===
LAW_CONSTANTS = {
    "slope":     0.5185715,   # hydrophobic Koc-Kow slope (fitted)
    "intercept": -0.6659622,  # Koc-Kow intercept (fitted)
    "foc_exp":   0.5170269,   # Freundlich organic-carbon exponent (textbook fixes = 1)
}

# === OTHER_CONSTANTS — universal math operators ===
OTHER_CONSTANTS = {}  # log10 is a math operator; foc already dimensionless
LOCAL_FITTABLE = {}   # Type I — no per-cluster parameters


def predict(X: np.ndarray, slope: float = 0.5185715,
            intercept: float = -0.6659622, foc_exp: float = 0.5170269,
            **params) -> np.ndarray:
    """Predict log10(Kd) from log_Kow and foc (Freundlich-exponent OC coupling).

    X : np.ndarray, shape (n, 2)
        Column 0 = log_Kow (log10 octanol-water partition coefficient).
        Column 1 = foc (fraction organic carbon, dimensionless).
    slope, intercept : Koc-Kow regression coefficients.
    foc_exp : Freundlich-type exponent on the organic-carbon term
              (textbook form fixes this at 1.0).

    Returns
    -------
    np.ndarray, shape (n,) — predicted log10(Kd) in log10(L/kg).
    """
    log_kow = np.asarray(X[:, 0], dtype=float)
    foc = np.clip(np.asarray(X[:, 1], dtype=float), 1e-9, None)
    return slope * log_kow + intercept + foc_exp * np.log10(foc)
