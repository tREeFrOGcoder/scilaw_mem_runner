"""Shared Oren-style logarithmic VPD response: canopy conductance is affine in ln(vpd), with a per-cluster conductance at 1 kPa and a per-cluster logarithmic sensitivity."""
import numpy as np

USED_INPUTS = ["vpd"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {
    "G_ref": {"init": None},
    "m": {"init": None},
}

def fit(X_fit, y_fit):
    D = np.asarray(X_fit[:, 0], dtype=float)
    y = np.asarray(y_fit, dtype=float)
    mask = np.isfinite(D) & np.isfinite(y) & (D > 0.0)
    if np.sum(mask) >= 2:
        z = np.log(D[mask])
        A = np.column_stack((np.ones_like(z), z))
        try:
            coef, _, _, _ = np.linalg.lstsq(A, y[mask], rcond=None)
            G_ref = float(coef[0])
            m = float(-coef[1])
            if np.isfinite(G_ref) and np.isfinite(m):
                return {"G_ref": G_ref, "m": m}
        except Exception:
            pass

    yy = y[np.isfinite(y)]
    G_ref = float(np.mean(yy)) if yy.size else 0.0
    return {"G_ref": G_ref, "m": 0.0}

def predict(X, G_ref, m):
    D = np.asarray(X[:, 0], dtype=float)
    D = np.maximum(D, 1e-12)
    return G_ref - m * np.log(D)
