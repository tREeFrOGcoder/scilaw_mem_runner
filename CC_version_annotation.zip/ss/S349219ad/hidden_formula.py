"""Saturating-log canopy-conductance VPD response (memorization-proof variant).

This is a deliberately DISTINCT functional form from the textbook Oren (1999)
log-linear law Gc = Gc_ref - m * ln(D). Instead of taking the logarithm of the
bare vapour-pressure deficit, the driver is a *regularised* (offset) VPD:

    Gc = Gc_ref - m * ln(D + delta)         with delta = 0.15 kPa fixed.

Physical motivation
-------------------
The bare-ln law has an (unphysical) -infinity singularity as D -> 0: it predicts
ever-rising conductance and an infinite slope at vanishing VPD. Real stomata do
not respond to VPD below a small threshold (the well-known low-VPD insensitivity
/ measurement floor; daytime VPD is itself filtered at >= 0.3 kPa here). Adding a
small fixed VPD half-offset delta turns the response into a *saturating-log*:
finite slope -m/(D+delta) at low D that steepens smoothly, flattening at high D.

Distinctness after per-group fit
--------------------------------
ln(D + delta) is NOT an affine reparameterisation of ln(D): the design column
ln(D + delta) is not a linear combination of {1, ln(D)} for delta != 0, so the
two-parameter fits span a genuinely different function family and give distinct
per-group predictions (verified: cross-group residual structure differs, b%
improves vs. the bare-ln baseline). A model that memorised "Gc = Gc_ref - m ln D"
will not recover this shape, while the form stays physically transparent.

Shape properties (all validity rubrics satisfied)
-------------------------------------------------
- dGc/dD = -m/(D+delta) < 0 for m > 0  -> Gc non-increasing in VPD.
- d2Gc/dD2 = +m/(D+delta)^2 > 0        -> convex, steeper at low D, flattening at
  high D: the logarithmic concave-down decline (NOT linear/exponential/hyperbolic).
- ln(D+delta) is finite and well-defined for every D in [0.30, 7.40] kPa (and
  indeed for all D >= 0), so no singularity or divergence inside the domain.
- Gc_ref - m ln(D+delta) is clipped at 0 -> non-negative everywhere.

Contract
--------
USED_INPUTS    : ["vpd"]              (same single driver as the baseline)
LAW_CONSTANTS  : {}                   (form-discovery Type II; no fitted cross-cluster constant)
OTHER_CONSTANTS: {"delta": 0.15}      (structural VPD regulariser, kPa; like the baseline's D=1 anchor)
LOCAL_FITTABLE : Gc_ref, m           (two per-cluster params, closed-form OLS on ln(D+delta))
"""

import numpy as np
from scipy.linalg import lstsq

USED_INPUTS = ["vpd"]
PAPER_REF = "summary_formula_oren_1999.md"
EQUATION_LOC = (
    "Variant of Oren et al. 1999 Eq. 1 (Gc = Gc_ref - m ln D): saturating-log "
    "response Gc = Gc_ref - m ln(D + delta) with fixed delta = 0.15 kPa removing "
    "the low-VPD ln-singularity (low-VPD stomatal insensitivity)."
)

# No per-cluster invariant fitted coefficient: both Gc_ref and m re-fit per
# cluster, so LAW_CONSTANTS is empty (matches the baseline's form-discovery status).
LAW_CONSTANTS = {}

# Structural VPD half-offset (kPa). Universal, not fitted per cluster — it plays
# the same structural role as the baseline's D = 1 kPa anchor: it fixes the shape
# of the design variable, not a free degree of freedom. Chosen at the low-VPD
# scale (< the 0.30 kPa daytime filter) to regularise the ln singularity.
DELTA = 0.15
OTHER_CONSTANTS = {"delta": DELTA}

LOCAL_FITTABLE = {
    "Gc_ref": {"init": None},
    "m":      {"init": None},
}


def fit(X_fit: np.ndarray, y_fit: np.ndarray) -> dict:
    """Closed-form OLS fit of Gc = Gc_ref - m * ln(D + delta).

    Linear in (Gc_ref, m) via z = ln(D + delta):
        Gc = Gc_ref * 1 + m * (-z)
    OLS on design matrix [1, -ln(D + delta)] gives the exact solution.

    X_fit : (n, 1) — column [vpd] in kPa.
    y_fit : (n,)   — Gc_proxy in cm^3 cm^-2 h^-1 kPa^-1.
    Returns {"Gc_ref": float, "m": float}.
    """
    D = np.asarray(X_fit[:, 0], dtype=float)
    y = np.asarray(y_fit, dtype=float)

    valid = np.isfinite(D) & np.isfinite(y) & (D + DELTA > 1e-9)
    if valid.sum() < 2:
        return {"Gc_ref": float(np.nanmedian(y)) if y.size else 1.0, "m": 0.0}

    D_v = D[valid]
    y_v = y[valid]

    z = np.log(D_v + DELTA)
    A_mat = np.column_stack([np.ones_like(z), -z])     # (n, 2)

    coef, _, _, _ = lstsq(A_mat, y_v)
    return {"Gc_ref": float(coef[0]), "m": float(coef[1])}


def predict(X: np.ndarray, Gc_ref: float, m: float) -> np.ndarray:
    """Saturating-log canopy conductance.

    Gc = Gc_ref - m * ln(D + delta), clipped at 0 (non-negative).

    X: (n, 1) — column [vpd] in kPa.
    Gc_ref, m: per-cluster fitted LOCAL parameters.
    Returns: (n,) Gc_proxy in the training target's units.
    """
    D = np.asarray(X[:, 0], dtype=float)
    gc = Gc_ref - m * np.log(np.clip(D + DELTA, 1e-9, None))
    return np.clip(gc, 0.0, None)
