"""Cubic polynomial parameterization of the electric-to-dipole Sachs form factor ratio G_E/G_D."""
import numpy as np

USED_INPUTS = ["Q2_GeV2"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {}

def predict(X):
    x = X[:, 0]
    return 1.0 - 0.051648 * x - 0.021996 * (x**2) + 0.001721 * (x**3)
