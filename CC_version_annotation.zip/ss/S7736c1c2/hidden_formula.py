"""Hydraulic-corrected allometric form for whole-plant leaf area (a_lf).

MEMORIZATION-PROOF VARIANT (sim3 Type II, multi-group).

This is NOT the textbook pipe-model law (Shinozaki 1964: A_L = k_p * A_S, a
strict linear proportionality with no height term) nor the interspecific 3/4-
power law (Niklas & Enquist 2001: A_L = k * A_S^0.762, a single fixed exponent
with no height term). It is a distinct two-input multiplicative form that
couples a per-group sapwood-area power law to a hydraulic-path (height)
dilution factor:

    A_L = c * A_S^p * H^(-gamma)

with c, p, gamma all LOCAL_FITTABLE per group (gamma constrained >= 0).

Physical motivation:
  - A_S^p : foliage supported by conductive sapwood. The exponent p is local
    (not fixed at 1 or 0.762): it absorbs species-specific deviations between
    the pure pipe-model (p=1) and metabolic-scaling (p~3/4) limits caused by
    tapering, heartwood formation and bark fraction.
  - H^(-gamma) : Whitehead-style hydraulic extension. As the conductive path
    length (~ tree height H) grows, hydraulic resistance rises, so the
    leaf-area-to-sapwood-area ratio A_L/A_S falls. gamma >= 0 is enforced so
    that predicted leaf area is non-increasing in height at fixed sapwood area
    (rubric: A_L/A_S inversely related to path length).

The form is DISTINCT IN FUNCTIONAL SHAPE from either baseline after per-group
fitting: it carries a second predictor (H) that neither baseline uses and a
freely-fitted sapwood exponent. It still passes through the origin in A_S,
is non-negative, and is monotone non-decreasing in A_S.

Type II — c, p, gamma are LOCAL_FITTABLE per group; the FORM is universal.

Column mapping (CSV):
  A_S -> a_ssbh : sapwood cross-sectional area at breast height (m2).
  H   -> h_t    : total plant height (m).
  A_L -> a_lf   : whole-plant leaf area (m2).
"""

import numpy as np

USED_INPUTS = ["a_ssbh", "h_t"]
PAPER_REF = "summary_supporting_lehnebach_2018.md"
EQUATION_LOC = (
    "Hydraulic-corrected allometry: A_L = c * A_S^p * H^(-gamma). Couples a "
    "local sapwood-area power law (Shinozaki pipe-model / Niklas-Enquist "
    "scaling limits) to a Whitehead hydraulic-path height dilution; all three "
    "parameters fitted per group, gamma constrained non-negative."
)

LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {
    "c": {"init": None},      # per-group normalization (closed-form, log-space)
    "p": {"init": None},      # per-group sapwood-area exponent (closed-form)
    "gamma": {"init": None},  # per-group height-dilution exponent (>= 0)
}

# Grid over the (non-negative) hydraulic exponent gamma; c and p are solved in
# closed form by log-space OLS conditional on gamma.
_GAMMA_GRID = np.linspace(0.0, 1.5, 31)


def fit(X_fit: np.ndarray, y_fit: np.ndarray) -> dict:
    """Fit c, p, gamma per group.

    In log10 space the model is linear:
        log10(A_L) = log10(c) + p*log10(A_S) - gamma*log10(H).
    gamma is constrained to be non-negative (hydraulic dilution), so we grid
    over gamma >= 0 and solve (log c, p) by OLS for each, keeping the least-
    squares-best gamma. Robust to thin / degenerate groups.
    """
    a_ssbh = np.asarray(X_fit[:, 0], dtype=float)
    h_t = np.asarray(X_fit[:, 1], dtype=float)
    y = np.asarray(y_fit, dtype=float)

    mask = (a_ssbh > 0) & (h_t > 0) & (y > 0) & \
        np.isfinite(a_ssbh) & np.isfinite(h_t) & np.isfinite(y)
    if mask.sum() < 1:
        return {"c": 1.0, "p": 1.0, "gamma": 0.0}

    lx = np.log10(a_ssbh[mask])
    lh = np.log10(h_t[mask])
    ly = np.log10(y[mask])

    # Too few points to fit a slope -> fall back to pure proportionality.
    if mask.sum() < 3 or np.ptp(lx) <= 0:
        log_c = float(np.mean(ly - lx))
        c = 10.0 ** log_c
        if not np.isfinite(c) or c <= 0:
            c = 1.0
        return {"c": c, "p": 1.0, "gamma": 0.0}

    A = np.column_stack([np.ones_like(lx), lx])
    best = None
    for gamma in _GAMMA_GRID:
        rhs = ly + gamma * lh           # absorb the -gamma*lh term to the LHS
        coef, *_ = np.linalg.lstsq(A, rhs, rcond=None)
        pred = A @ coef - gamma * lh
        sse = float(np.sum((pred - ly) ** 2))
        if best is None or sse < best[0]:
            best = (sse, float(coef[0]), float(coef[1]), float(gamma))

    _, log_c, p, gamma = best
    c = 10.0 ** log_c

    # Guard rails: keep parameters physically sane and finite.
    if not np.isfinite(c) or c <= 0:
        c = 1.0
    if not np.isfinite(p) or p <= 0:
        p = 1.0
    if not np.isfinite(gamma) or gamma < 0:
        gamma = 0.0
    return {"c": float(c), "p": float(p), "gamma": float(gamma)}


def predict(X: np.ndarray, c: float, p: float, gamma: float) -> np.ndarray:
    """A_L = c * A_S^p * H^(-gamma).

    X: (n, 2) — columns [a_ssbh, h_t].
    c     : per-group normalization (LOCAL_FITTABLE, > 0).
    p     : per-group sapwood-area exponent (LOCAL_FITTABLE, > 0).
    gamma : per-group height-dilution exponent (LOCAL_FITTABLE, >= 0).

    Non-negative; passes through the origin in a_ssbh; non-decreasing in
    a_ssbh; non-increasing in h_t.
    """
    a_ssbh = np.clip(np.asarray(X[:, 0], dtype=float), 0.0, None)
    h_t = np.clip(np.asarray(X[:, 1], dtype=float), 1e-9, None)
    return c * np.power(a_ssbh, p) * np.power(h_t, -gamma)
