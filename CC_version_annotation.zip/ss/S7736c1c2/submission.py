"""
Woody-plant allometry: leaf area scales with sapwood area and height per WBE theory.
a_lf = c_i * a_ssbh^(5/4) * h_t^(-3/4)
where c_i is a per-cluster constant and the exponents follow West-Brown-Enquist
allometric scaling with the constraint beta = alpha - 2.
"""
import numpy as np

USED_INPUTS = ["a_ssbh", "h_t"]
LAW_CONSTANTS = {"alpha": 1.25}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {"c": {"init": None}}

def fit(X_fit, y_fit):
    a = X_fit[:, 0]
    h = X_fit[:, 1]
    alpha = 1.25
    beta = alpha - 2.0  # = -0.75
    c_vals = y_fit / (a**alpha * h**beta)
    c = float(np.mean(c_vals))
    return {"c": c}

def predict(X, c):
    alpha = 1.25
    beta = alpha - 2.0
    return c * X[:, 0]**alpha * X[:, 1]**beta
