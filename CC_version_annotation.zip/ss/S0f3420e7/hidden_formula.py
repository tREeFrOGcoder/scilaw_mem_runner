"""VARIANT capacity-fade law — STRETCHED power-law SEI fade (memorization-proof).

The two textbook capacity-fade forms a memorizer would recognise for this
NASA PCoE 18650 task are:

  * Pinson-Bazant (2013): diffusion-limited sqrt-time SEI growth,
        Q(k) = Q0 - alpha * sqrt(k)            (fade exponent fixed at 1/2),
  * He et al. (2011): phenomenological double-exponential,
        Q(k) = A * exp(B*k) + C * exp(D*k).

This variant keeps the single-loss-channel SEI picture of Pinson-Bazant
(one irreversible capacity-loss term that grows monotonically with cycle
count) but RELAXES the parabolic exponent from the textbook value 1/2 to a
FREE stretched exponent P:

        Q(k) = Q0 - ALPHA * k**P .

Why this is a genuine SHAPE change (survives a downstream refit)
---------------------------------------------------------------
The sqrt-time law is the single special case P = 1/2 of this family, and
the double-exponential is a different (sum-of-exponentials) family entirely.
A pure coefficient refit of the textbook sqrt form cannot reach this curve
because the curvature is controlled by the EXPONENT, not by a coefficient:
re-optimising (Q0, ALPHA, P) on the real pooled data drives P to ~0.80, far
from 1/2, so the fitted curve bends LESS early and MORE late than any sqrt
form. Because P is identified away from 1/2 by the data, the shape stays
distinct from the textbook law after re-optimisation; it is not a sqrt curve
in disguise, nor a sum of exponentials.

Physical interpretation
-----------------------
A pure-diffusion-limited SEI film grows as sqrt(t) (exponent 1/2). When the
loss is co-limited by the interfacial side-reaction kinetics rather than by
solvent diffusion alone, the effective growth law is a stretched power-law
k**P with P > 1/2 (the parabolic-to-linear crossover regime of Wagner/
Tammann oxide-growth theory generalised to SEI). A single fitted exponent P
absorbs this mixed diffusion/reaction limitation with one extra shape
parameter and no extra channels.

Validity (metadata rubrics) — satisfied analytically
----------------------------------------------------
- Irreversible SEI/side-reaction loss: the single -ALPHA*k**P term is a
  monotonically growing irreversible capacity loss from cyclable-lithium
  consumption (ALPHA > 0, P > 0).
- Defined for every positive cycle_index: k**P is real and finite for all
  k > 0 (the whole task domain k >= 1).
- Stays positive over the cycling domain: over k in [1, 168] the loss
  ALPHA*k**P stays well below Q0 (Q(168) ~ 1.26 Ah > 0).
- Does not exceed fresh-cell capacity: Q is maximal at the smallest cycle
  and Q(k) <= Q0 for all k >= 1, with Q0 ~ 1.95 Ah the fresh-cell value.
- Non-increasing in cycle_index: dQ/dk = -ALPHA*P*k**(P-1) < 0 everywhere
  on the domain, so capacity is strictly decreasing.

LAW_CONSTANTS — fit by nonlinear least squares (rmse / linear space) on the
real pooled NASA PCoE data (train + test). The pipeline refits all three via
curve_fit; the finite optimum keeps P ~ 0.80 (not 1/2), so the stretched
shape persists and stays distinct from the textbook sqrt and double-exp laws.
"""

import numpy as np

USED_INPUTS = ["cycle_index"]
PAPER_REF = "summary_formula_pinson_2013.md"
EQUATION_LOC = (
    "Variant stretched power-law SEI fade: Q(k) = Q0 - ALPHA * k**P, a "
    "single-channel irreversible capacity-loss term with a FREE growth "
    "exponent P (generalising Pinson-Bazant's fixed sqrt exponent 1/2). "
    "Fitted P ~ 0.80 from pooled NASA PCoE nonlinear LS."
)

LAW_CONSTANTS = {
    "Q0":    1.952475,   # Ah, fresh-cell capacity intercept
    "ALPHA": 0.011445,   # Ah / cycle**P, stretched fade rate
    "P":     0.799633,   # dimensionless stretched-fade exponent (textbook = 1/2)
}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {}


def predict(X: np.ndarray, Q0: float = 1.952475,
            ALPHA: float = 0.011445, P: float = 0.799633) -> np.ndarray:
    """Q(k) = Q0 - ALPHA * k**P  (stretched power-law SEI capacity fade)."""
    k = np.asarray(X[:, 0], dtype=float)
    return Q0 - ALPHA * np.power(np.maximum(k, 0.0), P)
