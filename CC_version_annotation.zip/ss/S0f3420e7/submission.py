"""Power law degradation model for lithium-ion battery capacity fade."""
import numpy as np

USED_INPUTS = ["cycle_index"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {}

def predict(X):
    k = X[:, 0]
    # Q(k) = Q0 - alpha * k^n
    # Fitted parameters from experimental data
    Q0 = 1.942
    alpha = 0.0143
    n = 0.75
    return Q0 - alpha * k**n
