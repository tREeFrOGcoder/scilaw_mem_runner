"""Decoupled-height allometric model for tropical tree AGB (sim3 Type I variant).

Memorization-proof variant of the Chave (2014) pantropical power law. The
textbook form lumps wood density, basal area and height into a single composite
(rho * D^2 * H) raised to one shared exponent alpha:

    AGB = c * (rho * D^2 * H)^alpha          (textbook / baseline)

This variant instead keeps the structural geometric scaling explicit -- wood
density enters linearly (mass per unit volume) and trunk diameter enters as the
basal-area term D^2 (cross-sectional area ~ D^2) -- while letting tree height
carry its OWN exponent:

    AGB = c * rho * D^2 * H^beta             (this variant)

Physical motivation: real trunks are not perfect cylinders. As trees grow
taller their stems taper and crown architecture changes, so the marginal AGB
contribution of height is sub-linear (beta < 1) rather than scaling identically
to the rho*D^2 product. Decoupling H from the (rho, D) structural factors is the
shape change: in the baseline all three drivers are forced to share a single
exponent alpha, whereas here the height exponent beta is independent. A refit of
the baseline (single alpha on the composite) cannot reproduce this decoupled
form, so the two stay functionally distinct after re-optimization.

Validity:
    - height dependence: H^beta (sub-linear, beta ~ 0.92)
    - diameter dependence: D^2 (basal-area / cross-section)
    - wood-density dependence: linear rho factor
    - AGB >= 0 for all physical (rho, D, H >= 0)
    - AGB -> 0 as D -> 0 or H -> 0

Column mapping (released CSV -> formula):
    agb_kg        -> AGB  (output)
    wood_density  -> rho  (g/cm^3)
    diameter_cm   -> D     (cm)
    height_m      -> H     (m)
"""

import numpy as np

USED_INPUTS = ["wood_density", "diameter_cm", "height_m"]

# === LAW_CONSTANTS — fitted to data (scipy curve_fit, log10 space) ===
LAW_CONSTANTS = {
    "c":    0.06425342,   # leading coefficient
    "beta": 0.92005678,   # independent height exponent (sub-linear taper)
}
# === OTHER_CONSTANTS — universal physics factors ===
OTHER_CONSTANTS = {}   # none needed
LOCAL_FITTABLE  = {}   # Type I — no per-cluster parameters


def predict(X: np.ndarray, c: float, beta: float) -> np.ndarray:
    """AGB (kg) per tropical tree: c * rho * D^2 * H^beta.

    X: (n, 3) — columns wood_density (rho, g/cm^3), diameter_cm (D, cm),
                height_m (H, m).
    """
    rho = np.asarray(X[:, 0], dtype=float)
    D   = np.asarray(X[:, 1], dtype=float)
    H   = np.asarray(X[:, 2], dtype=float)
    return c * rho * D**2 * np.power(H, beta)
