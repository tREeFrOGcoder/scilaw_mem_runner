"""Model for estimating aboveground biomass (AGB) of tropical trees."""
import numpy as np

USED_INPUTS = ["wood_density", "diameter_cm", "height_m"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {}

def predict(X):
    rho = X[:, 0]  # wood_density
    D = X[:, 1]    # diameter_cm
    H = X[:, 2]    # height_m
    return (rho * D**2 * H) / 1000  # AGB in kg
