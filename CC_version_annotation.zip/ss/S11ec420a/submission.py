"""STIRPAT-style methane emissions: multiplicative power law in GDP per capita, population, and urbanization."""
import numpy as np

USED_INPUTS = ["GDP", "TP", "UR"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {}

def predict(X):
    GDP = X[:, 0]
    TP = X[:, 1]
    UR = X[:, 2]
    return 2.3738940564 * (GDP ** 0.1417796295) * (TP ** 0.9931801119) * (UR ** 0.4430493299)
