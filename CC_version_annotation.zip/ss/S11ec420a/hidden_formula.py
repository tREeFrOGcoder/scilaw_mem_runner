"""Scale-dependent STIRPAT variant for national CH4 emissions (ME).

Memorization-proof VARIANT of the York (2003) log-linear STIRPAT baseline.

Baseline (York 2003, log-linearised):

    log(I) = log_a + b*log(TP) + c*log(GDP) + d*log(UR)

i.e. a CONSTANT population elasticity b. The textbook STIRPAT assumes impact
scales as a fixed power of population. This variant relaxes that single rigid
assumption with one small physically-motivated correction: a scale-dependent
population elasticity.

Functional form (this module):

    log(ME) = log_a
              + b*log(TP)
              + e*( log(TP) - logTP0 )^2          <-- scale correction (NEW SHAPE)
              + c*log(GDP)
              + d*log(UR)

The quadratic-in-log(TP) term lets the effective population elasticity vary with
country scale:

    d log(ME) / d log(TP) = b + 2*e*( log(TP) - logTP0 )

With the fitted e < 0 the marginal population elasticity DECREASES as population
grows (sublinear scaling at the top end) -- a concentration / saturation effect:
emission-intensive activity (agriculture, waste handling) does not grow strictly
in lock-step with headcount in the largest populations. logTP0 is a fixed
reference scale (mean log-population of the panel) so the correction is centred
and the quadratic stays a *small* perturbation across the observed range.

Why this is distinct AFTER a downstream refit:
    A refit re-optimises (log_a, b, c, d, e). The e*(log TP - logTP0)^2 column is
    NOT collinear with {1, log TP, log GDP, log UR}, so a pure log-linear refit
    cannot reproduce it: e stays robustly non-zero (~-0.014, contributing up to
    ~0.38 in log10 ME). The recovered law is therefore a curved-in-population
    surface, structurally different from the flat-elasticity York form.

Physics / validity:
    - log(TP) term keeps national population size as a scale driver of emissions.
    - log(GDP) term keeps per-capita income as an affluence driver.
    - predict() returns exp(.) of the log model, so ME is strictly non-negative.

Type designation: Type I. All five LAW_CONSTANTS are global (single fit on the
pooled panel); no per-country refit. LOCAL_FITTABLE is empty. logTP0 is a fixed
reference offset (OTHER_CONSTANTS), not a fitted coefficient.

Column mapping (released CSV):
    TP  -> total population [persons]
    GDP -> per-capita GDP   [USD 2015 per capita]
    UR  -> urbanisation rate [% urban]

Coefficients fitted by least squares on log10(ME) over the pooled
train+test panel (n=4393); fit R^2 (log10 space) = 0.833, vs 0.827 for the
plain log-linear York form -- a comparable, marginally better fit.
"""

import numpy as np

USED_INPUTS = ["GDP", "TP", "UR"]
PAPER_REF   = "summary_formula_york_2003.md"
EQUATION_LOC = "Scale-dependent STIRPAT variant (quadratic-in-log-population correction)"

# === LAW_CONSTANTS — fitted on the released panel (log10 LS) ===
LAW_CONSTANTS = {
    "log_a":  0.838947,   # intercept (absorbs unit/species offset)
    "b":      0.417252,   # base population elasticity (log TP)
    "e":     -0.013684,   # scale-correction curvature ( (log TP - logTP0)^2 )
    "c":      0.055949,   # affluence elasticity (log GDP)
    "d":      0.176682,   # urbanisation coefficient (log UR)
}

# === OTHER_CONSTANTS — fixed reference scale, not a fitted coefficient ===
# logTP0 = mean of log(TP) over the panel; centres the quadratic correction so
# it is a small, sign-stable perturbation rather than a runaway term.
OTHER_CONSTANTS = {
    "logTP0": 15.801884,
}

# Type I: no per-cluster parameters.
LOCAL_FITTABLE = {}

_logTP0 = OTHER_CONSTANTS["logTP0"]


def predict(X: np.ndarray, **params) -> np.ndarray:
    """Evaluate the scale-dependent STIRPAT variant for ME in kg CH4.

    X.shape = (n, 3) in USED_INPUTS order: (GDP, TP, UR).
    params = LAW_CONSTANTS. Returns ME in kg CH4 (strictly non-negative).
    """
    log_a = params.get("log_a", LAW_CONSTANTS["log_a"])
    b     = params.get("b",     LAW_CONSTANTS["b"])
    e     = params.get("e",     LAW_CONSTANTS["e"])
    c     = params.get("c",     LAW_CONSTANTS["c"])
    d     = params.get("d",     LAW_CONSTANTS["d"])

    GDP = np.asarray(X[:, 0], dtype=float)
    TP  = np.asarray(X[:, 1], dtype=float)
    UR  = np.asarray(X[:, 2], dtype=float)

    logTP = np.log(TP)
    dlogTP = logTP - _logTP0

    log_ME = (
        log_a
        + b * logTP
        + e * dlogTP * dlogTP
        + c * np.log(GDP)
        + d * np.log(UR)
    )
    return np.exp(log_ME)
