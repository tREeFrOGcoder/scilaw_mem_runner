"""Mass-metallicity relation: logistic saturation form oh = p0 + p1 / (1 + exp(-p2 * (log_Mstar - p3)))"""
import numpy as np

USED_INPUTS = ["log_Mstar"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {}

def predict(X):
    x = X[:, 0]
    # Logistic/sigmoid mass-metallicity relation
    # Parameters fitted from experimental data
    p0 = 8.31482896      # asymptotic low-mass metallicity
    p1 = 0.80350710      # amplitude of the rise
    p2 = 1.99745370      # steepness of the transition
    p3 = 9.42822604      # turnover mass (log Mstar)
    return p0 + p1 / (1.0 + np.exp(-p2 * (x - p3)))
