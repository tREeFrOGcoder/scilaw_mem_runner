"""Schreiber-style Budyko curve: E/P = 1 - exp(-PET/P)."""
import numpy as np

USED_INPUTS = ["pet_over_p"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {}

def predict(X):
    x = X[:, 0]
    return 1.0 - np.exp(-x)
