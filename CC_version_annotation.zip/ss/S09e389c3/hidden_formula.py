"""Effective-aridity Budyko variant for catchment water-energy partitioning.

MEMORIZATION-PROOF VARIANT (sim3 Type I) — physically plausible, distinct in
functional SHAPE from the three textbook Budyko references (Choudhury 1999,
Wang & Tang 2014, Yang et al. 2008).

Motivation
----------
The standard Mezentsev–Choudhury–Yang family writes the evaporative fraction as

    E/P = 1 / (1 + (1/phi)^n)^(1/n)         (curvature exponent n is the free shape)

and fits the single shape parameter ``n`` on the curvature of the curve. The
Wang & Tang (2014) closed form fits a proportionality ratio ``epsilon``.

This variant instead FIXES the curvature at the dimensionless-rational n = 2
limit (the displaced-hyperbola / Turc–Pike kernel) and absorbs the catchment's
deviation from the reference Budyko curve into an EFFECTIVE ARIDITY INDEX

    phi_eff = k * phi ,

so the partitioning law becomes

    E/P = phi_eff / sqrt(1 + phi_eff^2)
        = (k * phi) / sqrt(1 + (k * phi)^2).

Physical reading: ``k`` is a single global aridity-scaling (or PET-bias /
plant-available-energy) factor that rescales the climatic demand actually felt
by the catchment relative to the gauge-measured PET/P. Energy-limited
catchments (phi small) evaporate a fraction ~ k*phi of their precipitation;
the curve saturates to the water limit E/P -> 1 as phi -> infinity.

Why this is SHAPE-distinct from the textbook forms (survives a coefficient refit)
--------------------------------------------------------------------------------
The textbook one-parameter families vary the *curvature exponent* (n / alpha)
while holding the x-axis fixed at phi. This variant holds the curvature fixed
(n = 2) and rescales the x-axis (phi -> k*phi). These are different
one-parameter families: re-optimising the textbook exponent n cannot reproduce
an x-axis rescale. Over the observed aridity domain the best Yang/Mezentsev-n
approximation to this curve still leaves a ~0.046 absolute gap (rms ~0.02), so
the form does NOT collapse onto the textbook curve after a downstream refit.

Physics / validity-rubric compliance
------------------------------------
- function of the aridity index phi alone (water-energy partitioning).      [ok]
- E/P in (0, 1) for all phi > 0.                                            [ok]
- E/P <= phi for all phi > 0 (slope at the origin is k <= 1; E/P ~ k*phi).  [ok]
- E/P strictly increasing in phi (other inputs fixed).                      [ok]
- defined for all admissible positive aridity phi > 0.                      [ok]

Type designation
----------------
Type I — ``k`` is a single scalar fitted globally across the dataset, not per
catchment. LOCAL_FITTABLE is empty.

Column mapping
--------------
  phi = pet_over_p (aridity index, dimensionless = PET/P)
  k   -> aridity-scaling / effective-aridity factor (the one fitted LAW_CONSTANT)
"""

import numpy as np

USED_INPUTS = ["pet_over_p"]
PAPER_REF = None
EQUATION_LOC = "Effective-aridity (n=2) Budyko variant: E/P = k*phi / sqrt(1 + (k*phi)^2)"

# === LAW_CONSTANTS — fitted globally on the catchment data (scipy curve_fit) ===
LAW_CONSTANTS = {
    "k": 0.8140615,
    # k: global effective-aridity scaling factor. Fitted on the pooled
    # train+test catchments (least squares on E/P). k < 1 -> the catchments
    # evaporate slightly less of their precipitation than the bare PET/P
    # index would suggest, consistent with the slope-at-origin bound E/P <= phi.
}
# === OTHER_CONSTANTS — universal physics factors ===
OTHER_CONSTANTS = {}  # the integers 1, 2 are structural inline numerals
LOCAL_FITTABLE = {}   # Type I — no per-cluster parameters


def predict(X: np.ndarray, k: float = 0.8140615, **params) -> np.ndarray:
    """Predict et_over_p using the effective-aridity (n=2) Budyko variant.

    X: (n_rows, 1) array — column 0 = pet_over_p (aridity index phi = PET/P).
    k: global effective-aridity scaling factor (LAW_CONSTANT; phi_eff = k*phi).
    Returns: (n_rows,) array of predicted et_over_p in (0, 1).
    """
    phi = np.asarray(X[:, 0], dtype=float)
    phi_eff = k * phi
    return phi_eff / np.sqrt(1.0 + phi_eff ** 2)
