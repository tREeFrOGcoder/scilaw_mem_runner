"""Cruising equivalent airspeed as a baseline speed combined quadratically with a wing-loading term."""
import numpy as np

USED_INPUTS = ["mass_kg", "wing_area_m2"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {}

def predict(X):
    m = X[:, 0]
    S = X[:, 1]
    return np.sqrt(115.76 + 15.768 * (m / S))
