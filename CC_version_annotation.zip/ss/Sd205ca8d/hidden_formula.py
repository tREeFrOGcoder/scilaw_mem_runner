"""cand_variant.py — bird_flight_speed_alerstam__Ue (sim3 Type I VARIANT)

Memorization-proof variant of the Alerstam (2007) flight-speed law.

Baseline / textbook forms:
    empirical RMA power law :  Ue = a * Q^c            (Q = m*g/S, wing loading)
    lift-equilibrium        :  Ue = sqrt(2*Q / (rho_0*C_L))

Both are PURE power laws in wing loading Q (exponent 0.31 empirical, 0.5
theoretical). A downstream refit of those forms re-optimizes (a, c) and
collapses any pure-coefficient change back to the textbook power law.

VARIANT — affine-under-root wing-loading law (offset-floor form):

    Ue = sqrt( a * Q + b )      with Q = m * g / S

This keeps the physically-motivated square-root (lift-equilibrium ~ sqrt(Q))
dependence but adds a SHAPE change: an additive baseline term b inside the
root. Physically b plays the role of a residual / floor airspeed (e.g. a
parasitic-drag-limited minimum cruising speed) that is independent of wing
loading, so that as Q -> 0 the speed approaches sqrt(b) rather than 0.

Why this is distinct from the textbook power law AFTER refit:
  - It is sqrt of an AFFINE function of Q, not a pure power Q^c. The fitted
    b is large (b ~ 115, comparable to a*Q over the whole data range), so it
    cannot be absorbed into the amplitude/exponent of a power law — a least-
    squares refit of a*Q^c does NOT reproduce this curve (it bends away from
    a straight log-log line, especially for small birds / low Q).
  - It fits the data about as well as the baseline (rmse ~ 2.29 vs the
    baseline empirical power law ~ 2.35 on the pooled train+test data).

Validity rubrics:
  - body weight increases speed: Q = m*g/S is increasing in m ⇒ Ue increases. OK
  - wing area lowers speed at fixed mass: Q decreasing in S ⇒ Ue decreases. OK
  - strictly positive: a>0, b>0 ⇒ a*Q+b > 0 ⇒ Ue > 0. OK

Contract: USED_INPUTS identical to baseline; LAW_CONSTANTS = fitted (a, b);
predict(X, **LAW_CONSTANTS) pure-numpy vectorised. g is the universal
gravitational constant (OTHER_CONSTANTS), not a discovery target.

LAW_CONSTANTS fitted with scipy.optimize.curve_fit on pooled train+test
(g = 9.81 m/s^2 fixed):
    a = 1.614965   (m^2/s^2 per (N/m^2); slope of the lift-equilibrium term)
    b = 115.086564 (m^2/s^2; floor-speed^2 offset)
"""

import numpy as np

USED_INPUTS = ["mass_kg", "wing_area_m2"]

# === LAW_CONSTANTS — fitted coefficients of the variant ===
LAW_CONSTANTS = {
    "a": 1.614965,    # slope of the wing-loading (lift-equilibrium) term
    "b": 115.086564,  # additive floor-speed^2 offset inside the root
}

# === OTHER_CONSTANTS — universal physics factors ===
OTHER_CONSTANTS = {
    "g": 9.81,  # m/s^2 — standard gravitational acceleration (CODATA / ISO 80000)
}

LOCAL_FITTABLE = {}  # Type I — no per-species parameters


def predict(X: np.ndarray, a: float, b: float) -> np.ndarray:
    """Equivalent airspeed (m/s) from affine-under-root wing-loading law.

    Ue = sqrt(a * Q + b),   Q = m * g / S   (wing loading, N/m^2)

    X: (n, 2) — columns [mass_kg, wing_area_m2] in USED_INPUTS order.
    a, b: fitted coefficients (arrive via predict(X, **LAW_CONSTANTS)).
    g: fixed at 9.81 m/s^2 (universal; read from OTHER_CONSTANTS).

    Returns Ue_ms array of shape (n,).
    """
    g = OTHER_CONSTANTS["g"]
    mass_kg = np.asarray(X[:, 0], dtype=float)
    wing_area_m2 = np.asarray(X[:, 1], dtype=float)
    Q = mass_kg * g / wing_area_m2          # wing loading, N/m^2
    return np.sqrt(np.maximum(a * Q + b, 1e-12))
