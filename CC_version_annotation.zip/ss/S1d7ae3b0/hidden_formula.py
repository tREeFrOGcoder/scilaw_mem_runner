"""Power-generalized rectangular-hyperbola light-response curve — net assimilation.

MEMORIZATION-PROOF VARIANT (sim3 Type II, multi-group). This is deliberately
NOT the textbook non-rectangular hyperbola (Lobo 2013 NRH) and NOT the
Mitscherlich exponential (Peek 2002). It is a distinct, physically-plausible
saturating form: the photon-limited initial-slope line `phi*Qin` is rolled
smoothly into a finite asymptote `Pgmax` through a *power-mean* knee with free
convexity EXPONENT `q`, then offset by dark respiration `RD`:

    A_n = phi*Qin / (1 + (phi*Qin / Pgmax)^q)^(1/q)  -  RD

Properties (q > 0, phi > 0, Pgmax > 0, RD > 0):
  * Qin -> 0    : A_n -> -RD                 (negative in darkness; respiration)
  * dA_n/dQin|0 : -> phi > 0                 (finite positive apparent quantum
                                              yield — the photon-driven onset)
  * Qin -> inf  : A_n -> Pgmax - RD          (finite light-saturated asymptote)
  * monotone non-decreasing in Qin           (no photoinhibition in range)
  * single positive light-compensation point (one sign change, neg -> pos)
  * bounded above by Pgmax-RD, below near -RD

Why this is shape-distinct from the NRH (not a reparameterization):
  The NRH saturates as the lower root of a quadratic with convexity
  theta in (0,1]; this variant saturates as a power-mean of the slope line
  and the asymptote with a free EXPONENT q in (0.6, 6]. q = 1 is the
  rectangular (Michaelis-Menten) hyperbola, q = 2 is the Smith curve, and
  q -> inf approaches the Blackman broken-stick. The two families coincide
  only in degenerate limits, so after a per-cluster fit the fitted curves
  differ in knee curvature (here the fitted q spans ~1.0-3.8 across clusters)
  — genuinely distinct, not an algebraic relabelling of theta.

Fit weighting (a deliberate, simple choice):
  The light-response SHAPE lives on the rising/knee limb; the high-PPFD
  plateau is nearly flat and carries little curve information. fit() applies
  a mild 2x weight to rows with Qin < 300 umol m-2 s-1 so the asymptotic
  plateau does not dominate the least-squares objective and pull the knee
  off the data. This is unweighted-equivalent in shape, only re-balanced.

LAW_CONSTANTS — none (the FORM is the scientific claim; all params per-cluster).
OTHER_CONSTANTS — the literal 1 in (1 + (...)^q)^(1/q) is the structural unit
  of the power-mean blend; the 300 umol m-2 s-1 weight knee and 2x weight are
  fit-procedure constants, not part of the predictive model.

LOCAL_FITTABLE — per-cluster, fitted by fit() via bounded nonlinear LS:
  - phi   : apparent quantum yield at Qin=0 (umol CO2 / umol photon), > 0.
  - Pgmax : light-saturated gross asymptote (umol CO2 m-2 s-1), > 0.
  - RD    : dark respiration rate (umol CO2 m-2 s-1), > 0.
  - q     : convexity exponent of the saturation knee, in (0.6, 6].
"""

import numpy as np
from scipy.optimize import least_squares

USED_INPUTS = ["Qin"]
PAPER_REF = None
EQUATION_LOC = (
    "Power-generalized rectangular hyperbola: "
    "A_n = phi*Qin / (1 + (phi*Qin/Pgmax)^q)^(1/q) - RD."
)

LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {
    "phi":   {"init": None},
    "Pgmax": {"init": None},
    "RD":    {"init": None},
    "q":     {"init": None},
}

# Fit-procedure constants (NOT predictive-model constants).
_WEIGHT_KNEE = 300.0   # umol m-2 s-1 — boundary of the informative rising limb
_WEIGHT_HI = 2.0       # extra weight on the rising/knee limb


def _pgrh(I, phi, Pgmax, RD, q):
    """Power-generalized rectangular-hyperbola net assimilation."""
    I = np.maximum(np.asarray(I, dtype=float), 0.0)
    a = phi * I                              # photon-limited initial-slope line
    denom = (1.0 + (a / Pgmax) ** q) ** (1.0 / q)
    return a / denom - RD


def fit(X_fit: np.ndarray, y_fit: np.ndarray) -> dict:
    """Bounded weighted nonlinear least-squares fit.

    Data-derived initial estimates:
      RD0    = -mean(A at low light), or |min(A)|, floored at 0.5
      Pgmax0 = max(A) + RD0   (rough gross asymptote from observed peak)
      phi0   = 0.05           (mid-range apparent quantum yield)
      q0     = 1.5            (knee convexity midpoint)
    A mild 2x weight on rows with Qin < 300 keeps the flat high-PPFD plateau
    from dominating the knee. Multi-start over q0 for robustness.
    """
    I = np.asarray(X_fit[:, 0], dtype=float)
    y = np.asarray(y_fit, dtype=float)

    low = I < 10.0
    if low.any():
        RD0 = float(np.maximum(-np.mean(y[low]), 0.5))
    else:
        RD0 = float(max(-np.min(y), 0.5))
    Pgmax0 = float(max(np.max(y) + RD0, 1.0))

    w = np.where(I < _WEIGHT_KNEE, _WEIGHT_HI, 1.0)

    #     phi      Pgmax    RD       q
    lo = [1e-5,    0.1,     1e-3,    0.6]
    hi = [0.5,   300.0,    50.0,     6.0]

    def residual(p):
        return (_pgrh(I, p[0], p[1], p[2], p[3]) - y) * w

    best, best_cost = None, np.inf
    for q0 in (1.0, 1.5, 2.0, 3.0):
        p0 = [0.05, Pgmax0, RD0, q0]
        p0 = [min(max(p0[i], lo[i]), hi[i]) for i in range(4)]
        try:
            sol = least_squares(residual, p0, bounds=(lo, hi),
                                method="trf", max_nfev=6000)
            if sol.cost < best_cost and np.all(np.isfinite(sol.x)):
                best_cost, best = sol.cost, sol.x
        except Exception:                            # noqa: BLE001
            continue

    if best is None:
        best = [0.05, Pgmax0, RD0, 1.5]
    return {"phi": float(best[0]), "Pgmax": float(best[1]),
            "RD": float(best[2]), "q": float(best[3])}


def predict(X: np.ndarray, phi: float, Pgmax: float,
            RD: float, q: float) -> np.ndarray:
    """Power-generalized rectangular-hyperbola net assimilation.

    X: (n, 1) — column [Qin] in umol m-2 s-1.
    Returns A_n in umol(CO2) m-2 s-1.
    """
    I = np.asarray(X[:, 0], dtype=float)
    return _pgrh(I, phi, Pgmax, RD, q)
