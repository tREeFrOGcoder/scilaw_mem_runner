"""Non-rectangular hyperbola light-response curve with per-cluster alpha, Amax, curvature, and dark respiration."""
import numpy as np
from scipy.optimize import curve_fit

USED_INPUTS = ["Qin"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {
    "phi": {"init": [0.05]},
    "Amax": {"init": [4.0]},
    "theta": {"init": [0.6]},
    "Rd": {"init": [0.5]},
}

def _nrh(Q, phi, Amax, theta, Rd):
    disc = (phi * Q + Amax) ** 2 - 4.0 * theta * phi * Q * Amax
    disc = np.maximum(disc, 0.0)
    return (phi * Q + Amax - np.sqrt(disc)) / (2.0 * theta) - Rd

def fit(X_fit, y_fit):
    Q = np.asarray(X_fit[:, 0], dtype=float)
    y = np.asarray(y_fit, dtype=float)

    # Sort for stability
    idx = np.argsort(Q)
    Q = Q[idx]
    y = y[idx]

    # Robust initial guesses
    Rd0 = float(max(0.0, -y[0]))
    y_shift = y + Rd0
    A0 = float(max(np.max(y_shift), 0.5))
    if np.any(Q > 0):
        pos = np.where(Q > 0)[0]
        i1 = pos[0]
        i2 = pos[min(1, len(pos) - 1)]
        dq = max(float(Q[i2] - Q[i1]), 1e-6)
        phi0 = float(max((y_shift[i2] - y_shift[i1]) / dq, 1e-4))
    else:
        phi0 = 0.05

    p0 = [phi0, A0, 0.7, Rd0]
    bounds = ([1e-10, 1e-10, 1e-6, 0.0], [10.0, 1e4, 0.999999, 100.0])

    try:
        popt, _ = curve_fit(_nrh, Q, y, p0=p0, bounds=bounds, maxfev=20000)
        return {
            "phi": float(popt[0]),
            "Amax": float(popt[1]),
            "theta": float(popt[2]),
            "Rd": float(popt[3]),
        }
    except Exception:
        return {"phi": float(phi0), "Amax": float(A0), "theta": 0.7, "Rd": float(Rd0)}

def predict(X, phi, Amax, theta, Rd):
    Q = np.asarray(X[:, 0], dtype=float)
    return _nrh(Q, phi, Amax, theta, Rd)
