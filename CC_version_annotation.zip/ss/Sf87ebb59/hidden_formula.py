"""Harmonic-modulated von Mises orientation-tuning function — memorization-proof variant.

The textbook orientation-tuning law (Swindale 1998 Eq. 6; Wu & Van Hooser 2025
Eq. 14) models the tuning peak as a pure exponential-of-cosine von Mises:

    M(theta) = A * exp(k * (cos(2*(theta - phi)) - 1)).

Real V1 tuning curves systematically depart from this pure shape: the flanks
are often sharper or broader than a single-harmonic von Mises predicts, a
non-Gaussian-flank effect well documented in cortical tuning. This variant adds
a small, physically-motivated FLANK-MODULATION term — a multiplicative
second-harmonic (4*theta) factor — that reshapes only the flanks while leaving
the peak amplitude and the preferred orientation intact:

    R(theta) = A * exp(k*(cos(2*(theta - phi)) - 1))
                 * (1 + d * (cos(4*(theta - phi)) - 1))

The factor g(theta) = 1 + d*(cos(4*(theta - phi)) - 1):
- at the peak theta = phi, cos(0) - 1 = 0, so g = 1 and R(phi) = A exactly
  (peak amplitude and location are unchanged by the modulation);
- d > 0 SHARPENS the flanks (pulls response down between peak and trough);
  d < 0 BROADENS / flat-tops them. This is a flank-shape control that is
  mathematically independent of the von Mises width k.

WHY DISTINCT (not just reparameterized von Mises): the product of an
exp-of-cos(2.) and a polynomial-in-cos(4.) is not itself a von Mises and cannot
be rewritten as A'*exp(k'*(cos(2*(theta - psi)) - 1)) for any A', k', psi — the
second harmonic introduces an independent flank degree of freedom. After a
per-neuron fit the modulated and the pure forms leave systematically different
residuals; they are different shape families, not a change of variables.

Physical-plausibility properties (all validity rubrics):
- Orientation-selective peak at preferred orientation phi (g(phi)=1, exp peaks).
- pi-periodic: cos(2*(theta + pi - phi)) and cos(4*(theta + pi - phi)) are both
  invariant under theta -> theta + pi, so 0 deg and 180 deg are identical.
- Orthogonal trough near theta = phi +/- 90 deg, where the exp factor is
  smallest (cos(2*90deg) - 1 = -2).
- Peak flatness/sharpness controllable independently of width via d.
- Non-negative: for d in [-0.5, 0.5] the modulation factor stays >= 0
  (cos(4.) - 1 in [-2, 0] => g in [1 - 2d, 1] >= 0), exp > 0, A > 0,
  so R(theta) >= 0 everywhere.

A baseline / spontaneous offset is not added here: the deconvolved-fluorescence
floor in this dataset is at zero, and the no-baseline von Mises is the reference
form; the modulation term, not a baseline, is the novel physical ingredient.

LAW_CONSTANTS — paper-published, frozen
---------------------------------------
None. The FORM is the claim. A, k, phi, d are per-neuron fits.

OTHER_CONSTANTS — universal / structural factors
------------------------------------------------
(empty.) The `2` and `4` (pi-periodic harmonics) and the `-1` peak-normalising
offsets are structural algebraic invariants coded as literals.

LOCAL_FITTABLE — per-cluster (per-neuron), fitted by fit()
----------------------------------------------------------
- A   : peak amplitude (arb. units, > 0).               init = None: data range.
- k   : tuning concentration (dimensionless, > 0.1).    init = None: 2.0.
- phi : preferred orientation (degrees, interface).     init = None: argmax.
- d   : flank-modulation strength (dimensionless,
        -0.5 <= d <= 0.5; d = 0 -> pure von Mises).      init = 0.0.
"""

import numpy as np
from scipy.optimize import least_squares

USED_INPUTS = ["orientation_deg"]
PAPER_REF = "summary_formula_swindale_1998.md"
EQUATION_LOC = (
    "Harmonic-modulated von Mises: "
    "R(theta) = A*exp(k*(cos(2*(theta-phi))-1))*(1+d*(cos(4*(theta-phi))-1)); "
    "second-harmonic flank modulation on the von Mises core "
    "(Swindale 1998 Eq. 6 core; flank term is the variant's distinct ingredient)."
)

LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {
    "A":   {"init": None},
    "k":   {"init": None},
    "phi": {"init": None},
    "d":   {"init": 0.0},
}


def _predict_rad(theta_rad, A, k, phi_rad, d):
    """Internal: theta and phi in radians."""
    psi = theta_rad - phi_rad
    core = np.exp(k * (np.cos(2.0 * psi) - 1.0))
    modulation = 1.0 + d * (np.cos(4.0 * psi) - 1.0)
    return A * core * modulation


def fit(X_fit: np.ndarray, y_fit: np.ndarray) -> dict:
    """Bounded nonlinear least-squares fit of the harmonic-modulated von Mises.

    Deterministic, data-derived initialisation:
      A0   = max(y_fit) - min(y_fit)     — peak-above-floor amplitude estimate
      k0   = 2.0                         — moderate concentration
      phi0 = orientation of maximum mean response (degrees, mod 180)
      d0   = 0.0                         — start at pure von Mises
    """
    theta_deg = np.asarray(X_fit[:, 0], dtype=float)
    theta_rad = theta_deg * (np.pi / 180.0)
    y = np.asarray(y_fit, dtype=float)

    y_min = float(np.min(y))
    y_max = float(np.max(y))
    A0 = max(y_max - y_min, 1e-6)
    k0 = 2.0
    d0 = 0.0

    unique_deg = np.unique(theta_deg % 180.0)
    if unique_deg.size > 0:
        mean_resp = np.array([
            np.mean(y[np.isclose(theta_deg % 180.0, od, atol=1e-3)])
            for od in unique_deg
        ])
        phi0_deg = float(unique_deg[np.argmax(mean_resp)])
    else:
        phi0_deg = 0.0

    phi0_rad = phi0_deg * (np.pi / 180.0)

    amp_bound = max(abs(y_max), abs(y_min), 1.0) * 20.0
    # A > 0; k > 0.1 (bell shape); phi in [0, pi); d in [-0.5, 0.5]
    # (keeps the modulation factor non-negative => R >= 0 everywhere).
    lo = [1e-9, 0.1, 0.0, -0.5]
    hi = [amp_bound, 100.0, np.pi, 0.5]
    p0 = [float(np.clip(A0, lo[0], hi[0])),
          float(np.clip(k0, lo[1], hi[1])),
          float(np.clip(phi0_rad, lo[2], hi[2])),
          float(np.clip(d0, lo[3], hi[3]))]

    def residual(p):
        return _predict_rad(theta_rad, p[0], p[1], p[2], p[3]) - y

    try:
        sol = least_squares(residual, p0, bounds=(lo, hi),
                            method="trf", max_nfev=6000)
        A, k, phi_rad, d = sol.x
        if not np.all(np.isfinite([A, k, phi_rad, d])):
            raise RuntimeError("non-finite fit")
        return {"A": float(A), "k": float(k),
                "phi": float(phi_rad * (180.0 / np.pi)), "d": float(d)}
    except Exception:                                   # noqa: BLE001
        return {"A": float(p0[0]), "k": float(p0[1]),
                "phi": float(p0[2] * (180.0 / np.pi)), "d": float(p0[3])}


def predict(X: np.ndarray, A: float, k: float, phi: float, d: float) -> np.ndarray:
    """Harmonic-modulated von Mises orientation-tuning prediction.

    R(theta) = A * exp(k*(cos(2*(theta_rad - phi_rad)) - 1))
                 * (1 + d * (cos(4*(theta_rad - phi_rad)) - 1))

    X: (n, 1) — column [orientation_deg].
    phi: preferred orientation in degrees (benchmark CSV units).
    """
    theta_deg = np.asarray(X[:, 0], dtype=float)
    theta_rad = theta_deg * (np.pi / 180.0)
    phi_rad = phi * (np.pi / 180.0)
    return _predict_rad(theta_rad, A, k, phi_rad, d)
