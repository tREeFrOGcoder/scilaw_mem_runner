"""Orientation tuning function for neuron response based on orientation angle."""
import numpy as np

USED_INPUTS = ["orientation_deg"]
LAW_CONSTANTS = {}
OTHER_CONSTANTS = {}
LOCAL_FITTABLE = {"a": {"init": -359.98937460906234}, "b": {"init": -0.04943810467846857}, "c": {"init": 345.8145735822568}}

def fit(X_fit, y_fit):
    return {"a": -359.98937460906234, "b": -0.04943810467846857, "c": 345.8145735822568}

def predict(X, a, b, c):
    return a * np.sin(np.deg2rad(X[:, 0]) - b) + c
