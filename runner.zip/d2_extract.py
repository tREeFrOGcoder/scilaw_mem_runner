"""D2 pre-equation context extractor (LLM-anchored on PROSE, EQUATION_LOC-narrowed).

Pipeline per formula:
  1. resolve_txt  — formula stem -> the RIGHT paper txt via author_year core
                    (ricker_1975 -> ricker_1975_dfo_bulletin191, darc_2025_pyoperon -> darc_2025);
                    marks `no-txt` instead of grabbing a random paper.
  2. narrow       — EQUATION_LOC page + the txt's `=== PAGE N ===` markers hand the LLM ~1-2 pages
                    (saves tokens). Falls back to the txt head; broadens to head on failure.
  3. llm_prose    — a CHEAP LLM does the *semantic* locate and outputs the VERBATIM 1-3 sentences of
                    running PROSE immediately BEFORE the defining equation (NOT the math — prose
                    string-matches reliably and can't leak the formula).
  4. extract      — script locates that prose in the txt (whitespace-normalized), takes the 800 chars
                    ending where the prose ends (= right before the equation), and VERIFIES the prose
                    is really present. On failure: broaden to whole txt, then fall back to the
                    summary `## 1. Background` (flagged), never silently fake.

Test:  python -m runner.d2_extract --tasks /tmp/mem_pilot_tasks.json --model gpt-4o-mini
"""
from __future__ import annotations
import argparse, json, re
from collections import Counter
from pathlib import Path
import yaml
try:
    from .client import complete
except ImportError:
    from client import complete

ROOT = Path(__file__).resolve().parent.parent
CONTEXT_CHARS = 800


def resolve_txt(formula_py: Path, refdir: Path) -> tuple[Path | None, str]:
    stem = formula_py.stem
    m = re.match(r"^(.*?_\d{4}[a-z]?)", stem)            # author_year core
    core = m.group(1) if m else stem
    refs = sorted(refdir.glob("*.txt"))
    for r in refs:
        if r.stem == stem:
            return r, "exact"
    for r in refs:
        if r.stem.startswith(core):
            return r, "core-prefix"
    for r in refs:
        if core in r.stem:
            return r, "core-substr"
    return None, "no-txt"


def parse_eqloc(formula_py: Path) -> dict:
    src = formula_py.read_text(errors="ignore")
    m = re.search(r"EQUATION_LOC\s*=\s*(.+?)(?:\n[A-Z_]+\s*=|\ndef |\n\n)", src, re.S)
    text = " ".join((m.group(1) if m else "").split())
    return {"pages": [int(x) for x in re.findall(r"p\.\s?(\d{1,4})", text)]}


def narrow(txt_text: str, eqloc: dict) -> tuple[str, str]:
    starts = {int(m.group(1)): m.start()
              for m in re.finditer(r"=== PAGE (\d+) ===", txt_text)}
    for pg in eqloc["pages"]:
        if pg in starts:
            s = starts[pg]
            e = starts.get(pg + 2, len(txt_text))
            return txt_text[max(0, s - 200):e], f"page{pg}"
    return txt_text[:14000], "head"


_PROSE_PROMPT = """Below is text extracted (pdf-to-text; spacing may be rough) from a scientific \
paper. Locate the equation that DEFINES {tname} ({tsym}) as a function of {inputs}.

Return STRICT JSON with two verbatim fields (copy characters EXACTLY from the TEXT so a script can \
string-match them):
{{"found": true/false,
  "prose": "<the 1-3 sentences of running TEXT that come ABOVE / BEFORE that equation in reading \
order — the lead-in, NOT the 'where X is ...' definitions that follow it, NOT the equation. ~150-350 chars>",
  "eq_start": "<the first ~15-30 characters of the equation itself (its left-hand side and '=' and \
first operator) — this marks exactly WHERE the equation begins>"}}
The equation must come immediately AFTER your `prose`. If that defining equation is not in the text, \
return {{"found": false, "prose": "", "eq_start": ""}}.

TEXT:
---
{window}
---"""


def llm_prose(window: str, tname: str, tsym: str, inputs: list[str], model: str,
              log_dir: Path) -> tuple[str, str]:
    out = complete(model, _PROSE_PROMPT.format(tname=tname, tsym=tsym,
                   inputs=", ".join(inputs) or "(the listed inputs)", window=window[:14000]),
                   temperature=0.0, max_tokens=300, n=1, log_dir=log_dir)[0]
    m = re.search(r"\{.*\}", out, re.S)
    try:
        v = json.loads(m.group(0)) if m else {}
    except Exception:
        v = {}
    if not v.get("found"):
        return "", ""
    return v.get("prose", ""), v.get("eq_start", "")


def _norm(s: str) -> str:
    return re.sub(r"\s+", " ", s).strip()


def extract(txt_text: str, prose: str, eq_start: str) -> tuple[str, str]:
    """800 chars ending where the prose ends, then HARD-cut before eq_start if it leaked in."""
    if not prose:
        return "", "no-prose"
    T = _norm(txt_text)
    P = _norm(prose)
    end = -1
    for frag in (P, P[-80:], P[-50:]):
        frag = frag.strip()
        if len(frag) >= 12 and (i := T.find(frag)) >= 0:
            end = i + len(frag); break
    if end < 0:
        return "", "prose-not-in-txt"
    ctx = T[max(0, end - CONTEXT_CHARS):end].strip()
    # anti-leak: if the equation start slipped into the context, cut it off there
    eq = _norm(eq_start)
    for frag in ([eq, eq[:14]] if len(eq) >= 8 else []):
        j = ctx.find(frag.strip())
        if j >= 0:
            ctx = ctx[:j].strip(); break
    return ctx, "located"


def _summary_ctx(refdir: Path) -> str:
    for sm in sorted(refdir.glob("summary_*.md")):
        s = sm.read_text(errors="ignore")
        m = re.search(r"^##\s*1\.\s*Background.*$", s, re.M | re.I)
        if m:
            return _norm(s[m.end():m.end() + 1200])[:CONTEXT_CHARS]
    return ""


def get_context(formula_py: Path, refdir: Path, tname: str, tsym: str, inputs: list[str],
                model: str, log_dir: Path) -> dict:
    txt, how_txt = resolve_txt(formula_py, refdir)
    if txt is None:
        ctx = _summary_ctx(refdir)
        return {"txt": "—", "how_txt": how_txt, "narrow": "-",
                "status": "fallback-summary" if ctx else "none", "context": ctx}
    text = txt.read_text(errors="ignore")
    window, how_narrow = narrow(text, parse_eqloc(formula_py))
    prose, eq_start = llm_prose(window, tname, tsym, inputs, model, log_dir)
    ctx, status = extract(text, prose, eq_start)
    if status != "located" and how_narrow != "head":          # broaden to whole-txt head
        prose, eq_start = llm_prose(text[:14000], tname, tsym, inputs, model, log_dir)
        ctx, status = extract(text, prose, eq_start)
        how_narrow += "->head"
    if status != "located":                                    # last resort: summary background
        sctx = _summary_ctx(refdir)
        if sctx:
            return {"txt": txt.name, "how_txt": how_txt, "narrow": how_narrow,
                    "status": "fallback-summary", "context": sctx, "prose": prose}
    return {"txt": txt.name, "how_txt": how_txt, "narrow": how_narrow,
            "status": status, "context": ctx, "prose": prose}


def main(argv=None):
    p = argparse.ArgumentParser()
    p.add_argument("--tasks", required=True)
    p.add_argument("--bench", default="final_merge_2026-06-02")
    p.add_argument("--model", default="gpt-4o-mini")
    p.add_argument("--show", default="cepheid_period_luminosity__M_W,co2_adsorption_zeolite_isodb_toth__n_ads,"
                   "coral_reef_fish_growth_wicquart__length_mm,bns_merger_disk_ejecta__Mdisk,"
                   "baseball_pythagorean_winpct_lahman__win_pct")
    a = p.parse_args(argv)
    raw = json.loads(Path(a.tasks).read_text())
    tasks = (raw["typeI"] + raw["typeII"]) if isinstance(raw, dict) else raw
    bench = ROOT / a.bench
    show = set(a.show.split(","))
    log_dir = Path(__file__).resolve().parent / "d2_extract_runs" / "anchor_raw"

    n = 0
    status_c, txt_c = Counter(), Counter()
    for tname in tasks:
        td = bench / tname
        meta = yaml.safe_load((td / "metadata.yaml").read_text())
        t = meta["target"]; tsym = t.get("symbol") or t.get("name")
        inputs = [i.get("symbol") or i.get("name") for i in meta["inputs"] if i.get("name") != "group_id"]
        for fp in sorted((td / "formulas").glob("*.py")):
            if fp.stem.startswith("_"):
                continue
            r = get_context(fp, td / "reference", t.get("name"), tsym, inputs, a.model, log_dir)
            n += 1
            status_c[r["status"]] += 1
            txt_c[r["how_txt"]] += 1
            if tname in show:
                print("=" * 96)
                print(f"{tname}  |  {fp.stem}")
                print(f"   txt={r['txt']} ({r['how_txt']})  narrow={r['narrow']}  -> {r['status']}")
                if r["context"]:
                    print(f"   context tail ~170: …{r['context'][-170:]!r}")
    print("\n" + "=" * 96)
    print(f"{n} formulas   status={dict(status_c)}   txt-resolution={dict(txt_c)}")
    good = status_c["located"]
    print(f"clean-located={good}/{n}  (+fallback-summary {status_c['fallback-summary']})")


if __name__ == "__main__":
    main()
