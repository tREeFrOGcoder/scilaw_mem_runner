"""Memorization audit v3 (pilot) — the converged design (2026-06-06).

Paradigm (vs the old bare-math + numeric-fold pipeline):
  * The probe asks the LLM to output a Python ``def predict(X): ...`` (same
    deliverable as the real eval), NOT a bare-math expression.
  * Equivalence is decided by an **LLM judge comparing the two predict
    functions' forms** (coefficients fold; exponents are structural).
    NO numeric congruence here — that is a *recovery* metric and lives in a
    separate dir for Setting-2; for *memorization* we want same-FORM (recall),
    and a different-looking-but-numerically-equal function is NOT recall.
  * GT is the formula file's ``predict`` (+ its helpers / constant dicts),
    docstrings stripped — NO AST structural-string extraction.
  * Verdict per (task, formula, model): **memorized / suspect / clean**
    (renamed from HARD / SOFT / PASS).

D1 input: I/O spec only (target + ordered inputs, with descriptions).  no context.
D2 input: D1 + citation + the ~800 chars of the paper that precede the equation
          (located in reference/<formula_stem>.txt; falls back if not found).

Run:
  python -m runner.pilot_v3 --tasks /tmp/mem_pilot_tasks.json \
      --models gpt-4o-mini,gpt-4.1-mini,gpt-5-mini --probes d1,d2 \
      --bench final_merge_2026-06-02
"""
from __future__ import annotations
import argparse, ast, json, re, sys, os
from pathlib import Path
import yaml

try:
    from .client import complete
except ImportError:
    from client import complete
try:
    from .d2_extract import resolve_txt
except ImportError:
    from d2_extract import resolve_txt

ROOT = Path(__file__).resolve().parent.parent
OUT_ROOT = Path(__file__).resolve().parent / "pilot_v3_runs"
CONTEXT_CHARS = 800

# ----------------------------------------------------------------------------- prompts
D1_PROMPT = """You are an expert in {domain}. Using ONLY your own knowledge — you are given NO data — \
write the standard closed-form relationship for the quantity below as a Python function.

Quantity to predict:
- {t_name} ({t_sym}){t_unit} — {t_desc}

Inputs (X is a 2-D numpy array; column X[:, i] is the i-th input listed):
{inputs_block}

Write a single Python function `def predict(X):` (use `import numpy as np`) that returns a 1-D \
array of {t_sym}. Fitted coefficients may be literal numbers or named constants — your choice. \
If several canonical forms exist, write the most commonly cited one. Output ONLY one \
```python ... ``` block, nothing else."""

D2_EXTRA = """

The text below is the passage that appears immediately BEFORE the relevant equation in the source \
{citation}. Use it, together with your general knowledge, to recall the canonical form:
---
{context}
---"""

# --- ablation arms: weaker (leak-safe) D2 guides ---
D2_CITE = """

Recall the canonical closed form for {t_sym} exactly as published in {citation}, \
using your general knowledge of that specific work."""

D2_ABSTRACT = """

The following is the opening / abstract of {citation}. Use it, together with your general \
knowledge, to recall the canonical form published in that work:
---
{context}
---"""

JUDGE_PROMPT = """You compare two Python functions that both predict {t_sym}. Decide whether they \
implement the **same functional form**.

The input variables (carry the same meaning in both; NOT renameable): {inputs}. Everything else \
(literal numbers, named constants, free parameters) is a fittable COEFFICIENT.

Equivalence rules:
(1) Standard algebra preserves equivalence (commutativity, factoring, exp(log x)=x, log/exp laws...).
(2) **Coefficient fold (critical).** At any multiplicative-factor / additive-offset / ratio / \
internal-rate / pivot position, a literal number on one side and a free symbol (or a different \
number) on the other are EQUIVALENT. A baked number is STRONGER recall, NOT a different form. \
Renaming free coefficients is allowed. Combinations of coefficients fold to one coefficient.
(3) max(_,0)/np.maximum(_,0)/clipping is identity on the valid range.
(4) **Exponents and structural integer powers are NOT coefficients — they must MATCH in value** \
(approximately): `x**2` vs `x**(5/3)` is a DIFFERENT form; `x**1.667` vs `x**(5/3)` is the SAME. \
Likewise the count/degree of terms is structural.
(5) Different functional FAMILIES at a structural position fail: exp(-x) vs 1/(1+x), tanh vs \
x/sqrt(1+x^2), polynomial vs log, VBGF vs Gompertz, etc. This and (4) are the ONLY axes along \
which two functions are "different".

Judge by the FORM only; do not run or fit. Ignore which side uses numbers vs symbols for coefficients.

REFERENCE (ground truth):
```python
{gt_code}
```

CANDIDATE (model output):
```python
{cand_code}
```

Output JSON only: {{"equivalent": true|false, "reason": "<one sentence>"}}"""


# ----------------------------------------------------------------------------- task assets
def load_meta(task_dir: Path) -> dict:
    return yaml.safe_load((task_dir / "metadata.yaml").read_text())


def io_spec(meta: dict) -> tuple[dict, list[dict]]:
    t = meta["target"]
    target = {"name": t.get("name", "y"), "sym": t.get("symbol") or t.get("name", "y"),
              "unit": t.get("unit", "") or "", "desc": t.get("description", "") or ""}
    inputs = [{"name": i.get("name", ""), "sym": i.get("symbol") or i.get("name", ""),
               "unit": i.get("unit", "") or "", "desc": i.get("description", "") or "",
               "range": i.get("range")}
              for i in meta["inputs"] if i.get("name") != "group_id"]
    return target, inputs


def inputs_block(inputs: list[dict]) -> str:
    out = []
    for i, v in enumerate(inputs):
        u = f" [{v['unit']}]" if v["unit"] else ""
        rng = f"  (typical range {v['range']})" if v.get("range") else ""
        out.append(f"- X[:, {i}] = {v['name']} ({v['sym']}){u} — {v['desc']}{rng}")
    return "\n".join(out)


_DOC_TYPES = (ast.FunctionDef, ast.AsyncFunctionDef, ast.ClassDef, ast.Module)


def _strip_docstrings(node):
    for n in ast.walk(node):
        if isinstance(n, _DOC_TYPES):
            b = getattr(n, "body", [])
            if b and isinstance(b[0], ast.Expr) and isinstance(getattr(b[0], "value", None), ast.Constant) \
                    and isinstance(b[0].value.value, str):
                n.body = b[1:] or [ast.Pass()]


def gt_code(formula_py: Path) -> tuple[str, list[str]]:
    """Return (clean GT source for the judge, USED_INPUTS).

    Keeps USED_INPUTS / *_CONSTANTS / *_FITTABLE assigns + all module-level
    functions EXCEPT `fit` (the per-cluster fitter is irrelevant to the form).
    Strips all docstrings (so the judge reasons over code, not prose).
    """
    src = formula_py.read_text()
    tree = ast.parse(src)
    used: list[str] = []
    keep: list[ast.stmt] = []
    for n in tree.body:
        if isinstance(n, ast.Assign) and len(n.targets) == 1 and isinstance(n.targets[0], ast.Name):
            name = n.targets[0].id
            if name == "USED_INPUTS":
                try: used = list(ast.literal_eval(n.value))
                except Exception: pass
            if name in ("USED_INPUTS",) or name.endswith("_CONSTANTS") or name.endswith("_FITTABLE"):
                keep.append(n)
        elif isinstance(n, ast.FunctionDef) and n.name != "fit":
            keep.append(n)
    mod = ast.Module(body=keep, type_ignores=[])
    _strip_docstrings(mod)
    ast.fix_missing_locations(mod)
    return ast.unparse(mod), used


def find_paper_txt(reference_dir: Path, formula_py: Path) -> Path | None:
    cand = reference_dir / f"{formula_py.stem}.txt"
    if cand.exists():
        return cand
    txts = sorted(reference_dir.glob("*.txt"))
    return txts[0] if txts else None


def d2_context(reference_dir: Path, formula_py: Path, target_sym: str,
               inputs: list[dict]) -> tuple[str, str]:
    """~800 chars preceding the defining equation in the paper txt.

    Returns (context, how) where how ∈ {located, fallback-summary, fallback-head, none}.
    Heuristic locator: earliest '=' line that mentions the target symbol or an
    input token (or carries Greek letters). NOT perfect — D2 quality is reported.
    """
    txt = find_paper_txt(reference_dir, formula_py)
    if not txt:
        return "", "none"
    text = txt.read_text(errors="ignore")
    toks = [target_sym] + [i["sym"] for i in inputs] + [i["name"] for i in inputs]
    toks = [re.escape(t) for t in toks if t and len(t) >= 1]
    pos = None
    for m in re.finditer(r"[^\n]*=[^\n]*", text):
        line = m.group(0)
        if "==" in line or line.count("=") > 2 or len(line) > 200:
            continue
        score = sum(1 for t in toks if re.search(t, line, re.IGNORECASE))
        if re.search(r"[Ͱ-Ͽ]", line):  # greek
            score += 1
        if score >= 1 and m.start() > 400:       # skip title/author block
            pos = m.start(); break
    if pos is not None:
        ctx = text[max(0, pos - CONTEXT_CHARS):pos].strip()
        return ctx, "located"
    # fallback: summary background, else head of body
    summ = sorted(reference_dir.glob("summary_*.md"))
    if summ:
        s = summ[0].read_text(errors="ignore")
        m = re.search(r"^##\s*1\.\s*Background.*?$", s, re.M | re.I)
        if m:
            body = s[m.end():]
            return body[:CONTEXT_CHARS].strip(), "fallback-summary"
    return text[500:500 + CONTEXT_CHARS].strip(), "fallback-head"


def txt_head(reference_dir: Path, formula_py: Path, n: int = 800) -> str:
    """First ~n chars of the RIGHT paper txt (title/abstract region), leak-safe.

    Mechanical (no LLM, no locating): resolves the correct paper, strips page
    markers, normalizes whitespace, returns the head. Abstracts state results
    qualitatively, so they rarely carry the constant-laden equation.
    """
    txt, _ = resolve_txt(formula_py, reference_dir)
    if txt is None:
        return ""
    t = re.sub(r"=== PAGE \d+ ===", " ", txt.read_text(errors="ignore"))
    return re.sub(r"\s+", " ", t).strip()[:n]


def citation_of(meta: dict, formula_py: Path) -> str:
    """Clean author+year citation parsed from the formula FILENAME.

    e.g. aab_2019 -> "Aab (2019)", xu_randall_1996 -> "Xu Randall (1996)",
    darc_2025_pyoperon -> "Darc (2025)".

    Deliberately does NOT use the metadata `references[].label`: those are
    editorial annotations that (a) spell out the form/exponent (leak) and
    (b) were mis-selected by a startswith bug (always returned refs[0]). The
    filename gives a clean bibliographic key (surname(s)+year) that cannot
    carry the formula. Descriptive baseline names with no year (one_over_v,
    single_power_law, …) return "" → no citation shown (D2 == D1 for them).
    """
    stem = formula_py.stem
    m = re.search(r"(\d{4})", stem)
    if not m:
        return ""
    year = m.group(1)
    authors = stem[:m.start()].rstrip("_").replace("_", " ").strip()
    if not authors:
        return ""
    authors = " ".join(w.capitalize() for w in authors.split())
    return f"{authors} ({year})"


# ----------------------------------------------------------------------------- elicitation + judge
def extract_code(raw: str) -> str:
    m = re.search(r"```(?:python)?\s*(.+?)```", raw, re.S)
    if m:
        return m.group(1).strip()
    m = re.search(r"(?:^|\n)(import .+|def predict.+)", raw, re.S)
    if m:
        return raw[m.start():].strip()
    return raw.strip()


def judge(gt_src: str, cand_src: str, t_sym: str, input_syms: list[str],
          judge_model: str, log_dir: Path) -> dict:
    prompt = JUDGE_PROMPT.format(t_sym=t_sym, inputs=", ".join(input_syms) or "(none)",
                                 gt_code=gt_src, cand_code=cand_src)
    out = complete(judge_model, prompt, temperature=0.0, max_tokens=400, n=1, log_dir=log_dir)[0]
    m = re.search(r"\{.*\}", out, re.S)
    try:
        v = json.loads(m.group(0)) if m else {}
    except Exception:
        v = {}
    return {"equivalent": bool(v.get("equivalent", False)),
            "reason": str(v.get("reason", ""))[:200], "judge_raw": out[:400]}


def verdict(d1_rate: float, d2_rate: float) -> str:
    EPS = 1e-3
    if d1_rate >= 0.60 - EPS or d2_rate >= 2.0/3.0 - EPS:
        return "memorized"
    if d1_rate >= 0.20 - EPS or d2_rate >= 1.0/3.0 - EPS:
        return "suspect"
    return "clean"


# ----------------------------------------------------------------------------- per-task run
def run_task(task_dir: Path, model: str, judge_model: str, probes: list[str],
             out_root: Path = OUT_ROOT, d2_cache: dict | None = None,
             d2_mode: str = "paragraph") -> dict:
    meta = load_meta(task_dir)
    target, inputs = io_spec(meta)
    input_syms = [i["sym"] for i in inputs]
    fdir = task_dir / "formulas"
    formula_files = [p for p in sorted(fdir.glob("*.py")) if not p.stem.startswith("_")]
    formulas = []
    for fp in formula_files:
        code, _used = gt_code(fp)
        formulas.append({"stem": fp.stem, "gt": code, "py": fp})
    if not formulas:
        return {"status": "no-formulas"}

    out_dir = out_root / task_dir.name / model
    out_dir.mkdir(parents=True, exist_ok=True)
    jlog = out_dir / "judge_raw"
    t_unit = f" [{target['unit']}]" if target["unit"] else ""
    base = dict(domain=meta.get("domain", "science"), t_name=target["name"], t_sym=target["sym"],
                t_unit=t_unit, t_desc=target["desc"], inputs_block=inputs_block(inputs))

    res = {"task": task_dir.name, "model": model, "type": meta.get("type"),
           "primary": (meta.get("domain", "") or "").split("/")[0], "formulas": []}

    # ---- D1: one elicitation (n=5), judged against every formula ----
    d1_hits = [0] * len(formulas)
    d1_samples = []
    if "d1" in probes:
        raws = complete(model, D1_PROMPT.format(**base), temperature=0.8, max_tokens=900, n=5,
                        log_dir=out_dir / "d1_raw")
        cands = [extract_code(r) for r in raws]
        d1_samples = cands
        for fi, f in enumerate(formulas):
            for c in cands:
                if judge(f["gt"], c, target["sym"], input_syms, judge_model, jlog)["equivalent"]:
                    d1_hits[fi] += 1

    # ---- D2: per-formula elicitation (n=3) with that formula's context ----
    d2_hits = [0] * len(formulas)
    d2_how = []
    if "d2" in probes:
        for fi, f in enumerate(formulas):
            cite = citation_of(meta, f["py"])
            if d2_mode == "citation":
                if cite:
                    extra, how = D2_CITE.format(t_sym=target["sym"], citation=cite), "citation"
                else:
                    extra, how = "", "no-cite"   # no-year baseline: D2 == D1
            elif d2_mode == "abstract":
                head = txt_head(task_dir / "reference", f["py"])
                extra = D2_ABSTRACT.format(citation=cite, context=head or "(no abstract found)")
                how = "abstract" if head else "abstract-none"
            else:  # paragraph (cache or live locator)
                cached = (d2_cache or {}).get(task_dir.name, {}).get(f["stem"])
                if cached is not None:
                    ctx, how = cached.get("context", ""), cached.get("status", "cache")
                else:
                    ctx, how = d2_context(task_dir / "reference", f["py"], target["sym"], inputs)
                extra = D2_EXTRA.format(citation=cite, context=ctx or "(no context found)")
            d2_how.append(how)
            # splice the D2 guide block in just before the "Write a single" instruction
            prompt = D1_PROMPT.format(**base).replace("\n\nWrite a single Python",
                                                      extra + "\n\nWrite a single Python")
            raws = complete(model, prompt, temperature=0.3, max_tokens=900, n=3,
                            log_dir=out_dir / "d2_raw")
            for r in raws:
                if judge(f["gt"], extract_code(r), target["sym"], input_syms, judge_model, jlog)["equivalent"]:
                    d2_hits[fi] += 1

    for fi, f in enumerate(formulas):
        d1r = d1_hits[fi] / 5 if "d1" in probes else 0.0
        d2r = d2_hits[fi] / 3 if "d2" in probes else 0.0
        res["formulas"].append({
            "formula": f["stem"], "d1_hits": d1_hits[fi], "d1_rate": round(d1r, 3),
            "d2_hits": d2_hits[fi], "d2_rate": round(d2r, 3),
            "d2_context": (d2_how[fi] if "d2" in probes else None),
            "verdict": verdict(d1r, d2r),
        })
    (out_dir / "result.json").write_text(json.dumps(res, indent=2, ensure_ascii=False))
    (out_dir / "d1_samples.txt").write_text("\n\n=====\n\n".join(d1_samples))
    return res


def main(argv=None):
    p = argparse.ArgumentParser()
    p.add_argument("--tasks", required=True, help="json {typeI:[...], typeII:[...]} or [task,...]")
    p.add_argument("--bench", default="final_merge_2026-06-02")
    p.add_argument("--models", default="gpt-4o-mini")
    p.add_argument("--judge", default="gpt-4.1")   # 100% aligned with the Opus gold (gold/judge_alignment)
    p.add_argument("--probes", default="d1,d2")
    p.add_argument("--limit", type=int, default=0, help="limit #tasks (debug)")
    p.add_argument("--workers", type=int, default=1, help="concurrent (task,model) jobs")
    p.add_argument("--out-root", default=None, help="override output dir (default pilot_v3_runs)")
    p.add_argument("--d2-cache", default=None, help="json cache of pre-equation context per task/formula")
    p.add_argument("--d2-mode", default="paragraph", choices=["paragraph", "citation", "abstract"],
                   help="D2 guide strength: paragraph (pre-eq text) | citation (identity only) | abstract (txt head)")
    a = p.parse_args(argv)

    raw = json.loads(Path(a.tasks).read_text())
    tasks = (raw["typeI"] + raw["typeII"]) if isinstance(raw, dict) else raw
    if a.limit:
        tasks = tasks[:a.limit]
    models = [m.strip() for m in a.models.split(",") if m.strip()]
    probes = [x.strip() for x in a.probes.split(",") if x.strip()]
    bench = ROOT / a.bench
    out_root = Path(a.out_root) if a.out_root else OUT_ROOT
    d2_cache = json.loads(Path(a.d2_cache).read_text()) if a.d2_cache else None

    jobs = [(t, m) for t in tasks for m in models]

    # R1: the judge must differ from the subject; on collision swap to a 2nd-best alternate
    alt_judge = "gpt-4.1-mini" if a.judge != "gpt-4.1-mini" else "gpt-4.1"

    def do(job):
        tname, model = job
        jm = a.judge if model != a.judge else alt_judge
        return tname, model, run_task(bench / tname, model, jm, probes, out_root, d2_cache, a.d2_mode)

    rows = []
    from concurrent.futures import ThreadPoolExecutor, as_completed
    with ThreadPoolExecutor(max_workers=max(1, a.workers)) as ex:
        futs = {ex.submit(do, j): j for j in jobs}
        for fut in as_completed(futs):
            tname, model = futs[fut]
            try:
                _, _, r = fut.result()
                if r.get("status"):
                    print(f"[skip] {tname} | {model}: {r['status']}", file=sys.stderr); continue
                for f in r["formulas"]:
                    rows.append({**f, "task": tname, "model": model, "type": r["type"]})
                    print(f"{tname[:38]:38s} | {model:13s} | {f['formula'][:22]:22s} "
                          f"| D1 {f['d1_hits']}/5 D2 {f['d2_hits']}/3 | {f['verdict']}", flush=True)
            except Exception as e:
                print(f"[ERR] {tname} | {model}: {e}", file=sys.stderr, flush=True)
    out_root.mkdir(parents=True, exist_ok=True)
    (out_root / "rows.json").write_text(json.dumps(rows, indent=2, ensure_ascii=False))
    # tiny summary
    from collections import Counter
    c = Counter(r["verdict"] for r in rows)
    print(f"\n=== {len(rows)} (task,formula,model) rows: "
          f"memorized={c['memorized']} suspect={c['suspect']} clean={c['clean']} ===")


if __name__ == "__main__":
    main()
