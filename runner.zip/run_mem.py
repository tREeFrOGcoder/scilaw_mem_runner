"""One-command entry point for the memorization probe.

    python3 run_mem.py --list                    # what can I run, and what will it cost
    python3 run_mem.py --models glm --limit 2    # smoke test, ~$0.10, do this first
    python3 run_mem.py --models glm              # one full leg, 118 tasks
    python3 run_mem.py --models glm,qwen         # several legs
    python3 run_mem.py --models glm --pack       # run, then zip the output to send back

Everything the probe needs is inside this folder: the task slice (`bench/`), the task
list, the model settings, and the runner. Nothing outside it is read. Output goes to
`runs/<model>/` and is self-describing.

Required environment: OPENROUTER_API_KEY for the non-OpenAI models, OPENAI_API_KEY for
the OpenAI models and for the judge (the judge is gpt-4.1 in every case — it must stay
the same across all legs, so an OPENAI_API_KEY is needed no matter which subject runs).
"""

from __future__ import annotations

import argparse
import json
import os
import shutil
import sys
import zipfile
from collections import Counter
from pathlib import Path

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))

from client import MODELS                       # noqa: E402
import pilot_v3                                 # noqa: E402

JUDGE = "gpt-4.1"          # frozen: same judge for every leg, never the subject itself
D2_MODE = "citation"       # frozen: author+year identity only
PROBES = "d1,d2"

# short names so nobody has to type provider slugs
ALIAS = {
    "opus": "anthropic/claude-opus-4.8",
    "deepseek": "deepseek/deepseek-v4-pro",
    "gemini": "google/gemini-3.5-flash",
    "qwen": "qwen/qwen3.7-max",
    "glm": "z-ai/glm-5.2",
    "gpt-5.4-mini": "gpt-5.4-mini",
    "gpt-5.5": "gpt-5.5",
    "gpt-5-mini": "gpt-5-mini",
    "gpt-4o-mini": "gpt-4o-mini",
}
# measured / calibrated full-leg cost for 118 tasks, USD. See PROTOCOL.md for how these
# were derived; treat them as ±40%, and read `billed_usd` in the logs for the truth.
EST = {"anthropic/claude-opus-4.8": 32, "deepseek/deepseek-v4-pro": 19,
       "google/gemini-3.5-flash": 92, "qwen/qwen3.7-max": 48, "z-ai/glm-5.2": 31,
       "gpt-5.4-mini": 1}
JUDGE_EST = 4.73           # measured: gpt-4.1, per model, per 118 tasks


def resolve(names: str) -> list[str]:
    if names.strip() == "all":
        return [m for m in MODELS if MODELS[m]["backend"] == "openrouter"]
    out = []
    for n in (x.strip() for x in names.split(",") if x.strip()):
        m = ALIAS.get(n, n)
        if m not in MODELS:
            raise SystemExit(f"unknown model {n!r}. Known: {', '.join(sorted(ALIAS))}")
        out.append(m)
    return out


def cmd_list() -> None:
    print(f"{'alias':<14}{'model':<30}{'backend':<12}{'reasoning':<22}{'provider':<11}{'~$/leg':>7}")
    for alias, m in ALIAS.items():
        c = MODELS[m]
        r = c["reasoning"] if isinstance(c["reasoning"], str) else json.dumps(c["reasoning"])
        print(f"{alias:<14}{m:<30}{c['backend']:<12}{r:<22}{c.get('provider', '-'):<11}"
              f"{EST.get(m, 0):7.0f}")
    print(f"\njudge = {JUDGE} (OpenAI) — adds ~${JUDGE_EST:.2f} per leg, billed to OPENAI_API_KEY")
    print(f"tasks = 118   probes = {PROBES}   d2-mode = {D2_MODE}")


def check_keys(models: list[str]) -> None:
    need = {"OPENAI_API_KEY"}                 # judge always runs on OpenAI
    if any(MODELS[m]["backend"] == "openrouter" for m in models):
        need.add("OPENROUTER_API_KEY")
    missing = [k for k in sorted(need) if not os.environ.get(k)]
    if missing:
        raise SystemExit("missing environment variable(s): " + ", ".join(missing))


def pack(out_root: Path, models: list[str]) -> Path:
    """Zip exactly what needs to be sent back: every raw completion, the judge trail,
    the per-task verdicts, and the merged table."""
    zpath = out_root.parent / f"mem_results_{'_'.join(m.split('/')[-1] for m in models)}.zip"
    with zipfile.ZipFile(zpath, "w", zipfile.ZIP_DEFLATED) as z:
        for p in sorted(out_root.rglob("*")):
            if p.is_file():
                z.write(p, p.relative_to(out_root.parent))
    print(f"\npacked -> {zpath}  ({zpath.stat().st_size / 1e6:.1f} MB)")
    return zpath


def main(argv=None):
    ap = argparse.ArgumentParser()
    ap.add_argument("--models", help="aliases or slugs, comma separated; or 'all'")
    ap.add_argument("--list", action="store_true", help="show the model table and exit")
    ap.add_argument("--limit", type=int, default=0, help="only the first N tasks (smoke test)")
    ap.add_argument("--workers", type=int, default=12)
    ap.add_argument("--out", default=str(HERE / "runs"))
    ap.add_argument("--pack", action="store_true", help="zip the output when finished")
    a = ap.parse_args(argv)

    if a.list or not a.models:
        cmd_list()
        return
    models = resolve(a.models)
    check_keys(models)
    n_tasks = a.limit or 118
    est = sum(EST.get(m, 0) + JUDGE_EST for m in models) * n_tasks / 118
    print(f"models : {', '.join(models)}")
    print(f"tasks  : {n_tasks}   workers: {a.workers}   judge: {JUDGE}")
    print(f"est.   : ~${est:.2f}  (±40%; real billed amounts land in the logs)\n")

    out_root = Path(a.out)
    pilot_v3.main(["--tasks", str(HERE / "tasks_118.json"),
                   "--bench", str(HERE / "bench"),
                   "--models", ",".join(models),
                   "--judge", JUDGE, "--probes", PROBES, "--d2-mode", D2_MODE,
                   "--workers", str(a.workers), "--out-root", str(out_root)]
                  + (["--limit", str(a.limit)] if a.limit else []))

    # --- spend + coverage, straight from the logs ---
    billed = 0.0
    for f in out_root.rglob("d[12]_raw/*.json"):
        billed += json.loads(f.read_text()).get("billed_usd", 0) or 0
    rows = json.loads((out_root / "rows.json").read_text()) if (out_root / "rows.json").exists() else []
    print(f"\n{'model':<30}{'tasks':>7}{'rows':>7}{'mem':>6}{'sus':>6}{'clean':>6}")
    for m in models:
        mr = [r for r in rows if r["model"] == m]
        c = Counter(r["verdict"] for r in mr)
        nt = len({r["task"] for r in mr})
        flag = "" if nt >= n_tasks else f"  <- INCOMPLETE, expected {n_tasks}"
        print(f"{m:<30}{nt:7}{len(mr):7}{c['memorized']:6}{c['suspect']:6}{c['clean']:6}{flag}")
    if billed:
        print(f"\nactually billed on OpenRouter: ${billed:.2f}")

    if a.pack:
        pack(out_root, models)


if __name__ == "__main__":
    main()
