"""Unified LLM call layer for the memorization probe.

Two backends, selected per model by `models.json`:

- **openai**      native OpenAI SDK. This path is byte-for-byte the one that produced
                  the canonical 8-model run already reported in the paper. Do not change
                  it — the whole point of new legs is that they use the same instrument.
- **openrouter**  OpenAI-compatible endpoint for every non-OpenAI vendor. Adds three
                  things the native path does not need: an n-loop (most OpenRouter
                  providers reject n>1), an explicit `reasoning` setting, and provider
                  pinning.

Every call persists prompt + completions + usage + **actual billed cost** + the provider
that served it. Cost logging exists because an earlier run had to reconstruct spend from
token counts and per-model list prices, which was wrong twice: once from extrapolating a
partially-complete leg (the cheap tasks finish first), and once from pricing at the
default OpenRouter route when billing had used a different reseller. `usage.cost` is
returned by OpenRouter for free when `usage.include` is set — always record it.
"""

from __future__ import annotations

import json
import math
import os
import time
import uuid
from pathlib import Path
from typing import Any

HERE = Path(__file__).resolve().parent
MODELS: dict[str, dict] = {
    k: v for k, v in json.loads((HERE / "models.json").read_text()).items()
    if not k.startswith("_")
}

OR_BASE_URL = "https://openrouter.ai/api/v1"
OR_MAX_TOKENS = 28800   # frozen ceiling; == the canonical path's max(900*32, 16384)

_client = None
_or_client = None

_MODEL_PRICING: dict[str, tuple[float, float]] = {
    "gpt-4o": (2.50, 10.00),
    "gpt-4o-mini": (0.15, 0.60),
    "gpt-4-turbo": (10.00, 30.00),
    "gpt-4-0613": (30.00, 60.00),
}


def model_cfg(model: str) -> dict:
    """Config for `model`; unknown models fall back to the OpenAI path (gpt-*) or fail."""
    if model in MODELS:
        return MODELS[model]
    if "/" in model:
        raise ValueError(f"{model!r} is not in models.json — add it (backend/reasoning/provider)")
    return {"backend": "openai", "reasoning": "native"}


def _get_client():
    global _client
    if _client is not None:
        return _client
    from openai import OpenAI
    key = os.environ.get("OPENAI_API_KEY")
    if not key:
        raise RuntimeError("OPENAI_API_KEY is not set")
    _client = OpenAI(api_key=key)
    return _client


def _get_or_client():
    global _or_client
    if _or_client is not None:
        return _or_client
    from openai import OpenAI
    key = os.environ.get("OPENROUTER_API_KEY")
    if not key:
        raise RuntimeError("OPENROUTER_API_KEY is not set")
    _or_client = OpenAI(api_key=key, base_url=OR_BASE_URL)
    return _or_client


def _write_log(log_dir: Path | None, record: dict) -> None:
    if log_dir is None:
        return
    log_dir.mkdir(parents=True, exist_ok=True)
    (log_dir / f"{int(time.time())}_{uuid.uuid4().hex[:8]}.json").write_text(
        json.dumps(record, ensure_ascii=False, indent=2))


def _complete_openrouter(model, messages, temperature, n, log_dir, prompt, system,
                         max_retries, cfg) -> list[str]:
    """n independent samples via an n-loop (providers reject n>1), at an explicit
    reasoning setting, pinned to one provider so quantization stays constant."""
    client = _get_or_client()
    body: dict[str, Any] = {"usage": {"include": True}}
    if isinstance(cfg.get("reasoning"), dict):
        body["reasoning"] = cfg["reasoning"]
    if cfg.get("provider"):
        body["provider"] = {"order": [cfg["provider"]], "allow_fallbacks": False}

    completions, finish, served = [], [], []
    p_tok = c_tok = r_tok = 0
    cost = 0.0
    returned = None
    t0 = time.time()
    for _ in range(n):
        delay = 1.0
        for attempt in range(max_retries):
            try:
                resp = client.chat.completions.create(
                    model=model, messages=messages, n=1, max_tokens=OR_MAX_TOKENS,
                    temperature=temperature, extra_body=body)
                break
            except Exception:
                if attempt == max_retries - 1:
                    raise
                time.sleep(delay)
                delay = min(delay * 2, 30.0)
        ch = resp.choices[0]
        completions.append(ch.message.content or "")
        finish.append(ch.finish_reason)
        returned = getattr(resp, "model", None)
        served.append(getattr(resp, "provider", None))
        u = getattr(resp, "usage", None)
        if u is not None:
            p_tok += getattr(u, "prompt_tokens", 0) or 0
            c_tok += getattr(u, "completion_tokens", 0) or 0
            # OpenRouter returns the real billed amount here; it is not in the SDK's
            # typed model, so it arrives via model_extra.
            extra = getattr(u, "model_extra", None) or {}
            cost += float(extra.get("cost") or 0.0)
            det = getattr(u, "completion_tokens_details", None)
            if det is not None:
                r_tok += getattr(det, "reasoning_tokens", 0) or 0

    _write_log(log_dir, {
        "backend": "openrouter", "model_requested": model, "model_returned": returned,
        "providers_served": served, "reasoning_sent": body.get("reasoning"),
        "provider_pinned": cfg.get("provider"),
        "finish_reasons": finish, "system": system, "prompt": prompt,
        "temperature": temperature, "max_tokens": OR_MAX_TOKENS, "n": n,
        "completions": completions,
        "usage": {"prompt_tokens": p_tok, "completion_tokens": c_tok,
                  "reasoning_tokens": r_tok, "total_tokens": p_tok + c_tok},
        "billed_usd": round(cost, 6),
        "latency_sec": round(time.time() - t0, 3),
    })
    return completions


def complete(model: str, prompt: str, *, temperature: float = 0.0, max_tokens: int = 1024,
             n: int = 1, json_mode: bool = False, log_dir: Path | None = None,
             system: str | None = None, max_retries: int = 5) -> list[str]:
    """Single-turn completion returning the text of n samples.

    D1 calls this with temperature=0.8, n=5; D2 with temperature=0.3, n=3; the judge
    with temperature=0, n=1. Those values are the frozen protocol — see PROTOCOL.md.
    """
    messages: list[dict[str, Any]] = []
    if system:
        messages.append({"role": "system", "content": system})
    messages.append({"role": "user", "content": prompt})

    cfg = model_cfg(model)
    if cfg["backend"] == "openrouter":
        return _complete_openrouter(model, messages, temperature, n, log_dir, prompt,
                                    system, max_retries, cfg)

    if not model.startswith("gpt-") and not model.startswith("o"):
        raise ValueError(f"unsupported model: {model!r}")

    client = _get_client()
    # gpt-5* / o* renamed max_tokens to max_completion_tokens and lock temperature at
    # the service default. They also spend most of the budget on hidden reasoning
    # tokens, so the visible answer comes back empty at the protocol's 900-token
    # budget — hence the ×32 bump. Billing charges only what is actually generated.
    is_reasoning = model.startswith("gpt-5") or model.startswith("o")
    kwargs: dict[str, Any] = {"model": model, "messages": messages, "n": n}
    if is_reasoning:
        kwargs["max_completion_tokens"] = max(max_tokens * 32, 16384)
    else:
        kwargs["max_tokens"] = max_tokens
        kwargs["temperature"] = temperature
    if json_mode:
        kwargs["response_format"] = {"type": "json_object"}

    delay = 1.0
    for attempt in range(max_retries):
        t0 = time.time()
        try:
            resp = client.chat.completions.create(**kwargs)
            break
        except Exception:
            if attempt == max_retries - 1:
                raise
            time.sleep(delay)
            delay = min(delay * 2, 30.0)

    completions = [c.message.content or "" for c in resp.choices]
    usage: dict[str, Any] = {"prompt_tokens": resp.usage.prompt_tokens,
                             "completion_tokens": resp.usage.completion_tokens,
                             "total_tokens": resp.usage.total_tokens}
    det = getattr(resp.usage, "completion_tokens_details", None)
    if det is not None:
        usage["completion_tokens_details"] = (
            det.model_dump() if hasattr(det, "model_dump") else dict(det))
    _write_log(log_dir, {
        "backend": "openai", "model_requested": model,
        "model_returned": getattr(resp, "model", None),
        "response_id": getattr(resp, "id", None),
        "reasoning_sent": None,          # native default; gpt-5* defaults to medium
        "finish_reasons": [c.finish_reason for c in resp.choices],
        "system": system, "prompt": prompt, "temperature": temperature,
        "max_tokens": max_tokens, "n": n, "json_mode": json_mode,
        "completions": completions, "usage": usage,
        "latency_sec": round(time.time() - t0, 3),
        "estimated_cost_usd": estimate_cost(model, resp.usage.prompt_tokens,
                                            resp.usage.completion_tokens),
    })
    return completions


def estimate_cost(model: str, prompt_tokens: int, completion_tokens: int) -> float:
    """Rough cost for the OpenAI path (NaN when unpriced). OpenRouter calls log the
    real billed amount instead — prefer that."""
    pricing = _MODEL_PRICING.get(model)
    if pricing is None:
        return math.nan
    a, b = pricing
    return (prompt_tokens * a + completion_tokens * b) / 1_000_000
