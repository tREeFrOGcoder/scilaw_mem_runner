# 记忆探针 · 跑测包(发给协作者的极简目录)

这个目录是**完全自包含**的:把整个 `runner/` 文件夹拷到任何一台机器上就能跑,不需要
benchmark 仓库、不需要别的代码、不读目录外的任何文件。

## 它在测什么

给模型一个已发表科学定律的**目标量和输入变量描述**,**不给任何数据**,问它能不能凭记忆
写出那个闭式公式。分两种问法:

- **D1 冷回忆** —— 只给量的描述,采 5 次
- **D2 提示回忆** —— 额外给出论文出处 `作者 (年份)`,采 3 次

再用另一个模型(`gpt-4.1`)判断答案和真实公式在代数上是否等价。5 次里中 3 次(或 D2 中
2/3)算 `memorized`,完全没中算 `clean`。

## 准备

```bash
pip install -r requirements.txt          # 只要 openai + PyYAML

export OPENROUTER_API_KEY=sk-or-...      # 跑非 OpenAI 模型需要
export OPENAI_API_KEY=sk-...             # 跑 OpenAI 模型 + 判分需要
```

⚠️ **`OPENAI_API_KEY` 任何情况下都要**:判分模型固定是 `gpt-4.1`,走 OpenAI。哪怕你只跑
GLM,判分那部分还是花 OpenAI 的钱(每条腿约 \$4.7)。

## 三步

### 1. 看清单

```bash
python3 run_mem.py --list
```

会列出可跑的模型、各自的 reasoning 设定、钉死的 provider、以及每条腿的预估花费。

### 2. 先冒烟(约 \$0.1,**请务必先做**)

```bash
python3 run_mem.py --models glm --limit 2
```

只跑 2 个任务。看到每行输出 `D1 x/5 D2 y/3 | 判定` 就说明链路通了。

### 3. 正式跑

```bash
python3 run_mem.py --models glm                  # 一个模型,118 个任务
python3 run_mem.py --models glm,qwen             # 多个模型
python3 run_mem.py --models all                  # 全部 5 个非 OpenAI 模型
python3 run_mem.py --models glm --pack           # 跑完自动打包成 zip
```

可用简称:`opus` `deepseek` `gemini` `qwen` `glm`,也可以直接写完整 slug。

跑完会打印每个模型的任务数、行数、三类判定的数量,以及**实际计费金额**。

## 跑完把什么发回来

最省事的办法是加 `--pack`,它会生成一个 `mem_results_<模型>.zip`,直接发这个就行。

不用 `--pack` 的话,把整个 `runs/` 目录打包发回。里面每个 `runs/<任务>/<模型>/` 含:

| 文件 | 是什么 |
|---|---|
| `result.json` | 每个公式的命中数和判定结果 |
| `d1_samples.txt` | 模型 5 次冷回忆的原文 |
| `d1_raw/` `d2_raw/` | 完整请求 + 全部原始回复 + token 用量 + **实际计费** + 实际服务的 provider |
| `judge_raw/` | 每一次判分调用和它的结论 |

一个模型跑完约 **10 MB**(判分日志占大头)。**请不要删 `*_raw/`** —— 那是原始数据,后面
要用来复核判分、换判分模型重跑、以及核对成本,分数本身反而是可以重算的。

## 需要知道的几件事

**跑多久 / 多少钱。** 一条腿 118 个任务,`--workers 12` 大约 2–4 小时(推理模型在生僻公式上
单次要 30–60 秒)。花费见 `--list`,便宜的约 \$20,Gemini 最贵约 \$90。

**中途断了不用重头再来。** 每个任务跑完就立刻落盘。重跑同样的命令会覆盖已完成的任务,
如果只想补没跑完的,把已完成的任务名从 `tasks_118.json` 里去掉再跑。

**余额要留富余,不能刚好够。** OpenRouter 是按 `max_tokens` **预授权**的:我们每次请求
上限 28800 token,余额不足以覆盖这个额度时会直接拒绝(402),哪怕这次调用实际只用 2000
token。所以余额接近见底时,整条腿的尾巴会成批失败。**建议余额至少是预估花费的 1.3 倍。**

**不要改任何参数。** 温度、采样次数、判分模型、判定阈值、reasoning 档位、provider 钉选,
全部是冻结的实验设定 —— 改了这条腿就没法和论文里已有的 8 个模型放在一起比。要改请先讨论。
理由写在上一层的 `../PROTOCOL.md`。

## 目录里都是什么

```
run_mem.py              一键入口(你只需要用这个)
models.json             每个模型的 backend / reasoning / provider 设定
pilot_v3.py             实际的探针实现
client.py               API 调用层(OpenAI 原生 + OpenRouter 双路)
d2_extract.py           D2 上下文提取(citation 模式下用不到,保留以免导入报错)
tasks_118.json          118 个任务的清单
bench/                  任务切片:每个任务只有 metadata.yaml + formulas/,共 3.6 MB
requirements.txt
```
